﻿// Analytics.cpp : Этот файл содержит функцию "main". Здесь начинается и заканчивается выполнение программы.
//
#include<iostream>
#include<fstream>
#include <stdlib.h>
#include<cmath>
#include<complex>
#define _USE_MATH_DEFINES
#include <gsl/gsl_math.h>
#include <gsl/gsl_monte.h>
#include <gsl/gsl_monte_plain.h>
#include <gsl/gsl_monte_miser.h>
#include <gsl/gsl_monte_vegas.h>
using namespace std;

struct my_f_params { double Q2;double m;double mq;double b;double b1;double N; };
double f1(double* k, size_t dim, void* p)
{
    (void)(dim);
    struct my_f_params* fp = (struct my_f_params*)p;
    double x1 = k[0],x2=k[1],x3=k[2];
    double mq = fp->mq;
    double mpi = fp->m;
    double be12 = fp->b*fp->b;
    double be22 = fp->b1 * fp->b1;
    double qq = -fp->Q2;
    if (k[1] > 1 - k[0])
    {
        return 0;
    }
    if (k[2] > 1 - k[0] - k[1])
    {
        return 0;
    }
    else
    {
        return (1 / (pow(-mpi * mpi * x3 * x3 + ((-mpi * mpi - qq / 2.0) * x2 - x1 * mpi * mpi + mpi * mpi) * x3 + (
            -mpi * mpi / 4.0 - qq / 2.0) * x2 * x2 + ((-mpi * mpi / 2.0 - qq / 4.0) * x1 + mpi * mpi / 4.0 - be22 + mq * mq + qq /
                2.0) * x2 - x1 * x1 * mpi * mpi / 4.0 + (mpi * mpi / 4.0 - be12 + mq * mq) * x1 - mq * mq, 2.0))
            );
    }
    //2 * M_PI * M_PI * fp->mq * 4 * sqrt(3) * sqrt(-fp->N) / (sqrt(2) * 4 * M_PI * M_PI)
 
}
double f21(double* k, size_t dim, void* p)
{
    (void)(dim);
    struct my_f_params* fp = (struct my_f_params*)p;
    double x2 = k[0], y3 = k[1],x1=k[2];
    double mq = fp->mq;
    double mpi = fp->m;
    double be12 = fp->b * fp->b;
    double be22 = fp->b1 * fp->b1;
    double qq = -fp->Q2;
    if (k[1] > (1 - k[0])/2)
    {
        return 0;
    }
    if (k[2] > 2*k[1])
    {
        return 0;
    }
    else
    {

        return (1 / (pow(-mpi * mpi * y3 * y3 + ((-mpi * mpi - qq / 2.0) * x2 + mpi * mpi) * y3 + (-mpi * mpi /
            4.0 - qq / 2.0) * x2 * x2 + (mpi * mpi / 4.0 - be22 + mq * mq + qq / 2.0) * x2 + (-mpi * mpi / 4.0 - be12 + mq * mq) *
            x1 - mq * mq, 2.0))

            );
    }
    //2 * M_PI * M_PI * fp->mq * 4 * sqrt(3) * sqrt(-fp->N) / (sqrt(2) * 4 * M_PI * M_PI)

}
double f22(double* k, size_t dim, void* p)
{
    (void)(dim);
    struct my_f_params* fp = (struct my_f_params*)p;
    double x2 = k[0], y3 = k[1], x1 = k[2];
    double mq = fp->mq;
    double mpi = fp->m;
    double be12 = fp->b * fp->b;
    double be22 = fp->b1 * fp->b1;
    double qq = -fp->Q2;
    if (k[1] < (1 - k[0]) / 2)
    {
        return 0;
    }
    if (k[1] > (1 - k[0]) )
    {
        return 0;
    }
    if (k[2] > 2 * (1-k[0]-k[1]))
    {
        return 0;
    }

    else
    {
        return (1 / (pow(-mpi * mpi * y3 * y3 + ((-mpi * mpi - qq / 2.0) * x2 + mpi * mpi) * y3 + (-mpi * mpi /
            4.0 - qq / 2.0) * x2 * x2 + (mpi * mpi / 4.0 - be22 + mq * mq + qq / 2.0) * x2 + (-mpi * mpi / 4.0 - be12 + mq * mq) *
            x1 - mq * mq, 2.0))

            );
    }
    //2 * M_PI * M_PI * fp->mq * 4 * sqrt(3) * sqrt(-fp->N) / (sqrt(2) * 4 * M_PI * M_PI)

}

double f31(double* k, size_t dim, void* p)
{
    (void)(dim);
    struct my_f_params* fp = (struct my_f_params*)p;
    double x2 = k[0], y3 = k[1];
    double mq = fp->mq;
    double mpi = fp->m;
    double be12 = fp->b * fp->b;
    double be22 = fp->b1 * fp->b1;
    double qq = -fp->Q2;


    if (k[1] > (1 - k[0])/2)
    {
        return 0;
    }


    else
    {
        return (-16.0 / (mpi * mpi * x2 * x2 + 4.0 * mpi * mpi * x2 * y3 + 4.0 * mpi * mpi * y3 * y3 - x2 * mpi * mpi
            - 2.0 * mpi * mpi * y3 - 4.0 * x2 * mq * mq - 8.0 * mq * mq * y3 + 2.0 * qq * x2 * x2 + 2.0 * qq * x2 * y3 + 8.0 * be12 * y3
            + 4.0 * x2 * be22 + 4.0 * mq * mq - 2.0 * x2 * qq) / (mpi * mpi - 4.0 * mq * mq + 4.0 * be12) + 16.0 / (mpi * mpi * x2
                * x2 + 4.0 * mpi * mpi * x2 * y3 + 4.0 * mpi * mpi * y3 * y3 - x2 * mpi * mpi - 4.0 * mpi * mpi * y3 - 4.0 * x2 * mq * mq +
                2.0 * qq * x2 * x2 + 2.0 * qq * x2 * y3 + 4.0 * x2 * be22 + 4.0 * mq * mq - 2.0 * x2 * qq) / (mpi * mpi - 4.0 * mq * mq +
                    4.0 * be12)

            );
     /*   return (-16.0 / (mpi * mpi * x2 * x2 + 4.0 * x2 * mpi * mpi * y3 + 4.0 * mpi * mpi * y3 * y3 - x2 * mpi * mpi
            - 4.0 * mpi * mpi * y3 - 4.0 * x2 * mq * mq + 2.0 * x2 * x2 * qq + 2.0 * x2 * y3 * qq + 4.0 * x2 * be22 + 4.0 * mq * mq
            - 2.0 * x2 * qq) / (mpi * mpi - 4.0 * mq * mq + 4.0 * be12)
            );
        return(-16.0 / (mpi * mpi * x2 * x2 + 4.0 * x2 * mpi * mpi * y3 + 4.0 * mpi * mpi * y3 * y3 - x2 * mpi * mpi
            - 2.0 * mpi * mpi * y3 - 4.0 * x2 * mq * mq - 8.0 * mq * mq * y3 + 2.0 * x2 * x2 * qq + 2.0 * x2 * y3 * qq + 8.0 * be12 * y3
            + 4.0 * x2 * be22 + 4.0 * mq * mq - 2.0 * x2 * qq) / (mpi * mpi - 4.0 * mq * mq + 4.0 * be12)
        );
        return(16.0 / (-mpi * mpi * x2 * x2 - 4.0 * x2 * mpi * mpi * y3 - 4.0 * mpi * mpi * y3 * y3 + 3.0 * x2 * mpi *
            mpi + 6.0 * mpi * mpi * y3 - 4.0 * x2 * mq * mq - 8.0 * mq * mq * y3 - 2.0 * x2 * x2 * qq - 2.0 * x2 * y3 * qq + 8.0 * be12
            * x2 + 8.0 * be12 * y3 - 4.0 * x2 * be22 - 2.0 * mpi * mpi + 4.0 * mq * mq + 2.0 * x2 * qq - 8.0 * be12) / (mpi * mpi
                - 4.0 * mq * mq + 4.0 * be12)
            );*/
    }
    //2 * M_PI * M_PI * fp->mq * 4 * sqrt(3) * sqrt(-fp->N) / (sqrt(2) * 4 * M_PI * M_PI)

}
double f32(double* k, size_t dim, void* p)
{
    (void)(dim);
    struct my_f_params* fp = (struct my_f_params*)p;
    double x2 = k[0], y3 = k[1];
    double mq = fp->mq;
    double mpi = fp->m;
    double be12 = fp->b * fp->b;
    double be22 = fp->b1 * fp->b1;
    double qq = -fp->Q2;

    if (k[1] <(1 - k[0]) / 2)
    {
        return 0;
    }
    if (k[1] > (1 - k[0]))
    {
        return 0;
    }


    else
    {
        return (16.0 / (-mpi * mpi * x2 * x2 - 4.0 * mpi * mpi * x2 * y3 - 4.0 * mpi * mpi * y3 * y3 + 3.0 * x2 * mpi *
            mpi + 6.0 * mpi * mpi * y3 - 4.0 * x2 * mq * mq - 8.0 * mq * mq * y3 - 2.0 * qq * x2 * x2 - 2.0 * qq * x2 * y3 + 8.0 * be12
            * x2 + 8.0 * be12 * y3 - 4.0 * x2 * be22 - 2.0 * mpi * mpi + 4.0 * mq * mq + 2.0 * x2 * qq - 8.0 * be12) / (mpi * mpi
                - 4.0 * mq * mq + 4.0 * be12) + 16.0 / (mpi * mpi * x2 * x2 + 4.0 * mpi * mpi * x2 * y3 + 4.0 * mpi * mpi * y3 * y3 - x2
                    * mpi * mpi - 4.0 * mpi * mpi * y3 - 4.0 * x2 * mq * mq + 2.0 * qq * x2 * x2 + 2.0 * qq * x2 * y3 + 4.0 * x2 * be22 + 4.0 *
                    mq * mq - 2.0 * x2 * qq) / (mpi * mpi - 4.0 * mq * mq + 4.0 * be12)


            );
        //return (-16.0 / (mpi * mpi * x2 * x2 + 4.0 * x2 * mpi * mpi * y3 + 4.0 * mpi * mpi * y3 * y3 - x2 * mpi * mpi
        //    - 4.0 * mpi * mpi * y3 - 4.0 * x2 * mq * mq + 2.0 * x2 * x2 * qq + 2.0 * x2 * y3 * qq + 4.0 * x2 * be22 + 4.0 * mq * mq
        //    - 2.0 * x2 * qq) / (mpi * mpi - 4.0 * mq * mq + 4.0 * be12)
        //    );
        //return(-16.0 / (mpi * mpi * x2 * x2 + 4.0 * x2 * mpi * mpi * y3 + 4.0 * mpi * mpi * y3 * y3 - x2 * mpi * mpi
        //    - 2.0 * mpi * mpi * y3 - 4.0 * x2 * mq * mq - 8.0 * mq * mq * y3 + 2.0 * x2 * x2 * qq + 2.0 * x2 * y3 * qq + 8.0 * be12 * y3
        //    + 4.0 * x2 * be22 + 4.0 * mq * mq - 2.0 * x2 * qq) / (mpi * mpi - 4.0 * mq * mq + 4.0 * be12)
        //    );
        //return(16.0 / (-mpi * mpi * x2 * x2 - 4.0 * x2 * mpi * mpi * y3 - 4.0 * mpi * mpi * y3 * y3 + 3.0 * x2 * mpi *
        //    mpi + 6.0 * mpi * mpi * y3 - 4.0 * x2 * mq * mq - 8.0 * mq * mq * y3 - 2.0 * x2 * x2 * qq - 2.0 * x2 * y3 * qq + 8.0 * be12
        //    * x2 + 8.0 * be12 * y3 - 4.0 * x2 * be22 - 2.0 * mpi * mpi + 4.0 * mq * mq + 2.0 * x2 * qq - 8.0 * be12) / (mpi * mpi
        //        - 4.0 * mq * mq + 4.0 * be12)
        //    );
    }
    //2 * M_PI * M_PI * fp->mq * 4 * sqrt(3) * sqrt(-fp->N) / (sqrt(2) * 4 * M_PI * M_PI)

}
double g1_f(double* k, size_t dim, void* p)
{
    (void)(dim);

    struct my_f_params* fp = (struct my_f_params*)p;
    double x1 = k[0], x2 = k[1], x3 = k[2], x4 = k[3];
    double mpi = fp->m;
    double mq = fp->mq;
    double b22 = fp->b1 * fp->b1;
    double b12 = fp->b * fp->b;
    double N21 = -0.00596821;
    double N22 = -0.0175172;
    double N23 = -0.00325021;
    double q2 = -fp->Q2;
    double eta = -q2 / (4 * fp->m * fp->m);
    double pq = fp->m * fp->m * 2 * eta;
    /*double l2 = fp->m * fp->m * (k[0] / 2.0 + k[1] / 2.0 + k[2] / 2.0 - 1.0 + k[3]) * (k[0] / 2.0 + k[1] / 2.0 + k[2] / 2.0 - 1.0 + k[3]) + k[2] * k[2] * q2 / 4.0 - pq * (k[0] / 2.0 + k[1] /
        2.0 + k[2] / 2.0 - 1.0 + k[3]) * k[2];*/
    double l2= x2 * x2 * mpi * mpi / 4.0 + x4 * x4 * mpi * mpi / 4.0 + mpi * mpi * pow(1.0 - x1 - x2 - x3 - x4, 2.0)
        + x1 * x1 * mpi * mpi / 4.0 - x1 * q2 * x2 / 4.0 - x4 * q2 * x2 / 4.0 - q2 * (1.0 - x1 - x2 - x3 - x4) * x2 / 2.0 + x1 * mpi
        * mpi * x4 / 2.0 + x1 * mpi * mpi * x2 / 2.0 + x2 * mpi * mpi * (1.0 - x1 - x2 - x3 - x4) + x4 * mpi * mpi * (1.0 - x1 -
            x2 - x3 - x4) + x2 * mpi * mpi * x4 / 2.0 + x1 * mpi * mpi * (1.0 - x1 - x2 - x3 - x4);



   /* double D = (-1.0 + k[0] + k[1] + k[2]) * fp->mq * fp->mq + (-3.0 / 4.0 * k[0] - 3.0 / 4.0 * k[1] - 3.0 / 4.0 * k[2] + 1.0 - k[3]) * fp->m * fp->m
        - k[0] * fp->b * fp->b - k[1] * fp->b1 * fp->b1 + k[2] * pq / 2.0 + k[2] * q2 / 4.0 - k[2] * fp->b * fp->b;*/
    double D= x1 * mpi * mpi / 4.0 - x1 * b12 + x2 * mpi * mpi / 4.0 - x2 * b12 - mq * mq * x3 + x4 * mpi * mpi /
        4.0 - x4 * b22 - mq * mq * (1.0 - x1 - x2 - x3 - x4) + mpi * mpi * (1.0 - x1 - x2 - x3 - x4);


    double l0 = fp->m * sqrt(1 + eta) * (-k[0] / 2.0 - k[1] / 2.0 - k[2] / 2.0 - (1 - k[0] - k[1] - k[2] - k[3]));
    double p0 = fp->m * sqrt(1 + eta);
    double pl = fp->m * fp->m * (-k[0] / 2.0 - k[1] / 2.0 - k[2] / 2.0 - (1 - k[0] - k[1] - k[2] - k[3])) - pq * k[2] / 2;
    double ql = pq * (-k[0] / 2.0 - k[1] / 2.0 - k[2] / 2.0 - (1 - k[0] - k[1] - k[2] - k[3])) - k[2] * q2 / 2.0;
    //double numerator= (8.0 * pl + 4 * ql + 4 * fp->m * fp->m + 4* pq) * (fp->mq * fp->mq - D - pl);
    //double numerator = (8.0 * pl + 4 * ql + 4 * fp->m * fp->m + 2 * pq) * (fp->mq * fp->mq - D - pl);
    double numerator = 8.0 * fp->mq * fp->mq * pl + 4.0 * fp->mq * fp->mq * ql + (4.0 * fp->m * fp->m + 2.0 * pq) * fp->mq * fp->mq - 8.0 * pl * (l2 + 3.0 * (D - l2) / 2.0) - 4 * ql * (l2 + 3.0 * (D - l2) / 2.0) - (4.0 * fp->m * fp->m + 2.0 * pq) * D - 8.0 * (pl * pl + fp->m * fp->m * (D - l2) / 4.0) - 4.0 * (ql * pl + pq * (D - l2) / 4.0) - (4.0 * fp->m * fp->m + 2.0 * pq) * pl;
    //double numerator = 1;
    if (k[1] > 1 - k[0])
    {
        return 0;
    }
    if (k[2] > 1 - k[0] - k[1])
    {
        return 0;
    }
    if (k[3] > 1 - k[0] - k[1] - k[2])
    {
        return 0;
    }

    else
    {

        return (1 / ((D - l2) * (D - l2) * (D - l2) ));
 }

}
double g2_f(double* k, size_t dim, void* p)
{
    (void)(dim);

    struct my_f_params* fp = (struct my_f_params*)p;
    double x1 = k[0], x2 = k[1], x3 = k[2];
    double mpi = fp->m;
    double mq = fp->mq;
    double b22 = fp->b1 * fp->b1;
    double b12 = fp->b * fp->b;
    double N21 = -0.00596821;
    double N22 = -0.0175172;
    double N23 = -0.00325021;
    double q2 = -fp->Q2;
    double eta = -q2 / (4 * fp->m * fp->m);
    double pq = fp->m * fp->m * 2 * eta;
    double l2 = fp->m * fp->m * (k[0] / 2.0 + k[1] / 2.0 + k[2] / 2.0 - 1.0 + k[3]) * (k[0] / 2.0 + k[1] / 2.0 + k[2] / 2.0 - 1.0 + k[3]) + k[2] * k[2] * q2 / 4.0 - pq * (k[0] / 2.0 + k[1] /
        2.0 + k[2] / 2.0 - 1.0 + k[3]) * k[2];
    //double l2= x2 * x2 * mpi * mpi / 4.0 + x4 * x4 * mpi * mpi / 4.0 + mpi * mpi * pow(1.0 - x1 - x2 - x3 - x4, 2.0)
    //    + x1 * x1 * mpi * mpi / 4.0 - x1 * q2 * x2 / 4.0 - x4 * q2 * x2 / 4.0 - q2 * (1.0 - x1 - x2 - x3 - x4) * x2 / 2.0 + x1 * mpi
    //    * mpi * x4 / 2.0 + x1 * mpi * mpi * x2 / 2.0 + x2 * mpi * mpi * (1.0 - x1 - x2 - x3 - x4) + x4 * mpi * mpi * (1.0 - x1 -
    //        x2 - x3 - x4) + x2 * mpi * mpi * x4 / 2.0 + x1 * mpi * mpi * (1.0 - x1 - x2 - x3 - x4);



    double D = (-1.0 + k[0] + k[1] + k[2]) * fp->mq * fp->mq + (-3.0 / 4.0 * k[0] - 3.0 / 4.0 * k[1] - 3.0 / 4.0 * k[2] + 1.0 - k[3]) * fp->m * fp->m
        - k[0] * fp->b * fp->b - k[1] * fp->b1 * fp->b1 + k[2] * pq / 2.0 + k[2] * q2 / 4.0 - k[2] * fp->b * fp->b;
    /* double D= x1 * mpi * mpi / 4.0 - x1 * b12 + x2 * mpi * mpi / 4.0 - x2 * b12 - mq * mq * x3 + x4 * mpi * mpi /
         4.0 - x4 * b22 - mq * mq * (1.0 - x1 - x2 - x3 - x4) + mpi * mpi * (1.0 - x1 - x2 - x3 - x4);*/


    double l0 = fp->m * sqrt(1 + eta) * (-k[0] / 2.0 - k[1] / 2.0 - k[2] / 2.0 - (1 - k[0] - k[1] - k[2] - k[3]));
    double p0 = fp->m * sqrt(1 + eta);
    double pl = fp->m * fp->m * (-k[0] / 2.0 - k[1] / 2.0 - k[2] / 2.0 - (1 - k[0] - k[1] - k[2] - k[3])) - pq * k[2] / 2;
    double ql = pq * (-k[0] / 2.0 - k[1] / 2.0 - k[2] / 2.0 - (1 - k[0] - k[1] - k[2] - k[3])) - k[2] * q2 / 2.0;
    //double numerator= (8.0 * pl + 4 * ql + 4 * fp->m * fp->m + 4* pq) * (fp->mq * fp->mq - D - pl);
    //double numerator = (8.0 * pl + 4 * ql + 4 * fp->m * fp->m + 2 * pq) * (fp->mq * fp->mq - D - pl);
    double numerator = 8.0 * fp->mq * fp->mq * pl + 4.0 * fp->mq * fp->mq * ql + (4.0 * fp->m * fp->m + 2.0 * pq) * fp->mq * fp->mq - 8.0 * pl * (l2 + 3.0 * (D - l2) / 2.0) - 4 * ql * (l2 + 3.0 * (D - l2) / 2.0) - (4.0 * fp->m * fp->m + 2.0 * pq) * D - 8.0 * (pl * pl + fp->m * fp->m * (D - l2) / 4.0) - 4.0 * (ql * pl + pq * (D - l2) / 4.0) - (4.0 * fp->m * fp->m + 2.0 * pq) * pl;
    //double numerator = 1;
    if (k[1] > 1 - k[0])
    {
        return 0;
    }
    if (k[2] > 1 - k[0] - k[1])
    {
        return 0;
    }


    else
    {
        return(2.0 / pow(-mpi * mpi * x3 * x3 + ((-mpi * mpi - q2 / 2.0) * x2 - x1 * mpi * mpi + mpi * mpi) * x3 +
            (-mpi * mpi / 4.0 - q2 / 2.0) * x2 * x2 + ((-mpi * mpi / 2.0 - q2 / 4.0) * x1 + mpi * mpi / 4.0 - b22 + mq * mq + q2
                / 2.0) * x2 - mpi * mpi * x1 * x1 / 4.0 + (mpi * mpi / 4.0 - b12 + mq * mq) * x1 - mq * mq, 3.0) * x1)

        ;
    }

}
int main()
{
    double res,err,res1, err1,res2,err2;
    double xu[4] = { 1,1,1,1 };
    double xl[4] = { 0,0,0,0 };
    double xu1[3] = { 1,1,1 };
    double xl1[3] = { 0,0,0};
    double xu2[2] = { 1,1 };
    double xl2[2] = { 0,0 };
    const gsl_rng_type* T;
    gsl_rng* r;

    gsl_rng_env_setup();

    T = gsl_rng_default;
    r = gsl_rng_alloc(T);
    double Q2 = 0.2;
    double m = 0.14;
    double mq = 0.3;
    double b = 0.5;
    double b2 = 0.6;
    double N = -0.00613619;
    double N21 = -0.00596821;
    double N22 = -0.0175172;
    double N23 = -0.00325021;
    struct my_f_params params = { Q2,m,mq,b,b2,N21 };
    {
        //gsl_monte_vegas_state* s_fmonopole = gsl_monte_vegas_alloc(4);
        //gsl_monte_function G_fmonopole = { &g1_f , 4,&params };
        //gsl_monte_vegas_integrate(&G_fmonopole, xl, xu, 4, 1000000, r, s_fmonopole,
        //    &res, &err);
        //do
        //{
        //    gsl_monte_vegas_integrate(&G_fmonopole, xl, xu, 4, 1000000, r, s_fmonopole,
        //        &res, &err);
        //} while (fabs(gsl_monte_vegas_chisq(s_fmonopole) - 1.0) > 0.5);
        gsl_monte_vegas_state* s_fmonopole1 = gsl_monte_vegas_alloc(3);
        gsl_monte_function G_fmonopole1 = { &g2_f , 3,&params };
        gsl_monte_vegas_integrate(&G_fmonopole1, xl1, xu1, 3, 1000000, r, s_fmonopole1,
            &res1, &err1);
        do
        {
            gsl_monte_vegas_integrate(&G_fmonopole1, xl1, xu1, 3, 1000000, r, s_fmonopole1,
                &res1, &err1);
        } while (fabs(gsl_monte_vegas_chisq(s_fmonopole1) - 1.0) > 0.5);
        //gsl_monte_vegas_state* s_fmonopole1 = gsl_monte_vegas_alloc(3);
        //gsl_monte_function G_fmonopole1 = { &f21 , 3,&params };
        //gsl_monte_vegas_integrate(&G_fmonopole1, xl1, xu1, 3, 1000000, r, s_fmonopole1,
        //    &res1, &err1);
        //do
        //{
        //    gsl_monte_vegas_integrate(&G_fmonopole1, xl1, xu1, 3, 1000000, r, s_fmonopole1,
        //        &res1, &err1);
        //} while (fabs(gsl_monte_vegas_chisq(s_fmonopole1) - 1.0) > 0.5);

        //gsl_monte_vegas_state* s_fmonopole2 = gsl_monte_vegas_alloc(3);
        //gsl_monte_function G_fmonopole2 = { &f22 , 3,&params };
        //gsl_monte_vegas_integrate(&G_fmonopole2, xl1, xu1, 3, 1000000, r, s_fmonopole2,
        //    &res2, &err2);
        //do
        //{
        //    gsl_monte_vegas_integrate(&G_fmonopole2, xl1, xu1, 3, 1000000, r, s_fmonopole2,
        //        &res2, &err2);
        //} while (fabs(gsl_monte_vegas_chisq(s_fmonopole2) - 1.0) > 0.5);


        //gsl_monte_vegas_state* s_fmonopole1 = gsl_monte_vegas_alloc(2);
        //gsl_monte_function G_fmonopole1 = { &f31 , 2,&params };
        //gsl_monte_vegas_integrate(&G_fmonopole1, xl2, xu2, 2, 1000000, r, s_fmonopole1,
        //    &res1, &err1);
        //do
        //{
        //    gsl_monte_vegas_integrate(&G_fmonopole1, xl2, xu2, 2, 1000000, r, s_fmonopole1,
        //        &res1, &err1);
        //} while (fabs(gsl_monte_vegas_chisq(s_fmonopole1) - 1.0) > 0.5);

        //gsl_monte_vegas_state* s_fmonopole2 = gsl_monte_vegas_alloc(2);
        //gsl_monte_function G_fmonopole2 = { &f32 , 2,&params };
        //gsl_monte_vegas_integrate(&G_fmonopole2, xl2, xu2, 2, 1000000, r, s_fmonopole2,
        //    &res2, &err2);
        //do
        //{
        //    gsl_monte_vegas_integrate(&G_fmonopole2, xl2, xu2, 2, 1000000, r, s_fmonopole2,
        //        &res2, &err2);
        //} while (fabs(gsl_monte_vegas_chisq(s_fmonopole2) - 1.0) > 0.5);
    }

    cout << res1/2;


}

// Запуск программы: CTRL+F5 или меню "Отладка" > "Запуск без отладки"
// Отладка программы: F5 или меню "Отладка" > "Запустить отладку"

// Советы по началу работы 
//   1. В окне обозревателя решений можно добавлять файлы и управлять ими.
//   2. В окне Team Explorer можно подключиться к системе управления версиями.
//   3. В окне "Выходные данные" можно просматривать выходные данные сборки и другие сообщения.
//   4. В окне "Список ошибок" можно просматривать ошибки.
//   5. Последовательно выберите пункты меню "Проект" > "Добавить новый элемент", чтобы создать файлы кода, или "Проект" > "Добавить существующий элемент", чтобы добавить в проект существующие файлы кода.
//   6. Чтобы снова открыть этот проект позже, выберите пункты меню "Файл" > "Открыть" > "Проект" и выберите SLN-файл.
