﻿// Fpigamma.cpp : Этот файл содержит функцию "main". Здесь начинается и заканчивается выполнение программы.
//
#include<iostream>
#include<fstream>
#include <stdlib.h>
#include<cmath>
#include<complex>
#define _USE_MATH_DEFINES
#include <gsl/gsl_math.h>
#include <gsl/gsl_monte.h>
#include <gsl/gsl_monte_plain.h>
#include <gsl/gsl_monte_miser.h>
#include <gsl/gsl_monte_vegas.h>
using namespace std;

struct my_f_params { double Q2;double m;double mq;double b;double b1;double N; };
double gf(double* k, size_t dim, void* p)
{
    (void)(dim);

    struct my_f_params* fp = (struct my_f_params*)p;
    double x1 = k[0], x2 = k[1], x3 = k[2];
    double mpi = fp->m;
    double mq = fp->mq;
    double b = fp->b;
    double q12 = -fp->Q2;
    double eta = -q12 / (4 * fp->m * fp->m);
    if (x2 > 1 - x1)
    {
        return 0;
    }
    if (x3 > 1 - x1 - x2)
    {
        return 0;
    }
    else
    {
        

        //return( 2*M_PI*M_PI*sqrt(-fp->N)*fp->mq/(sqrt(6))/ (pow((-mpi * mpi / 4.0 + q12 / 2.0) * x1 * x1 + ((x2 + x3 - 1.0 / 2.0) * q12 - x2 * mpi * mpi /
        //    2.0 - x3 * mpi * mpi / 2.0 + b * b - mq * mq + mpi * mpi / 4.0) * x1 + (x2 + x3) * (x2 + x3 - 1.0) * q12 / 2.0 - mpi *
        //    mpi * x2 * x3 + mq * mq, 2.0)) );
        //return(  sqrt(-fp->N) * fp->mq / (pow((-mpi * mpi / 4.0 + q12 / 2.0) * x1 * x1 + ((x2 + x3 - 1.0 / 2.0) * q12 - x2 * mpi * mpi /
        //    2.0 - x3 * mpi * mpi / 2.0 + b * b - mq * mq + mpi * mpi / 4.0) * x1 + (x2 + x3) * (x2 + x3 - 1.0) * q12 / 2.0 - mpi *
        //   mpi * x2 * x3 + mq * mq, 2.0)));
       //return(2* sqrt(-fp->N) * fp->mq*sqrt(3)*sqrt(2)/6 / (pow((-mpi * mpi / 4.0 + q12 / 2.0) * x1 * x1 + ((x2 + x3 - 1.0 / 2.0) * q12 - x2 * mpi * mpi /
       //     2.0 - x3 * mpi * mpi / 2.0 + b * b - mq * mq + mpi * mpi / 4.0) * x1 + (x2 + x3) * (x2 + x3 - 1.0) * q12 / 2.0 - mpi *
       //     mpi * x2 * x3 + mq * mq, 2.0)));
       //return(8 * M_PI * M_PI * sqrt(-fp->N) * fp->mq * sqrt(3) * 2 * sqrt(2) / 9/(4*M_PI*M_PI) / (pow((-mpi * mpi / 4.0 + q12 / 2.0) * x1 * x1 + ((x2 + x3 - 1.0 / 2.0) * q12 - x2 * mpi * mpi /
       //    2.0 - x3 * mpi * mpi / 2.0 + b * b - mq * mq + mpi * mpi / 4.0) * x1 + (x2 + x3) * (x2 + x3 - 1.0) * q12 / 2.0 - mpi *
       //    mpi * x2 * x3 + mq * mq, 2.0)));
        return(4 * sqrt(-fp->N) * fp->mq * sqrt(2) / sqrt(3)/(16* M_PI * M_PI) / (pow(-b * b * x1 - x2 * mq * mq + x2 * mpi * mpi / 4.0 - x3 * mq * mq + x3 * mpi * mpi / 4.0 - (1.0 -
            x1 - x2 - x3) * mq * mq + (1.0 - x1 - x2 - x3) * q12 / 4.0 - (1.0 - x1 - x2 - x3) * (mpi * mpi / 2.0 - q12 / 2.0) / 2.0
            - mpi * mpi * pow(-x2 / 2.0 + x3 / 2.0, 2.0) - q12 * pow(1.0 - x1 - x2 - x3, 2.0) / 4.0 + (q12 / 2.0 + mpi * mpi
                / 2.0) * (1.0 - x1 - x2 - x3) * (-x2 / 2.0 + x3 / 2.0) - (mpi * mpi / 2.0 - q12 / 2.0) * (1.0 - x1 - x2 - x3) * (-x2
                    / 2.0 + x3 / 2.0) + (mpi * mpi / 2.0 - q12 / 2.0) * pow(1.0 - x1 - x2 - x3, 2.0) / 2.0, 2.0)));
        
        
        

        
    }
}
double gf_pk(double* k, size_t dim, void* p)
{
    (void)(dim);

    struct my_f_params* fp = (struct my_f_params*)p;
    double x1 = k[0], x2 = k[1], x3 = k[2];
    double alpha = -0.38;
    double mpi = fp->m;
    double mq = fp->mq;
    double b = fp->b;
    double q12 = -fp->Q2;
    double eta = -q12 / (4 * fp->m * fp->m);
    if (x2 > 1 - x1)
    {
        return 0;
    }
    if (x3 > 1 - x1 - x2)
    {
        return 0;
    }
    else
    {


        //return( 2*M_PI*M_PI*sqrt(-fp->N)*fp->mq/(sqrt(6))/ (pow((-mpi * mpi / 4.0 + q12 / 2.0) * x1 * x1 + ((x2 + x3 - 1.0 / 2.0) * q12 - x2 * mpi * mpi /
        //    2.0 - x3 * mpi * mpi / 2.0 + b * b - mq * mq + mpi * mpi / 4.0) * x1 + (x2 + x3) * (x2 + x3 - 1.0) * q12 / 2.0 - mpi *
        //    mpi * x2 * x3 + mq * mq, 2.0)) );
        //return(  sqrt(-fp->N) * fp->mq / (pow((-mpi * mpi / 4.0 + q12 / 2.0) * x1 * x1 + ((x2 + x3 - 1.0 / 2.0) * q12 - x2 * mpi * mpi /
        //    2.0 - x3 * mpi * mpi / 2.0 + b * b - mq * mq + mpi * mpi / 4.0) * x1 + (x2 + x3) * (x2 + x3 - 1.0) * q12 / 2.0 - mpi *
        //   mpi * x2 * x3 + mq * mq, 2.0)));
       //return(2* sqrt(-fp->N) * fp->mq*sqrt(3)*sqrt(2)/6 / (pow((-mpi * mpi / 4.0 + q12 / 2.0) * x1 * x1 + ((x2 + x3 - 1.0 / 2.0) * q12 - x2 * mpi * mpi /
       //     2.0 - x3 * mpi * mpi / 2.0 + b * b - mq * mq + mpi * mpi / 4.0) * x1 + (x2 + x3) * (x2 + x3 - 1.0) * q12 / 2.0 - mpi *
       //     mpi * x2 * x3 + mq * mq, 2.0)));
       //return(8 * M_PI * M_PI * sqrt(-fp->N) * fp->mq * sqrt(3) * 2 * sqrt(2) / 9/(4*M_PI*M_PI) / (pow((-mpi * mpi / 4.0 + q12 / 2.0) * x1 * x1 + ((x2 + x3 - 1.0 / 2.0) * q12 - x2 * mpi * mpi /
       //    2.0 - x3 * mpi * mpi / 2.0 + b * b - mq * mq + mpi * mpi / 4.0) * x1 + (x2 + x3) * (x2 + x3 - 1.0) * q12 / 2.0 - mpi *
       //    mpi * x2 * x3 + mq * mq, 2.0)));
        return(4 * sqrt(-fp->N) * fp->mq * sqrt(2) / sqrt(3) / (16 * M_PI * M_PI) / (pow(-b * b * x1 - x2 * mq * mq + x2 * mpi * mpi / 4.0 - x3 * mq * mq + x3 * mpi * mpi / 4.0 - (1.0 -
            x1 - x2 - x3) * mq * mq + (1.0 - x1 - x2 - x3) * q12 / 4.0 - (1.0 - x1 - x2 - x3) * (mpi * mpi / 2.0 - q12 / 2.0) / 2.0
            - mpi * mpi * pow(-alpha*x1/2-x2 / 2.0 + x3 / 2.0, 2.0) - q12 * pow(1.0 - x1 - x2 - x3, 2.0) / 4.0 + (q12 / 2.0 + mpi * mpi
                / 2.0) * (1.0 - x1 - x2 - x3) * (-alpha * x1 / 2 -x2 / 2.0 + x3 / 2.0) - (mpi * mpi / 2.0 - q12 / 2.0) * (1.0 - x1 - x2 - x3) * (-alpha * x1 / 2 -x2
                    / 2.0 + x3 / 2.0) + (mpi * mpi / 2.0 - q12 / 2.0) * pow(1.0 - x1 - x2 - x3, 2.0) / 2.0, 2.0)));





    }
}
double grianorm(double* k, size_t dim, void* p)
{
    (void)(dim);

    struct my_f_params* fp = (struct my_f_params*)p;
    double x1 = k[0], x2 = k[1], x3 = k[2], x4 = k[3];
    double mpi = fp->m;
    double mq = fp->mq;
    double b22 = fp->b1 * fp->b1;
    double b12 = fp->b * fp->b;
    double q2 = -fp->Q2;
    double eta = -q2 / (4 * fp->m * fp->m);
    double pq = fp->m * fp->m * 2 * eta;
    double l0 = -0.5 * (fp->m * sqrt(1 + eta) * (k[0] + k[1] - k[2]));
    double p0 = fp->m * sqrt(1 + eta);
    double pl = -0.5 * (fp->m * fp->m * (k[0] + k[1] - k[2]) + pq * (2 * k[1] + 1 - k[0] - k[1] - k[2] - k[3]));
    double ql = -0.5 * (pq * (k[0] + k[1] - k[2]) + q2 * (2 * k[1] + 1 - k[0] - k[1] - k[2] - k[3]));
    double l2 = 0.25 * (fp->m * fp->m * (k[0] + k[1] - k[2]) * (k[0] + k[1] - k[2]) + 2 * pq * (k[0] + k[1] - k[2]) * (2 * k[1] + 1 - k[0] - k[1] - k[2] - k[3]) + q2 * (2 * k[1] + 1 - k[0] - k[1] - k[2] - k[3]) * (2 * k[1] + 1 - k[0] - k[1] - k[2] - k[3]));
    double D = -(fp->mq * fp->mq - fp->m * fp->m / 4.) * (k[0] + k[1] + k[2]) + pq * k[1] + q2 * (k[1] + (1 - k[0] - k[1] - k[2] - k[3]) / 4.) - fp->b * fp->b * k[3] - fp->b1 * fp->b1 * (1 - k[0] - k[1] - k[2] - k[3]);
    double Sp1 = +4 * pl * l0 + p0 * (D - l2)
        + l0 * (+4 * pq + 3 * fp->m * fp->m + 4 * fp->mq * fp->mq)
        - 4 * l0 * (l2 + 3. * (D - l2) / 2)
        + p0 * (-4 * ql - 2 * pl)
        - 6 * p0 * (D)
        +p0 * (+1. / 2 * fp->m * fp->m + 6 * fp->mq * fp->mq);
    if (k[1] > 1 - k[0])
    {
        return 0;
    }
    if (k[2] > 1 - k[0] - k[1])
    {
        return 0;
    }
    if (k[3] > 1 - k[0] - k[1] - k[2])
    {
        return 0;
    }

    else
    {
        return (2 * M_PI * M_PI * Sp1  / (D - l2) / (D - l2) / (D - l2)/(16 * M_PI * M_PI * M_PI * M_PI));//monopole
         //return (2 * M_PI * M_PI * (-9.0 * mpi * (-1.0 + x1 + x2 + x3 + x4) * ((x3 * x3 * x3 / 12.0 + (1.0 / 6.0 - x1 / 4.0 - x2 / 4.0) *
         //    x3 * x3 + (x2 * x2 / 4.0 + (x1 / 2.0 + 1.0 / 6.0) * x2 + x1 * x1 / 4.0 + x1 / 6.0 + 1.0 / 12.0) * x3 - (x2 * x2 + (2.0 *
         //        x1 + 5.0) * x2 + x1 * x1 + 5.0 * x1 - 4.0) * (x2 - 1.0 + x1) / 12.0) * mpi * mpi - (x1 + x4 / 2.0) * (-x2 - 1.0 + x1 +
         //            x3 + x4) * (x1 + x2 - x3 - 7.0) * q2 / 6.0 + (-mq * mq + b22) * x3 * x3 + ((x4 + 2.0 / 3.0) * b22 - 3.0 * mq * mq - b12
         //                * x4) * x3 - (x1 + x2 - 5.0 / 3.0) * (x1 + x2 + x4 - 1.0) * b22 + mq * mq * x2 * x2 + ((2.0 * x1 - 1.0 / 3.0) * mq * mq +
         //                    b12 * x4) * x2 + (-4.0 + x1 * x1 - x1 / 3.0) * mq * mq + x4 * b12 * (x1 - 5.0 / 3.0)) * x4 * sqrt((4.0 * mpi * mpi -
         //                        q2) / (mpi * mpi)) / pow((x3 * x3 / 4.0 + (-x1 / 2.0 - x2 / 2.0 - 1.0 / 4.0) * x3 + (x1 + x2) * (x2 - 1.0 + x1) /
         //                            4.0) * mpi * mpi + (x1 + x4 / 2.0) * (-x2 - 1.0 + x1 + x3 + x4) * q2 / 2.0 + (mq * mq - b22) * x3 + (-x1 - x2 - x4 +
         //                                1.0) * b22 + mq * mq * x1 + mq * mq * x2 + b12 * x4, 5.0)));
    }
}
double grianorm_pk(double* k, size_t dim, void* p)
{
    (void)(dim);

    struct my_f_params* fp = (struct my_f_params*)p;
    double x1 = k[0], x2 = k[1], x3 = k[2], x4 = k[3];
    double alpha = -0.38;
    double mpi = fp->m;
    double mq = fp->mq;
    double b22 = fp->b1 * fp->b1;
    double b12 = fp->b * fp->b;
    double q2 = -fp->Q2;
    double eta = -q2 / (4 * fp->m * fp->m);
    double pq = fp->m * fp->m * 2 * eta;
    double l0 = (-x4 * alpha / 2.0 - alpha * (1 - x1 - x2 - x3 - x4) / 2.0 - x1 / 2.0 - x2 / 2.0 + x3 / 2.0) * fp->m * sqrt(1.0 + eta);
    double p0 = fp->m * sqrt(1 + eta);
    double pl = fp->m * fp->m * (-x4 * alpha / 2.0 - alpha * (1.0 - x1 - x2 - x3 - x4) / 2.0 - x1 / 2.0 - x2 / 2.0 + x3 / 2.0)
        + 2.0 * fp->m * fp->m * eta * (-x2 / 2.0 - 1.0 / 2.0 + x1 / 2.0 + x3 / 2.0 + x4 / 2.0);

    double ql = 2.0 * fp->m * fp->m * eta * (-x4 * alpha / 2.0 - alpha * (1.0 - x1 - x2 - x3 - x4) / 2.0 - x1 / 2.0 - x2 / 2.0
        + x3 / 2.0) + q2 * (-x2 / 2.0 - 1.0 / 2.0 + x1 / 2.0 + x3 / 2.0 + x4 / 2.0);

    double l2 = fp->m * fp->m * pow(-alpha * x4 / 2.0 - (1.0 - x1 - x2 - x3 - x4) * alpha / 2.0 - x1 / 2.0 - x2 / 2.0 + x3 /
        2.0, 2.0) + 2.0 * pq * (-x2 / 2.0 - 1.0 / 2.0 + x1 / 2.0 + x3 / 2.0 + x4 / 2.0) * (-alpha * x4 / 2.0 - (1.0 - x1 -
            x2 - x3 - x4) * alpha / 2.0 - x1 / 2.0 - x2 / 2.0 + x3 / 2.0) + q2 * pow(-x2 / 2.0 - 1.0 / 2.0 + x1 / 2.0 + x3 / 2.0 +
                x4 / 2.0, 2.0);

    double D = (-1.0 + x1 + x2 + x3) * fp->b * fp->b + (-x1 - x2 - x3) * mq * mq + (x1 / 4.0 + x2 / 4.0 + x3 / 4.0) * fp->m * fp->m + x2 *
        pq + x2 * q2 + (1.0 - x1 - x2 - x3 - x4) * q2 / 4.0;
    double Sp1 = +4 * pl * l0 + p0 * (D - l2)
        + l0 * (+4 * pq + 3 * fp->m * fp->m + 4 * fp->mq * fp->mq)
        - 4 * l0 * (l2 + 3. * (D - l2) / 2)
        + p0 * (-4 * ql - 2 * pl)
        - 6 * p0 * (D)
        +p0 * (+1. / 2 * fp->m * fp->m + 6 * fp->mq * fp->mq);
    if (k[1] > 1 - k[0])
    {
        return 0;
    }
    if (k[2] > 1 - k[0] - k[1])
    {
        return 0;
    }
    if (k[3] > 1 - k[0] - k[1] - k[2])
    {
        return 0;
    }

    else
    {
        return (2 * M_PI * M_PI * Sp1 / (D - l2) / (D - l2) / (D - l2) / (16 * M_PI * M_PI * M_PI * M_PI));//monopole
         //return (2 * M_PI * M_PI * (-9.0 * mpi * (-1.0 + x1 + x2 + x3 + x4) * ((x3 * x3 * x3 / 12.0 + (1.0 / 6.0 - x1 / 4.0 - x2 / 4.0) *
         //    x3 * x3 + (x2 * x2 / 4.0 + (x1 / 2.0 + 1.0 / 6.0) * x2 + x1 * x1 / 4.0 + x1 / 6.0 + 1.0 / 12.0) * x3 - (x2 * x2 + (2.0 *
         //        x1 + 5.0) * x2 + x1 * x1 + 5.0 * x1 - 4.0) * (x2 - 1.0 + x1) / 12.0) * mpi * mpi - (x1 + x4 / 2.0) * (-x2 - 1.0 + x1 +
         //            x3 + x4) * (x1 + x2 - x3 - 7.0) * q2 / 6.0 + (-mq * mq + b22) * x3 * x3 + ((x4 + 2.0 / 3.0) * b22 - 3.0 * mq * mq - b12
         //                * x4) * x3 - (x1 + x2 - 5.0 / 3.0) * (x1 + x2 + x4 - 1.0) * b22 + mq * mq * x2 * x2 + ((2.0 * x1 - 1.0 / 3.0) * mq * mq +
         //                    b12 * x4) * x2 + (-4.0 + x1 * x1 - x1 / 3.0) * mq * mq + x4 * b12 * (x1 - 5.0 / 3.0)) * x4 * sqrt((4.0 * mpi * mpi -
         //                        q2) / (mpi * mpi)) / pow((x3 * x3 / 4.0 + (-x1 / 2.0 - x2 / 2.0 - 1.0 / 4.0) * x3 + (x1 + x2) * (x2 - 1.0 + x1) /
         //                            4.0) * mpi * mpi + (x1 + x4 / 2.0) * (-x2 - 1.0 + x1 + x3 + x4) * q2 / 2.0 + (mq * mq - b22) * x3 + (-x1 - x2 - x4 +
         //                                1.0) * b22 + mq * mq * x1 + mq * mq * x2 + b12 * x4, 5.0)));
    }
}
int main()
{
    double xl_f[3] = { 0,0,0 };
    double xu_f[3] = { 1,1,1 };
    double res_f, err_f;
    double xl_norm[4] = { 0,0,0,0 };
    double xu_norm[4] = { 1,1,1,1 };
    double res_norm, err_norm;
    const gsl_rng_type* T;
    gsl_rng* r;

    gsl_rng_env_setup();

    T = gsl_rng_default;
    r = gsl_rng_alloc(T);
    double m = 0.14;
    double mq = 0.260;
    double b = 0.550;
    double b1 = 0.550001;
    double N21 = -0.00596118;//4.69579e-07
    double N11 = -9.29152;
    double N248450 = -5.24579;
    double N = -0.00282559;
    double N28 = -0.00613619;
    double N248550 = -8.9443;
    double N2484502 = -0.00336287;
    ofstream file("res.txt");
    {

        double b2 = b;
        file << "mq: " << mq << " be: " << b << endl;
        struct my_f_params params1 = { 0,m,mq,b,b2,N21 };
        {

            gsl_monte_vegas_state* s_norm = gsl_monte_vegas_alloc(4);
            gsl_monte_function G_norm = { &grianorm, 4,&params1 };
            gsl_monte_vegas_integrate(&G_norm, xl_norm, xu_norm, 4, 1000000, r, s_norm,
                &res_norm, &err_norm);
            do
            {
                gsl_monte_vegas_integrate(&G_norm, xl_norm, xu_norm, 4, 1000000, r, s_norm,
                    &res_norm, &err_norm);
            } while (fabs(gsl_monte_vegas_chisq(s_norm) - 1.0) > 0.5);
            cout << "N: " << 2 * m / res_norm << " N_err: " << 2 * m * (err_norm / res_norm / res_norm) << endl;
            //cout << 2 * m / res_norm << endl;
        }
        for (double Q2 = 0;Q2 < 40.2;Q2 += 0.5)
        {
            //double Q2 = 0;
            double N = 2 * m / res_norm;
            struct my_f_params params = { Q2,m,mq,b,b1,N };

            {

                gsl_monte_vegas_state* s_f = gsl_monte_vegas_alloc(3);
                gsl_monte_function G_f = { &gf, 3,&params };
                gsl_monte_vegas_integrate(&G_f, xl_f, xu_f, 3, 1000000, r, s_f,
                    &res_f, &err_f);
                do
                {
                    gsl_monte_vegas_integrate(&G_f, xl_f, xu_f, 3, 1000000, r, s_f,
                        &res_f, &err_f);
                } while (fabs(gsl_monte_vegas_chisq(s_f) - 1.0) > 0.5);
                //cout << Q2 << " " << m*m*m*M_PI* (res_f * res_f)*1e9/4/137.039/137.039 << endl;
                //cout << Q2 << " " <<   res_f  <<" "<<err_f<< endl;
                file << Q2 << " " << Q2 * res_f << endl;
            }

        }
    }
    return 0;
}

// Запуск программы: CTRL+F5 или меню "Отладка" > "Запуск без отладки"
// Отладка программы: F5 или меню "Отладка" > "Запустить отладку"

// Советы по началу работы 
//   1. В окне обозревателя решений можно добавлять файлы и управлять ими.
//   2. В окне Team Explorer можно подключиться к системе управления версиями.
//   3. В окне "Выходные данные" можно просматривать выходные данные сборки и другие сообщения.
//   4. В окне "Список ошибок" можно просматривать ошибки.
//   5. Последовательно выберите пункты меню "Проект" > "Добавить новый элемент", чтобы создать файлы кода, или "Проект" > "Добавить существующий элемент", чтобы добавить в проект существующие файлы кода.
//   6. Чтобы снова открыть этот проект позже, выберите пункты меню "Файл" > "Открыть" > "Проект" и выберите SLN-файл.
