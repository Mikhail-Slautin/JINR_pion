﻿// Full_ff_wr.cpp : Этот файл содержит функцию "main". Здесь начинается и заканчивается выполнение программы.
//

#include<iostream>
#include<fstream>
#include <stdlib.h>
#include<cmath>
#include<complex>
#define _USE_MATH_DEFINES
#include <gsl/gsl_math.h>
#include <gsl/gsl_monte.h>
#include <gsl/gsl_monte_plain.h>
#include <gsl/gsl_monte_miser.h>
#include <gsl/gsl_monte_vegas.h>
using namespace std;


struct my_f_params { double Q2;double m;double mq;double b; double N; };
//double m = 0.14;
//double mq = 0.3;
////double Q2 = 1e-4;
//double b = 0.5;
////double q2 = -Q2;
////double eta = -q2 / (4 * m * m);
complex<double> i_ = 0. + 1i;
double f1(double k4, double k, double Q2, double m, double mq, double b)
{
    double q2 = -Q2;
    double eta = -q2 / (4 * m * m);
    return (-k4 * k4 - k * k - b * b);
}
complex<double> f2(double k4, double k, double costheta, double Q2, double m, double mq, double b)
{
    double q2 = -Q2;
    double eta = -q2 / (4 * m * m);

    return(m * m / 4 + i_ * m * sqrt(1 + eta) * k4 + m * sqrt(eta) * k * costheta - k4 * k4 - k * k - mq * mq);
}
complex<double> f3(double k4, double k, double costheta, double Q2, double m, double mq, double b)
{
    double q2 = -Q2;
    double eta = -q2 / (4 * m * m);

    return(m * m / 4 - k4 * k4 - k * k + q2 + i_ * m * sqrt(1 + eta) * k4 + -3 * m * sqrt(eta) * k * costheta + m * m * 2 * eta - mq * mq);
}
complex<double> f4(double k4, double k, double costheta, double Q2, double m, double mq, double b)
{
    double q2 = -Q2;
    double eta = -q2 / (4 * m * m);

    return(m * m / 4 - i_ * m * sqrt(1 + eta) * k4 - m * sqrt(eta) * k * costheta - k4 * k4 - k * k - mq * mq);
}
double f5(double k4, double k, double costheta, double Q2, double m, double mq, double b)
{
    double q2 = -Q2;
    double eta = -q2 / (4 * m * m);

    return(-k4 * k4 - k * k - 2 * m * sqrt(eta) * k * costheta + q2 / 4 - b * b);
}
double fk1(double k0, double k, double costheta, double Q2, double m, double mq, double b)
{
    return(k0 - sqrt(b * b + k * k));
}
double fk2(double k0, double k, double costheta, double Q2, double m, double mq, double b)
{
    return(k0 + sqrt(k * k + b * b));
}
double fk3(double k0, double k, double costheta, double Q2, double m, double mq, double b)
{
    double q2 = -Q2;
    double eta = -q2 / (4 * m * m);
    //return (k0 + 0.5 * m * eta11 - 0.5 * sqrt(m * m * eta - 4 * m*eta1*k*costheta+4*k*k+4*mq*mq));
    //return(k0 + sqrt(1.0 + eta) * m / 2.0 - sqrt(-4.0 * sqrt(eta) * k * costheta * m + m * m * eta + 4.0
    //   * k * k + 4.0 * mq * mq) / 2.0
    //    );
    return(k0 + sqrt(1 + eta) * m / 2.0 - sqrt(-2.0 * k * costheta * sqrt(Q2) + m * m * (1 + eta) + 4.0 * k * k - m * m + 4.0 * mq * mq) / 2.0);
}
double fk4(double k0, double k, double costheta, double Q2, double m, double mq, double b)
{

    double q2 = -Q2;
    double eta = -q2 / (4 * m * m);
    //return (k0 + 0.5 * m * sqrt(1.0 + eta) + 0.5 * sqrt(m * m * eta - 4 * m * sqrt(eta) * k * costheta + 4 * k * k + 4 * mq * mq));
    return(k0 + sqrt(1 + eta) * m / 2.0 + sqrt(-2.0 * k * costheta * sqrt(Q2) + m * m * (1 + eta) + 4.0 * k * k - m * m + 4.0 * mq * mq) / 2.0);
}
double fk5(double k0, double k, double costheta, double Q2, double m, double mq, double b)
{
    double q2 = -Q2;
    double eta = -q2 / (4 * m * m);
   // return(k0 + 0.5 * m * eta11-0.5*sqrt(-7*m*m*eta+4*k*k-4*q2+12*m*eta1*k*costheta+4*mq*mq));
    //return(k0 + sqrt(1.0 + eta) * m / 2.0 - sqrt(12.0 * sqrt(eta) * k * costheta * m - 7.0 * m * m * eta
    //    + 4.0 * k * k + 4.0 * mq * mq - 4.0 * q2) / 2.0
    //    );
    return(k0 + sqrt(1.0 + eta) * m / 2.0 - sqrt(6.0 * k * costheta * sqrt(Q2) + (1.0 + eta) * m * m + 4.0 * k * k - m * m + 4.0 * mq * mq - 2.0 * q2) / 2.0);
}
double fk6(double k0, double k, double costheta, double Q2, double m, double mq, double b)
{
    double q2 = -Q2;
    double eta = -q2 / (4 * m * m);
    //return(k0 + 0.5 * m * sqrt(1.0 + eta) + 0.5 * sqrt(-7 * m * m * eta + 4 * k * k - 4 * q2 + 12 * m * sqrt( eta) * k * costheta + 4 * mq * mq));
    return(k0 + sqrt(1.0 + eta) * m / 2.0 + sqrt(6.0 * k * costheta * sqrt(Q2) + (1.0 + eta) * m * m + 4.0 * k * k - m * m + 4.0 * mq * mq - 2.0 * q2) / 2.0);
}
double fk7(double k0, double k, double costheta, double Q2, double m, double mq, double b)
{
    double q2 = -Q2;
    double eta = -q2 / (4 * m * m);
    //return (k0 - 0.5 * m * eta11 - 0.5 * sqrt(m * m * eta + 4 * m * eta1 * k * costheta + 4 * k * k + 4 * mq * mq));
    //return(k0 - sqrt(1.0 + eta) * m / 2.0 - sqrt(4.0 * sqrt(eta) * k * costheta * m + m * m * eta + 4.0 *
    //    k * k + 4.0 * mq * mq) / 2.0
    //    );
    return(k0 - sqrt(1.0 + eta) * m / 2.0 - sqrt(2.0 * k * costheta * sqrt(Q2) + (1.0 + eta) * m * m + 4.0 * k * k - m * m + 4.0 * mq * mq) / 2.0);
}
double fk8(double k0, double k, double costheta, double Q2, double m, double mq, double b)
{
    double q2 = -Q2;
    double eta = -q2 / (4 * m * m);
     //return (k0 - 0.5 * m * sqrt(1.0 + eta) + 0.5 * sqrt(m * m * eta + 4 * m * sqrt(eta) * k * costheta + 4 * k * k + 4 * mq * mq));
    return(k0 - sqrt(1.0 + eta) * m / 2.0 + sqrt(2.0 * k * costheta * sqrt(Q2) + (1.0 + eta) * m * m + 4.0 * k * k - m * m + 4.0 * mq * mq) / 2.0);
}
double fk9(double k0, double k, double costheta, double Q2, double m, double mq, double b)
{
    double q2 = -Q2;
    double eta = -q2 / (4 * m * m);
    //return (k0-0.5*sqrt(4*k*k+8*m*eta1*k*costheta-q2+4*b*b));
   // return(k0 - sqrt(8.0 * sqrt(eta) * k * costheta * m + 4.0 * b * b + 4.0 * k * k - q2) / 2.);
    return(k0 - sqrt(4.0 * k * costheta * sqrt(Q2) + 4.0 * k * k - q2 + 4.0 * b * b) / 2.0);
}
double fk10(double k0, double k, double costheta, double Q2, double m, double mq, double b)
{
    double q2 = -Q2;
    double eta = -q2 / (4 * m * m);
    //return (k0 + 0.5 * sqrt(4 * k * k + 8 * m * sqrt(eta) * k * costheta - q2 + 4 * b * b));
    return(k0 + sqrt(4.0 * k * costheta * sqrt(Q2) + 4.0 * k * k - q2 + 4.0 * b * b) / 2.0);
}
complex<double> Sp(double k4, double k, double costheta, double Q2, double m, double mq, double b)
{
    double q2 = -Q2;
    double eta = -q2 / (4 * m * m);
    return(4.0 * sqrt(eta) * i_ * k4 * k * m * costheta + 2.0 * sqrt(1.0 + eta) * k4 * k4 * m + 6.0 * eta * i_ * k4 *
        m * m + 4.0 * k4 * k4 * i_ * k4 + 4.0 * i_ * k4 * k * k + i_ * k4 * m * m * 3.0 + 4.0 * i_ * k4 * mq * mq + 6.0 * sqrt(1.0 + eta) * m * m * sqrt(
            eta) * k * costheta + 6.0 * sqrt(1.0 + eta) * m * k * k + sqrt(1.0 + eta) * m * m * m / 2.0 + 6.0 * sqrt(1.0
                + eta) * m * mq * mq
        );

}
double Sp1(double k0, double k, double costheta, double Q2, double m, double mq, double b)
{
    double q2 = -Q2;
    double eta = -q2 / (4 * m * m);
    return(4.0 * sqrt(eta) * k0 * k * m * costheta - 2.0 * sqrt(1.0 + eta) * k0 * k0 * m + 6.0 * eta * k0 *
        m * m - 4.0 * k0 * k0 * k0 + 4.0 * k0 * k * k + 3 * k0 * m * m + 4.0 * k0 * mq * mq + 6.0 * sqrt(1.0 + eta) * m * m * sqrt(
            eta) * k * costheta + 6.0 * sqrt(1.0 + eta) * m * k * k + sqrt(1.0 + eta) * m * m * m / 2.0 + 6.0 * sqrt(1.0
                + eta) * m * mq * mq);


}
complex<double> Spint1(double k4, double k, double costheta, double Q2, double m, double mq, double b)
{
    double q2 = -Q2;
    double eta = -q2 / (4 * m * m);
    return(8.0 * sqrt(1 + eta) * i_ * k4 * m * (mq * mq + m * m / 4.0 + k * k + k4 * k4));


}
double Spintres(double k0, double k, double costheta, double Q2, double m, double mq, double b)
{
    double q2 = -Q2;
    double eta = -q2 / (4 * m * m);
    return(8.0 * k0 * m * sqrt(1 + eta) * (mq * mq + m * m / 4.0 + k * k - k0 * k0));


}
double gint(double* x, size_t dim, void* p)//формула не из статьи а своя
{
    (void)(dim);
    struct my_f_params* fp = (struct my_f_params*)p;
    double* k = new double[3];
    double q2 = -fp->Q2;
    double eta = -q2 / (4 * fp->m * fp->m);
    
    k[0] = x[0] / (1 - x[0]);
    k[1] = x[1] / (1 - x[1]);
    k[2] = x[2];

    return real((k[1] * k[1] * 2 * 2 * M_PI * Spint1(k[0], k[1], k[2], fp->Q2, fp->m, fp->mq, fp->b) * fp->N / ((1 - x[0]) * (1 - x[0]) * (1 - x[1]) * (1 - x[1]) * f1(k[0], k[1], fp->Q2, fp->m, fp->mq, fp->b) * f1(k[0], k[1], fp->Q2, fp->m, fp->mq, fp->b + 0.00001) * f5(k[0], k[1], k[2], fp->Q2, fp->m, fp->mq, fp->b) * f2(k[0], k[1], k[2], fp->Q2, fp->m, fp->mq, fp->b) * f4(k[0], k[1], k[2], fp->Q2, fp->m, fp->mq, fp->b) * (2 * fp->m * sqrt(1 + eta)) * (2 * fp->m * sqrt(1 + eta)))));
    //Sp(k[0], k[1], k[2], fp->Q2, fp->m, fp->mq, fp->b)
         //*N2
         //* (2 * fp->m * sqrt(1 + eta))
}



double gup(double* x, size_t dim, void* p)//формула не из статьи а своя
{
    (void)(dim);
    struct my_f_params* fp = (struct my_f_params*)p;
    double* k = new double[3];
    double q2 = -fp->Q2;
    double eta = -q2 / (4 * fp->m * fp->m);
 

    k[0] = x[0] / (1 - x[0]);
    k[1] = x[1] / (1 - x[1]);
    k[2] = x[2];

    return real((k[1] * k[1] * 2 * 2 * M_PI * Sp(k[0], k[1], k[2], fp->Q2, fp->m, fp->mq, fp->b) * fp->N / ((1 - x[0]) * (1 - x[0]) * (1 - x[1]) * (1 - x[1]) * f1(k[0], k[1], fp->Q2, fp->m, fp->mq, fp->b) * f2(k[0], k[1], k[2], fp->Q2, fp->m, fp->mq, fp->b) * f3(k[0], k[1], k[2], fp->Q2, fp->m, fp->mq, fp->b) * f4(k[0], k[1], k[2], fp->Q2, fp->m, fp->mq, fp->b) * f5(k[0], k[1], k[2], fp->Q2, fp->m, fp->mq, fp->b) * (2 * fp->m * sqrt(1 + eta)))));
    //Sp(k[0], k[1], k[2], fp->Q2, fp->m, fp->mq, fp->b)
         //*N2
         //* (2 * fp->m * sqrt(1 + eta))
}
double gres1(double* k, size_t dim, void* p)
{
    (void)(dim);
    struct my_f_params* sp = (struct my_f_params*)p;

    {
        double q2 = -sp->Q2;
        double eta = -q2 / (4 * sp->m * sp->m);
  

        double k0 = -sqrt(1 + eta) * sp->m / 2.0 + sqrt(-2.0 * k[0] * k[1] * sqrt(sp->Q2) + sp->m * sp->m * (1 + eta) + 4.0 * k[0] * k[0] - sp->m * sp->m + 4.0 * sp->mq * sp->mq) / 2.0;



        double xcmin = 0.5 * (4 * k[0] * k[0] - sp->m * sp->m + 4 * sp->mq * sp->mq) / (sqrt(sp->Q2) * k[0]);
        if (k[1] < xcmin)
        {
            return 0;

        }
        else
        {
            //return(k[0] * k[0] * 2 * 2 * M_PI * N2 * Sp1(k0, k[0], k[1], sp->Q2, sp->m, sp->mq, sp->b) / (fk1(k0, k[0], k[1], sp->Q2, sp->m, sp->mq, sp->b)  * fk5(k0, k[0], k[1], sp->Q2, sp->m, sp->mq, sp->b)  * fk7(k0, k[0], k[1], sp->Q2, sp->m, sp->mq, sp->b)  * fk9(k0, k[0], k[1], sp->Q2, sp->m, sp->mq, sp->b)  * (2 * sp->m * sqrt(1 + eta))));
            return(k[0] * k[0] * 2 * 2 * M_PI* M_PI * sp->N * Sp1(k0, k[0], k[1], sp->Q2, sp->m, sp->mq, sp->b) / (fk1(k0, k[0], k[1], sp->Q2, sp->m, sp->mq, sp->b) * fk2(k0, k[0], k[1], sp->Q2, sp->m, sp->mq, sp->b) * fk4(k0, k[0], k[1], sp->Q2, sp->m, sp->mq, sp->b) * fk5(k0, k[0], k[1], sp->Q2, sp->m, sp->mq, sp->b) * fk6(k0, k[0], k[1], sp->Q2, sp->m, sp->mq, sp->b) * fk7(k0, k[0], k[1], sp->Q2, sp->m, sp->mq, sp->b) * fk8(k0, k[0], k[1], sp->Q2, sp->m, sp->mq, sp->b) * fk9(k0, k[0], k[1], sp->Q2, sp->m, sp->mq, sp->b) * fk10(k0, k[0], k[1], sp->Q2, sp->m, sp->mq, sp->b) * (2 * sp->m * sqrt(1 + eta))));
        }
    }
    //* N2 
        //* (2 * sp->m * sqrt(1 + eta))
}
double gresint1(double* k, size_t dim, void* p)
{
    (void)(dim);
    struct my_f_params* sp = (struct my_f_params*)p;

    {
        double q2 = -sp->Q2;
        double eta = -q2 / (4 * sp->m * sp->m);
  

        double k0 = -sqrt(1 + eta) * sp->m / 2.0 + sqrt(-2.0 * k[0] * k[1] * sqrt(sp->Q2) + sp->m * sp->m * (1 + eta) + 4.0 * k[0] * k[0] - sp->m * sp->m + 4.0 * sp->mq * sp->mq) / 2.0;



        double xcmin = 0.5 * (4 * k[0] * k[0] - sp->m * sp->m + 4 * sp->mq * sp->mq) / (sqrt(sp->Q2) * k[0]);
        if (k[1] < xcmin)
        {
            return 0;

        }
        else
        {
            //return(k[0] * k[0] * 2 * 2 * M_PI * N2 * Sp1(k0, k[0], k[1], sp->Q2, sp->m, sp->mq, sp->b) / (fk1(k0, k[0], k[1], sp->Q2, sp->m, sp->mq, sp->b)  * fk5(k0, k[0], k[1], sp->Q2, sp->m, sp->mq, sp->b)  * fk7(k0, k[0], k[1], sp->Q2, sp->m, sp->mq, sp->b)  * fk9(k0, k[0], k[1], sp->Q2, sp->m, sp->mq, sp->b)  * (2 * sp->m * sqrt(1 + eta))));
            return(k[0] * k[0] * 2 * 2 * M_PI*M_PI * sp->N * Spintres(k0, k[0], k[1], sp->Q2, sp->m, sp->mq, sp->b) / (fk1(k0, k[0], k[1], sp->Q2, sp->m, sp->mq, sp->b) * fk2(k0, k[0], k[1], sp->Q2, sp->m, sp->mq, sp->b) * fk4(k0, k[0], k[1], sp->Q2, sp->m, sp->mq, sp->b) * fk1(k0, k[0], k[1], sp->Q2, sp->m, sp->mq, sp->b + 0.00001) * fk2(k0, k[0], k[1], sp->Q2, sp->m, sp->mq, sp->b + 0.00001) * fk7(k0, k[0], k[1], sp->Q2, sp->m, sp->mq, sp->b) * fk8(k0, k[0], k[1], sp->Q2, sp->m, sp->mq, sp->b) * fk9(k0, k[0], k[1], sp->Q2, sp->m, sp->mq, sp->b) * fk10(k0, k[0], k[1], sp->Q2, sp->m, sp->mq, sp->b) * (2 * sp->m * sqrt(1 + eta)) * (2 * sp->m * sqrt(1 + eta))));
        }
    }
    //* N2 
        //* (2 * sp->m * sqrt(1 + eta))
}
double gres5(double* k, size_t dim, void* p)
{
    (void)(dim);
    struct my_f_params* sp = (struct my_f_params*)p;

    {
        double q2 = -sp->Q2;
        double eta = -q2 / (4 * sp->m * sp->m);


        // double k0 = -sqrt(1.0 + eta) * sp->m / 2.0 + sqrt(12.0 * sqrt(eta) * k[0] * k[1] * sp->m - 7.0 * sp->m * sp->m * eta
          //   + 4.0 * k[0] * k[0] + 4.0 * sp->mq * sp->mq - 4.0 * q2) / 2.0;

        double k0 = -sqrt(1.0 + eta) * sp->m / 2.0 + sqrt(6.0 * k[0] * k[1] * sqrt(sp->Q2) + (1.0 + eta) * sp->m * sp->m + 4.0 * k[0] * k[0] - sp->m * sp->m + 4.0 * sp->mq * sp->mq - 2.0 * q2) / 2.0;

        double xcmax = -(4 * k[0] * k[0] - sp->m * sp->m + 4 * sp->mq * sp->mq - 2 * q2) / (6 * sqrt(sp->Q2) * k[0]);
        if (k[1] > xcmax)
        {
            return 0;

        }
        else
        {
            //return(k[0] * k[0] * 2 * 2 * M_PI * N2 * Sp1(k0, k[0], k[1], sp->Q2, sp->m, sp->mq, sp->b) / (fk1(k0, k[0], k[1], sp->Q2, sp->m, sp->mq, sp->b)  * fk5(k0, k[0], k[1], sp->Q2, sp->m, sp->mq, sp->b)  * fk7(k0, k[0], k[1], sp->Q2, sp->m, sp->mq, sp->b)  * fk9(k0, k[0], k[1], sp->Q2, sp->m, sp->mq, sp->b)  * (2 * sp->m * sqrt(1 + eta))));
            return(k[0] * k[0] * 2 * 2 * M_PI*M_PI * sp->N * Sp1(k0, k[0], k[1], sp->Q2, sp->m, sp->mq, sp->b) / (fk1(k0, k[0], k[1], sp->Q2, sp->m, sp->mq, sp->b) * fk2(k0, k[0], k[1], sp->Q2, sp->m, sp->mq, sp->b) * fk4(k0, k[0], k[1], sp->Q2, sp->m, sp->mq, sp->b) * fk3(k0, k[0], k[1], sp->Q2, sp->m, sp->mq, sp->b) * fk6(k0, k[0], k[1], sp->Q2, sp->m, sp->mq, sp->b) * fk7(k0, k[0], k[1], sp->Q2, sp->m, sp->mq, sp->b) * fk8(k0, k[0], k[1], sp->Q2, sp->m, sp->mq, sp->b) * fk9(k0, k[0], k[1], sp->Q2, sp->m, sp->mq, sp->b) * fk10(k0, k[0], k[1], sp->Q2, sp->m, sp->mq, sp->b) * (2 * sp->m * sqrt(1 + eta))));
        }
    }
    //* N2 
        //* (2 * sp->m * sqrt(1 + eta))
}
double gres8(double* k, size_t dim, void* p)
{
    (void)(dim);
    struct my_f_params* sp = (struct my_f_params*)p;

    {
        double q2 = -sp->Q2;
        double eta = -q2 / (4 * sp->m * sp->m);

        //double k0 = sqrt(1.0 + eta) * sp->m / 2.0 + sqrt(4.0 * sqrt(eta) * k[0] * k[1] * sp->m + sp->m * sp->m * eta + 4.0
        //    * k[0] * k[0] + 4.0 * sp->mq * sp->mq - sp->m * sp->m) / 2.0;
        double k0 = +sqrt(1.0 + eta) * sp->m / 2.0 + sqrt(2.0 * k[0] * k[1] * sqrt(sp->Q2) + (1.0 + eta) * sp->m * sp->m + 4.0 * k[0] * k[0] - sp->m * sp->m + 4.0 * sp->mq * sp->mq) / 2.0;
        double xcmax = -0.5 * (4 * k[0] * k[0] - sp->m * sp->m + 4 * sp->mq * sp->mq) / (sqrt((sp->Q2)) * k[0]);
        if (k[1] > xcmax)
        {
            return 0;

        }
        else
        {
            //return(k[0] * k[0] * 2 * 2 * M_PI * N2 * Sp1(k0, k[0], k[1], sp->Q2, sp->m, sp->mq, sp->b) / (  fk2(k0, k[0], k[1], sp->Q2, sp->m, sp->mq, sp->b)  * fk4(k0, k[0], k[1], sp->Q2, sp->m, sp->mq, sp->b)  * fk6(k0, k[0], k[1], sp->Q2, sp->m, sp->mq, sp->b)   * fk10(k0, k[0], k[1], sp->Q2, sp->m, sp->mq, sp->b) * (2 * sp->m * sqrt(1 + eta))));
            return(k[0] * k[0] * 2 * 2 * M_PI* M_PI * sp->N * Sp1(k0, k[0], k[1], sp->Q2, sp->m, sp->mq, sp->b) / (fk1(k0, k[0], k[1], sp->Q2, sp->m, sp->mq, sp->b) * fk2(k0, k[0], k[1], sp->Q2, sp->m, sp->mq, sp->b) * fk3(k0, k[0], k[1], sp->Q2, sp->m, sp->mq, sp->b) * fk4(k0, k[0], k[1], sp->Q2, sp->m, sp->mq, sp->b) * fk5(k0, k[0], k[1], sp->Q2, sp->m, sp->mq, sp->b) * fk6(k0, k[0], k[1], sp->Q2, sp->m, sp->mq, sp->b) * fk8(k0, k[0], k[1], sp->Q2, sp->m, sp->mq, sp->b) * fk9(k0, k[0], k[1], sp->Q2, sp->m, sp->mq, sp->b) * fk10(k0, k[0], k[1], sp->Q2, sp->m, sp->mq, sp->b) * (2 * sp->m * sqrt(1 + eta))));
        }
    }
    //* N2
    //* (2 * sp->m * sqrt(1 + eta))
}
double gresint8(double* k, size_t dim, void* p)
{
    (void)(dim);
    struct my_f_params* sp = (struct my_f_params*)p;

    {
        double q2 = -sp->Q2;
        double eta = -q2 / (4 * sp->m * sp->m);

        //double k0 = sqrt(1.0 + eta) * sp->m / 2.0 + sqrt(4.0 * sqrt(eta) * k[0] * k[1] * sp->m + sp->m * sp->m * eta + 4.0
        //    * k[0] * k[0] + 4.0 * sp->mq * sp->mq - sp->m * sp->m) / 2.0;
        double k0 = +sqrt(1.0 + eta) * sp->m / 2.0 - sqrt(2.0 * k[0] * k[1] * sqrt(sp->Q2) + (1.0 + eta) * sp->m * sp->m + 4.0 * k[0] * k[0] - sp->m * sp->m + 4.0 * sp->mq * sp->mq) / 2.0;
        double xcmax = -0.5 * (4 * k[0] * k[0] - sp->m * sp->m + 4 * sp->mq * sp->mq) / (sqrt((sp->Q2)) * k[0]);
        if (k[1] > xcmax)
        {
            return 0;

        }
        else
        {
            //return(k[0] * k[0] * 2 * 2 * M_PI * N2 * Sp1(k0, k[0], k[1], sp->Q2, sp->m, sp->mq, sp->b) / (  fk2(k0, k[0], k[1], sp->Q2, sp->m, sp->mq, sp->b)  * fk4(k0, k[0], k[1], sp->Q2, sp->m, sp->mq, sp->b)  * fk6(k0, k[0], k[1], sp->Q2, sp->m, sp->mq, sp->b)   * fk10(k0, k[0], k[1], sp->Q2, sp->m, sp->mq, sp->b) * (2 * sp->m * sqrt(1 + eta))));
            return(k[0] * k[0] * 2 * 2 * M_PI * M_PI * sp->N * Spintres(k0, k[0], k[1], sp->Q2, sp->m, sp->mq, sp->b) / (fk1(k0, k[0], k[1], sp->Q2, sp->m, sp->mq, sp->b) * fk2(k0, k[0], k[1], sp->Q2, sp->m, sp->mq, sp->b) * fk4(k0, k[0], k[1], sp->Q2, sp->m, sp->mq, sp->b) * fk1(k0, k[0], k[1], sp->Q2, sp->m, sp->mq, sp->b + 0.00001) * fk2(k0, k[0], k[1], sp->Q2, sp->m, sp->mq, sp->b + 0.00001) * fk3(k0, k[0], k[1], sp->Q2, sp->m, sp->mq, sp->b) * fk7(k0, k[0], k[1], sp->Q2, sp->m, sp->mq, sp->b) * fk9(k0, k[0], k[1], sp->Q2, sp->m, sp->mq, sp->b) * fk10(k0, k[0], k[1], sp->Q2, sp->m, sp->mq, sp->b) * (2 * sp->m * sqrt(1 + eta)) * (2 * sp->m * sqrt(1 + eta))));

        }
    }
    //* N2
    //* (2 * sp->m * sqrt(1 + eta))
}
//double g2(double* x, size_t dim, void* params)
//{
//    (void)(dim);
//    (void)(params);
//    double* k = new double[3];
//    k[0] = x[0] / (1 - x[0]);
//    k[1] = x[1] / (1 - x[1]);
//    k[2] = x[2];
//    return real((k[1] * k[1] * 2 * 2 * M_PI * mq / ((1 - x[0]) * (1 - x[0]) * (1 - x[1]) * (1 - x[1]) * f1(k[0], k[1]) * f2(k[0], k[1], k[2])  * f4(k[0], k[1], k[2]) )));
//
//}
int main()
{


    double res, err, res8, err8, res3, err3, res5, err5;

    double xl[3] = { 0,0,-1 };
    double xu[3] = { 1,1,1 };

    const gsl_rng_type* T;
    gsl_rng* r;

    gsl_rng_env_setup();

    T = gsl_rng_default;
    r = gsl_rng_alloc(T);
    double m = 0.14;
    double mq = 0.265;
    double b = 0.403;
    double N = -0.00284119;
    for (double Q2 = 1e-8;Q2 < 10.2;Q2 += 0.2)
    {
        struct my_f_params params = { Q2,m,mq,b,N };
        double q2 = -Q2;
        double eta = -q2 / (4 * m * m);
        double kmin1 = sqrt(Q2) / 4. - sqrt(Q2 + 4 * m * m - 16 * mq * mq) / 4.;
        double kmax1 = sqrt(Q2) / 4. + sqrt(Q2 + 4 * m * m - 16 * mq * mq) / 4.;
        double kmin2 = 3 * sqrt(Q2) / 4. - sqrt(Q2 + 4 * m * m - 16 * mq * mq) / 4.;
        double kmax2 = 3 * sqrt(Q2) / 4. + sqrt(Q2 + 4 * m * m - 16 * mq * mq) / 4.;
        double xl1[2] = { kmin1,0 };
        double xu1[2] = { kmax1,1 };
        double xl2[2] = { kmin1,-1 };
        double xu2[2] = { kmax1,0 };
        double xl3[2] = { kmin2,-1 };
        double xu3[2] = { kmax2,0 };

        //if(Q2<1.4)
       /* {

            gsl_monte_vegas_state* s = gsl_monte_vegas_alloc(3);
            gsl_monte_function G = { &gup, 3,&params };
            gsl_monte_vegas_integrate(&G, xl, xu, 3, 100000, r, s,
                &res, &err);
            do
            {
                gsl_monte_vegas_integrate(&G, xl, xu, 3, 100000, r, s,
                    &res, &err);
            } while (fabs(gsl_monte_vegas_chisq(s) - 1.0) > 0.5);
            gsl_monte_vegas_free(s);
            cout << Q2 << " " << res  << endl;
        }*/
        //else
        //{
        //    gsl_monte_vegas_state* s = gsl_monte_vegas_alloc(3);
        //    gsl_monte_function G = { &gup, 3,&params };
        //    gsl_monte_vegas_integrate(&G, xl, xu, 3, 100000, r, s,
        //        &res, &err);
        //    do
        //    {
        //        gsl_monte_vegas_integrate(&G, xl, xu, 3, 100000, r, s,
        //            &res, &err);
        //    } while (fabs(gsl_monte_vegas_chisq(s) - 1.0) > 0.5);
        //    gsl_monte_vegas_free(s);
        //    {
        //        gsl_monte_vegas_state* s3 = gsl_monte_vegas_alloc(2);
        //        gsl_monte_function G3 = { &gres1, 2,&params };
        //        gsl_monte_vegas_integrate(&G3, xl1, xu1, 2, 100000, r, s3,
        //            &res3, &err3);
        //        do
        //        {
        //            gsl_monte_vegas_integrate(&G3, xl1, xu1, 2, 100000, r, s3,
        //                &res3, &err3);
        //        } while (fabs(gsl_monte_vegas_chisq(s3) - 1.0) > 0.5);
        //    }
        //    {
        //        gsl_monte_vegas_state* s5 = gsl_monte_vegas_alloc(2);
        //        gsl_monte_function G5 = { &gres5, 2,&params };
        //        gsl_monte_vegas_integrate(&G5, xl3, xu3, 2, 100000, r, s5,
        //            &res5, &err5);
        //        do
        //        {
        //            gsl_monte_vegas_integrate(&G5, xl3, xu3, 2, 100000, r, s5,
        //                &res5, &err5);
        //        } while (fabs(gsl_monte_vegas_chisq(s5) - 1.0) > 0.5);
        //    }
        //    {
        //        gsl_monte_vegas_state* s8 = gsl_monte_vegas_alloc(2);
        //        gsl_monte_function G8 = { &gres8, 2,&params };
        //        gsl_monte_vegas_integrate(&G8, xl2, xu2, 2, 100000, r, s8,
        //            &res8, &err8);
        //        do
        //        {
        //            gsl_monte_vegas_integrate(&G8, xl2, xu2, 2, 100000, r, s8,
        //                &res8, &err8);
        //        } while (fabs(gsl_monte_vegas_chisq(s8) - 1.0) > 0.5);
        //    }
        //    //cout << Q2 << " " << res<<" "<<res3<<" "<<res5<<" "<<res8 << endl;
        //    cout << Q2 << " "<< (res - res3 - res5 - res8) << endl;
        //}
       
        //{

        //    gsl_monte_vegas_state* s = gsl_monte_vegas_alloc(3);
        //    gsl_monte_function G = { &gint, 3,&params };
        //    gsl_monte_vegas_integrate(&G, xl, xu, 3, 100000, r, s,
        //        &res, &err);
        //    do
        //    {
        //        gsl_monte_vegas_integrate(&G, xl, xu, 3, 100000, r, s,
        //            &res, &err);
        //    } while (fabs(gsl_monte_vegas_chisq(s) - 1.0) > 0.5);
        //    gsl_monte_vegas_free(s);
        //    cout << Q2 << " " << 2*res <<" "<<err<< endl;
        //}
        if (Q2 < 1.4)
        {

            gsl_monte_vegas_state* s = gsl_monte_vegas_alloc(3);
            gsl_monte_function G = { &gint, 3,&params };
            gsl_monte_vegas_integrate(&G, xl, xu, 3, 100000, r, s,
                &res, &err);
            do
            {
                gsl_monte_vegas_integrate(&G, xl, xu, 3, 100000, r, s,
                    &res, &err);
            } while (fabs(gsl_monte_vegas_chisq(s) - 1.0) > 0.5);
            gsl_monte_vegas_free(s);
            cout << Q2 << " " << 2 * res << endl;
        }
        else
        {
            gsl_monte_vegas_state* s = gsl_monte_vegas_alloc(3);
            gsl_monte_function G = { &gint, 3,&params };
            gsl_monte_vegas_integrate(&G, xl, xu, 3, 100000, r, s,
                &res, &err);
            do
            {
                gsl_monte_vegas_integrate(&G, xl, xu, 3, 100000, r, s,
                    &res, &err);
            } while (fabs(gsl_monte_vegas_chisq(s) - 1.0) > 0.5);
            gsl_monte_vegas_free(s);
            {
                gsl_monte_vegas_state* s3 = gsl_monte_vegas_alloc(2);
                gsl_monte_function G3 = { &gresint1, 2,&params };
                gsl_monte_vegas_integrate(&G3, xl1, xu1, 2, 100000, r, s3,
                    &res3, &err3);
                do
                {
                    gsl_monte_vegas_integrate(&G3, xl1, xu1, 2, 100000, r, s3,
                        &res3, &err3);
                } while (fabs(gsl_monte_vegas_chisq(s3) - 1.0) > 0.5);
            }
            {
                gsl_monte_vegas_state* s8 = gsl_monte_vegas_alloc(2);
                gsl_monte_function G8 = { &gresint8, 2,&params };
                gsl_monte_vegas_integrate(&G8, xl2, xu2, 2, 100000, r, s8,
                    &res8, &err8);
                do
                {
                    gsl_monte_vegas_integrate(&G8, xl2, xu2, 2, 100000, r, s8,
                        &res8, &err8);
                } while (fabs(gsl_monte_vegas_chisq(s8) - 1.0) > 0.5);
            }
            //cout << Q2 << " " << 2*res<<" "<<2*res3<<" "<<2*res8 << endl;
            cout << Q2 << " " <<  2 * (res - res3 + res8) << endl;
        }
    }


    return 0;

}

// Запуск программы: CTRL+F5 или меню "Отладка" > "Запуск без отладки"
// Отладка программы: F5 или меню "Отладка" > "Запустить отладку"

// Советы по началу работы 
//   1. В окне обозревателя решений можно добавлять файлы и управлять ими.
//   2. В окне Team Explorer можно подключиться к системе управления версиями.
//   3. В окне "Выходные данные" можно просматривать выходные данные сборки и другие сообщения.
//   4. В окне "Список ошибок" можно просматривать ошибки.
//   5. Последовательно выберите пункты меню "Проект" > "Добавить новый элемент", чтобы создать файлы кода, или "Проект" > "Добавить существующий элемент", чтобы добавить в проект существующие файлы кода.
//   6. Чтобы снова открыть этот проект позже, выберите пункты меню "Файл" > "Открыть" > "Проект" и выберите SLN-файл.
