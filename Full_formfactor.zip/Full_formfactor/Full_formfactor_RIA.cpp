﻿// Full_formfactor.cpp : Этот файл содержит функцию "main". Здесь начинается и заканчивается выполнение программы.
//

#include<iostream>
#include<fstream>
#include <stdlib.h>
#include<cmath>
#include<complex>
#define _USE_MATH_DEFINES
#include <gsl/gsl_math.h>
#include <gsl/gsl_monte.h>
#include <gsl/gsl_monte_plain.h>
#include <gsl/gsl_monte_miser.h>
#include <gsl/gsl_monte_vegas.h>
using namespace std;

struct my_f_params { double Q2;double m;double mq;double b;double b1;double N; };
//complex<double> i_ = 0. + 1i;
//double f1_wr(double k4, double k, double Q2, double m, double mq, double b)
//{
//    double q2 = -Q2;
//    double eta = -q2 / (4 * m * m);
//    return (-k4 * k4 - k * k - b * b);
//}
//complex<double> f2_wr(double k4, double k, double costheta, double Q2, double m, double mq, double b)
//{
//    double q2 = -Q2;
//    double eta = -q2 / (4 * m * m);
//
//    return(m * m / 4 + i_ * m * sqrt(1 + eta) * k4 + m * sqrt(eta) * k * costheta - k4 * k4 - k * k - mq * mq);
//}
//complex<double> f3_wr(double k4, double k, double costheta, double Q2, double m, double mq, double b)
//{
//    double q2 = -Q2;
//    double eta = -q2 / (4 * m * m);
//
//    return(m * m / 4 - k4 * k4 - k * k + q2 + i_ * m * sqrt(1 + eta) * k4 + -3 * m * sqrt(eta) * k * costheta + m * m * 2 * eta - mq * mq);
//}
//complex<double> f4_wr(double k4, double k, double costheta, double Q2, double m, double mq, double b)
//{
//    double q2 = -Q2;
//    double eta = -q2 / (4 * m * m);
//
//    return(m * m / 4 - i_ * m * sqrt(1 + eta) * k4 - m * sqrt(eta) * k * costheta - k4 * k4 - k * k - mq * mq);
//}
//double f5_wr(double k4, double k, double costheta, double Q2, double m, double mq, double b)
//{
//    double q2 = -Q2;
//    double eta = -q2 / (4 * m * m);
//
//    return(-k4 * k4 - k * k - 2 * m * sqrt(eta) * k * costheta + q2 / 4 - b * b);
//}
//double fk1_wr(double k0, double k, double costheta, double Q2, double m, double mq, double b)
//{
//    return(k0 - sqrt(b * b + k * k));
//}
//double fk2_wr(double k0, double k, double costheta, double Q2, double m, double mq, double b)
//{
//    return(k0 + sqrt(k * k + b * b));
//}
//double fk3_wr(double k0, double k, double costheta, double Q2, double m, double mq, double b)
//{
//    double q2 = -Q2;
//    double eta = -q2 / (4 * m * m);
//    //return (k0 + 0.5 * m * eta11 - 0.5 * sqrt(m * m * eta - 4 * m*eta1*k*costheta+4*k*k+4*mq*mq));
//    return(k0 + sqrt(1.0 + eta) * m / 2.0 - sqrt(-4.0 * sqrt(eta) * k * costheta * m + m * m * eta + 4.0
//        * k * k + 4.0 * mq * mq) / 2.0
//        );
//}
//double fk4_wr(double k0, double k, double costheta, double Q2, double m, double mq, double b)
//{
//
//    double q2 = -Q2;
//    double eta = -q2 / (4 * m * m);
//    return (k0 + 0.5 * m * sqrt(1.0 + eta) + 0.5 * sqrt(m * m * eta - 4 * m * sqrt(eta) * k * costheta + 4 * k * k + 4 * mq * mq));
//}
//double fk5_wr(double k0, double k, double costheta, double Q2, double m, double mq, double b)
//{
//    double q2 = -Q2;
//    double eta = -q2 / (4 * m * m);
//    //return(k0 + 0.5 * m * eta11-0.5*sqrt(-7*m*m*eta+4*k*k-4*q2+12*m*eta1*k*costheta+4*mq*mq));
//    return(k0 + sqrt(1.0 + eta) * m / 2.0 - sqrt(12.0 * sqrt(eta) * k * costheta * m - 7.0 * m * m * eta
//        + 4.0 * k * k + 4.0 * mq * mq - 4.0 * q2) / 2.0
//        );
//}
//double fk6_wr(double k0, double k, double costheta, double Q2, double m, double mq, double b)
//{
//    double q2 = -Q2;
//    double eta = -q2 / (4 * m * m);
//    return(k0 + 0.5 * m * sqrt(1.0 + eta) + 0.5 * sqrt(-7 * m * m * eta + 4 * k * k - 4 * q2 + 12 * m * sqrt(eta) * k * costheta + 4 * mq * mq));
//}
//double fk7_wr(double k0, double k, double costheta, double Q2, double m, double mq, double b)
//{
//    double q2 = -Q2;
//    double eta = -q2 / (4 * m * m);
//    //return (k0 - 0.5 * m * eta11 - 0.5 * sqrt(m * m * eta + 4 * m * eta1 * k * costheta + 4 * k * k + 4 * mq * mq));
//    return(k0 - sqrt(1.0 + eta) * m / 2.0 - sqrt(4.0 * sqrt(eta) * k * costheta * m + m * m * eta + 4.0 *
//        k * k + 4.0 * mq * mq) / 2.0
//        );
//}
//double fk8_wr(double k0, double k, double costheta, double Q2, double m, double mq, double b)
//{
//    double q2 = -Q2;
//    double eta = -q2 / (4 * m * m);
//    return (k0 - 0.5 * m * sqrt(1.0 + eta) + 0.5 * sqrt(m * m * eta + 4 * m * sqrt(eta) * k * costheta + 4 * k * k + 4 * mq * mq));
//}
//double fk9_wr(double k0, double k, double costheta, double Q2, double m, double mq, double b)
//{
//    double q2 = -Q2;
//    double eta = -q2 / (4 * m * m);
//    //return (k0-0.5*sqrt(4*k*k+8*m*eta1*k*costheta-q2+4*b*b));
//    return(k0 - sqrt(8.0 * sqrt(eta) * k * costheta * m + 4.0 * b * b + 4.0 * k * k - q2) / 2.);
//}
//double fk10_wr(double k0, double k, double costheta, double Q2, double m, double mq, double b)
//{
//    double q2 = -Q2;
//    double eta = -q2 / (4 * m * m);
//    return (k0 + 0.5 * sqrt(4 * k * k + 8 * m * sqrt(eta) * k * costheta - q2 + 4 * b * b));
//}
//complex<double> Sp_wr(double k4, double k, double costheta, double Q2, double m, double mq, double b)
//{
//    double q2 = -Q2;
//    double eta = -q2 / (4 * m * m);
//    return(4.0 * sqrt(eta) * i_ * k4 * k * m * costheta + 2.0 * sqrt(1.0 + eta) * k4 * k4 * m + 6.0 * eta * i_ * k4 *
//        m * m + 4.0 * k4 * k4 * i_ * k4 + 4.0 * i_ * k4 * k * k + i_ * k4 * m * m + 4.0 * i_ * k4 * mq * mq + 6.0 * sqrt(1.0 + eta) * m * m * sqrt(
//            eta) * k * costheta + 6.0 * sqrt(1.0 + eta) * m * k * k + sqrt(1.0 + eta) * m * m * m / 2.0 + 6.0 * sqrt(1.0
//                + eta) * m * mq * mq
//        );
//
//}
//double Sp1_wr(double k0, double k, double costheta, double Q2, double m, double mq, double b)
//{
//    double q2 = -Q2;
//    double eta = -q2 / (4 * m * m);
//    return(4.0 * sqrt(eta) * k0 * k * m * costheta - 2.0 * sqrt(1.0 + eta) * k0 * k0 * m + 6.0 * eta * k0 *
//        m * m - 4.0 * k0 * k0 * k0 + 4.0 * k0 * k * k + k0 * m * m + 4.0 * k0 * mq * mq + 6.0 * sqrt(1.0 + eta) * m * m * sqrt(
//            eta) * k * costheta + 6.0 * sqrt(1.0 + eta) * m * k * k + sqrt(1.0 + eta) * m * m * m / 2.0 + 6.0 * sqrt(1.0
//                + eta) * m * mq * mq);
//
//
//}
//double gup_wr(double* x, size_t dim, void* p)
//{
//    (void)(dim);
//    struct my_f_params* fp = (struct my_f_params*)p;
//    double* k = new double[3];
//    double q2 = -fp->Q2;
//    double eta = -q2 / (4 * fp->m * fp->m);
//    double N2 = -0.00595952;
//
//    k[0] = x[0] / (1 - x[0]);
//    k[1] = x[1] / (1 - x[1]);
//    k[2] = x[2];
//
//    return real((k[1] * k[1] * 2 * 2 * M_PI * fp->N* Sp_wr(k[0], k[1], k[2], fp->Q2, fp->m, fp->mq, fp->b) / ((1 - x[0]) * (1 - x[0]) * (1 - x[1]) * (1 - x[1]) * f1_wr(k[0], k[1], fp->Q2, fp->m, fp->mq, fp->b) * f2_wr(k[0], k[1], k[2], fp->Q2, fp->m, fp->mq, fp->b) * f3_wr(k[0], k[1], k[2], fp->Q2, fp->m, fp->mq, fp->b) * f4_wr(k[0], k[1], k[2], fp->Q2, fp->m, fp->mq, fp->b) * f5_wr(k[0], k[1], k[2], fp->Q2, fp->m, fp->mq, fp->b) * (2 * fp->m * sqrt(1 + eta)))));
//    //Sp(k[0], k[1], k[2], fp->Q2, fp->m, fp->mq, fp->b)
//         //*fp->N
//         //* (2 * fp->m * sqrt(1 + eta))
//}
//double gres1_wr(double* k, size_t dim, void* p)
//{
//    (void)(dim);
//    struct my_f_params* sp = (struct my_f_params*)p;
//
//    {
//        double q2 = -sp->Q2;
//        double eta = -q2 / (4 * sp->m * sp->m);
//        double N2 = -0.00595952;
//
//        double k0 = -sqrt(1.0 + eta) * sp->m / 2.0 + sqrt(-4.0 * sqrt(eta) * k[0] * k[1] * sp->m + sp->m * sp->m * eta + 4.0
//            * k[0] * k[0] + 4.0 * sp->mq * sp->mq) / 2.0;
//
//
//
//        double xcmin = 0.5 * (4 * k[0] * k[0] - sp->m * sp->m + 4 * sp->mq * sp->mq) / ((sp->Q2) * k[0]);
//        if (k[1] < xcmin)
//        {
//            return 0;
//
//        }
//        else
//        {
//            return(k[0] * k[0] * 2 * 2 * M_PI * sp->N * Sp1_wr(k0, k[0], k[1], sp->Q2, sp->m, sp->mq, sp->b) / (fk1_wr(k0, k[0], k[1], sp->Q2, sp->m, sp->mq, sp->b) * fk2_wr(k0, k[0], k[1], sp->Q2, sp->m, sp->mq, sp->b) * fk4_wr(k0, k[0], k[1], sp->Q2, sp->m, sp->mq, sp->b) * fk5_wr(k0, k[0], k[1], sp->Q2, sp->m, sp->mq, sp->b) * fk6_wr(k0, k[0], k[1], sp->Q2, sp->m, sp->mq, sp->b) * fk7_wr(k0, k[0], k[1], sp->Q2, sp->m, sp->mq, sp->b) * fk8_wr(k0, k[0], k[1], sp->Q2, sp->m, sp->mq, sp->b) * fk9_wr(k0, k[0], k[1], sp->Q2, sp->m, sp->mq, sp->b) * fk10_wr(k0, k[0], k[1], sp->Q2, sp->m, sp->mq, sp->b) * (2 * sp->m * sqrt(1 + eta))));
//        }
//        //* sp->N* Sp1_wr(k0, k[0], k[1], sp->Q2, sp->m, sp->mq, sp->b)
//        //* (2 * sp->m * sqrt(1 + eta))
//    }
//
//}
//double gres8_wr(double* k, size_t dim, void* p)
//{
//    (void)(dim);
//    struct my_f_params* sp = (struct my_f_params*)p;
//
//    {
//        double q2 = -sp->Q2;
//        double eta = -q2 / (4 * sp->m * sp->m);
//        double N2 = -0.00595952;
//        double k0 = sqrt(1.0 + eta) * sp->m / 2.0 - sqrt(4.0 * sqrt(eta) * k[0] * k[1] * sp->m + sp->m * sp->m * eta + 4.0
//            * k[0] * k[0] + 4.0 * sp->mq * sp->mq - sp->m * sp->m) / 2.0;
//        double xcmax = -0.5 * (4 * k[0] * k[0] - sp->m * sp->m + 4 * sp->mq * sp->mq) / ((sp->Q2) * k[0]);
//        if (k[1] > xcmax)
//        {
//            return 0;
//
//        }
//        else
//        {
//
//            return(k[0] * k[0] * 2 * 2 * M_PI * sp->N * Sp1_wr(k0, k[0], k[1], sp->Q2, sp->m, sp->mq, sp->b) / (fk1_wr(k0, k[0], k[1], sp->Q2, sp->m, sp->mq, sp->b) * fk2_wr(k0, k[0], k[1], sp->Q2, sp->m, sp->mq, sp->b) * fk3_wr(k0, k[0], k[1], sp->Q2, sp->m, sp->mq, sp->b) * fk4_wr(k0, k[0], k[1], sp->Q2, sp->m, sp->mq, sp->b) * fk5_wr(k0, k[0], k[1], sp->Q2, sp->m, sp->mq, sp->b) * fk6_wr(k0, k[0], k[1], sp->Q2, sp->m, sp->mq, sp->b) * fk7_wr(k0, k[0], k[1], sp->Q2, sp->m, sp->mq, sp->b) * fk9_wr(k0, k[0], k[1], sp->Q2, sp->m, sp->mq, sp->b) * fk10_wr(k0, k[0], k[1], sp->Q2, sp->m, sp->mq, sp->b) * (2 * sp->m * sqrt(1 + eta))));
//        }
//        
//    }
//
//}

//////////////////////

double L = 5;
double F_f(double x1, double x2, double x3, double x4, double Q2, double m, double mq, double b)
{
    double q2 = -Q2;
    double eta = -q2 / (4 * m * m);
    double pq = m * m * 2 * eta;
    return((-1.0 + x1 + x2 + x3) * b * b + (-x2 * (1.0 - x1 - x2 - x3 - x4) - x2 * x2 - pow(1.0 - x1 - x2 - x3 - x4, 2.0) / 4.0 + 1.0 / 4.0 - x1 / 4.0 + 3.0 / 4.0 * x2 - x3 / 4.0 - x4 / 4.0) * q2 + (-x2 * x2 + x2 - x1 * x2 - x1 * (1.0 - x1 - x2 - x3 - x4) / 2.0 + x2 * x3 - x2 * (1.0 - x1 - x2 - x3 - x4) / 2.0 + x3 * (1.0 - x1 - x2 - x3 - x4) / 2.0) * pq + (-x1 - x2 - x3) * mq * mq + (x2 * x3 / 2.0 + x1 * x3 / 2.0 - x1 * x2 / 2.0 + x2 / 4.0 - x1 * x1 / 4.0 - x2 * x2 / 4.0 - x3 * x3 / 4.0 + x3 / 4.0 + x1 / 4.0) * m * m);
}
double g_f(double* k, size_t dim, void* p)
{
    (void)(dim);

    struct my_f_params* fp = (struct my_f_params*)p;
    double x1 = k[0], x2 = k[1], x3 = k[2], x4 = k[3];
    double mpi = fp->m;
    double mq = fp->mq;
    double b22 = fp->b1 * fp->b1;
    double b12 = fp->b * fp->b;
    double q2 = -fp->Q2;
    double eta = -q2 / (4 * fp->m * fp->m);
    double pq = fp->m * fp->m * 2 * eta;
    double l0 = -0.5 * (fp->m * sqrt(1 + eta) * (k[0] + k[1] - k[2]));
    double p0 = fp->m * sqrt(1 + eta);
    double pl = -0.5 * (fp->m * fp->m * (k[0] + k[1] - k[2]) + pq * (2 * k[1] + 1 - k[0] - k[1] - k[2] - k[3]));
    double ql = -0.5 * (pq * (k[0] + k[1] - k[2]) + q2 * (2 * k[1] + 1 - k[0] - k[1] - k[2] - k[3]));
    double l2 = 0.25 * (fp->m * fp->m * (k[0] + k[1] - k[2]) * (k[0] + k[1] - k[2]) + 2 * pq * (k[0] + k[1] - k[2]) * (2 * k[1] + 1 - k[0] - k[1] - k[2] - k[3]) + q2 * (2 * k[1] + 1 - k[0] - k[1] - k[2] - k[3]) * (2 * k[1] + 1 - k[0] - k[1] - k[2] - k[3]));
    double D = -(fp->mq * fp->mq - fp->m * fp->m / 4.) * (k[0] + k[1] + k[2]) + pq * k[1] + q2 * (k[1] + (1 - k[0] - k[1] - k[2] - k[3]) / 4.) - fp->b * fp->b * (k[3] + (1 - k[0] - k[1] - k[2] - k[3]));
    double kmu = l0;
    double pk = (-0.5 * (p0 * p0 * (k[0] + k[1] - k[3]) + pq * (2 * k[1] + (1 - k[0] - k[1] - k[2] - k[3]))));
    double k2 = (2 * D - (L - 1.) * l2) / (L - 3.);
    double kmuknuk2 = (l0 * (l2 + 3 * (D * D - l2) / (L - 3.)));
    double Sp = 4. * (pl * l0 + p0 * (D * D - l2) / 4.) + 4. * kmu * pq - 4. * kmuknuk2 + 3. * kmu * fp->m * fp->m + 4. * fp->mq * fp->mq * kmu - 4. * p0 * ql - 2 * p0 * pl - 6. * p0 * D * D + 0.5 * p0 * fp->m * fp->m + 6. * p0 * fp->mq * fp->mq;
    double Sp1 = +4 * pl * l0 + p0 * (D - l2)
        + l0 * (+4 * pq + 3 * fp->m * fp->m + 4 * fp->mq * fp->mq)
        - 4 * l0 * (l2 + 3. * (D - l2) / 2)
        + p0 * (-4 * ql - 2 * pl)
        - 6 * p0 * (D)
        +p0 * (+1. / 2 * fp->m * fp->m + 6 * fp->mq * fp->mq);
    if (k[1] > 1 - k[0])
    {
        return 0;
    }
    if (k[2] > 1 - k[0] - k[1])
    {
        return 0;
    }
    if (k[3] > 1 - k[0] - k[1] - k[2])
    {
        return 0;
    }

    else
    {
        //return (2 * M_PI * M_PI*fp->N * Sp1 / F_f(k[0], k[1], k[2], k[3], fp->Q2, fp->m, fp->mq, fp->b) / F_f(k[0], k[1], k[2], k[3], fp->Q2, fp->m, fp->mq, fp->b) / F_f(k[0], k[1], k[2], k[3], fp->Q2, fp->m, fp->mq, fp->b)/ (2 * fp->m * sqrt(1 + eta)));
       /* return (2 * M_PI * M_PI * fp->N*(-9.0 * mpi * (-1.0 + x1 + x2 + x3 + x4) * ((x3 * x3 * x3 / 12.0 + (1.0 / 6.0 - x1 / 4.0 - x2 / 4.0) *
            x3 * x3 + (x2 * x2 / 4.0 + (x1 / 2.0 + 1.0 / 6.0) * x2 + x1 * x1 / 4.0 + x1 / 6.0 + 1.0 / 12.0) * x3 - (x2 * x2 + (2.0 *
                x1 + 5.0) * x2 + x1 * x1 + 5.0 * x1 - 4.0) * (x2 - 1.0 + x1) / 12.0) * mpi * mpi - (x1 + x4 / 2.0) * (-x2 - 1.0 + x1 +
                    x3 + x4) * (x1 + x2 - x3 - 7.0) * q2 / 6.0 + (-mq * mq + b22) * x3 * x3 + ((x4 + 2.0 / 3.0) * b22 - 3.0 * mq * mq - b12
                        * x4) * x3 - (x1 + x2 - 5.0 / 3.0) * (x1 + x2 + x4 - 1.0) * b22 + mq * mq * x2 * x2 + ((2.0 * x1 - 1.0 / 3.0) * mq * mq +
                            b12 * x4) * x2 + (-4.0 + x1 * x1 - x1 / 3.0) * mq * mq + x4 * b12 * (x1 - 5.0 / 3.0)) * x4 * sqrt((4.0 * mpi * mpi -
                                q2) / (mpi * mpi)) / pow((x3 * x3 / 4.0 + (-x1 / 2.0 - x2 / 2.0 - 1.0 / 4.0) * x3 + (x1 + x2) * (x2 - 1.0 + x1) /
                                    4.0) * mpi * mpi + (x1 + x4 / 2.0) * (-x2 - 1.0 + x1 + x3 + x4) * q2 / 2.0 + (mq * mq - b22) * x3 + (-x1 - x2 - x4 +
                                        1.0) * b22 + mq * mq * x1 + mq * mq * x2 + b12 * x4, 5.0))/ (2 * fp->m * sqrt(1 + eta)));*/
       // return (2 * M_PI * M_PI * fp->N * Sp1 / (D - l2) / (D - l2) / (D - l2) / (2 * fp->m * sqrt(1 + eta)));
        return ( Sp1 / (D - l2) / (D - l2) / (D - l2)/ (2 * fp->m * sqrt(1 + eta)));
    }
    //2 * M_PI * M_PI * N21 * Sp1
    //N21*Sp1
    //* (2 * fp->m * sqrt(1 + eta))
}

///////////////////////////////////

long double f1_res(double k0, double k, double costheta, double Q2, double m, double mq, double b)
{
    double q2 = -Q2;
    double eta = -q2 / (4 * m * m);
    return(k0 + m * sqrt(1 + eta) / 2.0 - sqrt(m * m * (1 + eta) + 4.0 * k * costheta * m * sqrt(eta) + 4.0 * b * b + 4.0 * k * k - m *
        m) / 2.0
        );
}
long double f2_res(double k0, double k, double costheta, double Q2, double m, double mq, double b)
{
    double q2 = -Q2;
    double eta = -q2 / (4 * m * m);
    return(k0 + m * sqrt(1 + eta) / 2.0 + sqrt(m * m * (1 + eta) + 4.0 * k * costheta * m * sqrt(eta) + 4.0 * b * b + 4.0 * k * k - m *
        m) / 2.0
        );
}
long double f3_res(double k0, double k, double costheta, double Q2, double m, double mq, double b)
{
    double q2 = -Q2;
    double eta = -q2 / (4 * m * m);
    return(k0 + m * sqrt(1 + eta) / 2.0 - sqrt((1 + eta) * m * m - 4.0 * k * costheta * m * sqrt(eta) + 4.0 * b * b + 4.0 * k * k - m *
        m) / 2.0
        );
}
long double f4_res(double k0, double k, double costheta, double Q2, double m, double mq, double b)
{
    double q2 = -Q2;
    double eta = -q2 / (4 * m * m);
    return(k0 + m * sqrt(1 + eta) / 2.0 + sqrt((1 + eta) * m * m - 4.0 * k * costheta * m * sqrt(eta) + 4.0 * b * b + 4.0 * k * k - m *
        m) / 2.0
        );
}
long double f5_res(double k0, double k, double costheta, double Q2, double m, double mq, double b)
{
    double q2 = -Q2;
    double eta = -q2 / (4 * m * m);
    return(k0 + m * sqrt(1 + eta) - sqrt((1 + eta) * m * m + 2.0 * k * costheta * m * sqrt(eta) + k * k - m * m + mq * mq));

}
long double f6_res(double k0, double k, double costheta, double Q2, double m, double mq, double b)
{
    double q2 = -Q2;
    double eta = -q2 / (4 * m * m);
    return(k0 + m * sqrt(1 + eta) + sqrt((1 + eta) * m * m + 2.0 * k * costheta * m * sqrt(eta) + k * k - m * m + mq * mq));

}
long double f7_res(double k0, double k, double costheta, double Q2, double m, double mq, double b)
{
    double q2 = -Q2;
    double eta = -q2 / (4 * m * m);
    return(k0 + m * sqrt(1 + eta) - sqrt((1 + eta) * m * m - 2.0 * k * costheta * m * sqrt(eta) + k * k - m * m + mq * mq));

}
long double f8_res(double k0, double k, double costheta, double Q2, double m, double mq, double b)
{
    double q2 = -Q2;
    double eta = -q2 / (4 * m * m);
    return(k0 + m * sqrt(1 + eta) + sqrt((1 + eta) * m * m - 2.0 * k * costheta * m * sqrt(eta) + k * k - m * m + mq * mq));

}
long double f9_res(double k0, double k, double costheta, double Q2, double m, double mq, double b)
{
    double q2 = -Q2;
    double eta = -q2 / (4 * m * m);
    return(k0 - sqrt(k * k + mq * mq));

}
long double f10_res(double k0, double k, double costheta, double Q2, double m, double mq, double b)
{
    double q2 = -Q2;
    double eta = -q2 / (4 * m * m);
    return(k0 + sqrt(k * k + mq * mq));
}

double Sp_res(double k0, double k, double costheta, double Q2, double m, double mq, double b)
{
    double q2 = -Q2;
    double eta = -q2 / (4 * m * m);
    double pk = m * sqrt(1 + eta) * k0 + m * sqrt(eta) * k * costheta;
    double pq = m * m * 2 * eta;
    double kq = -m * 2 * sqrt(eta) * k * costheta;
    double kk = k0 * k0 - k * k;
    return(k0 * (4 * pk + 4 * pq - 4 * kk + 3 * m * m + 4 * mq * mq) + m * sqrt(1 + eta) * (-4 * kq - 2 * pk - 6 * kk + 0.5 * m * m + 6 * mq * mq));
     //return(k0 * (8.0 * m * m * sqrt(eta) * sqrt(eta) + 4.0 * k * costheta * m * sqrt(eta) + 4.0 * k0 * m * sqrt(eta + 1) + 4.0 * k * k - 4.0 * k0 * k0
     //+ 3.0 * m * m + 4.0 * mq * mq) + m * sqrt(1 + eta) * (6.0 * k * costheta * m * sqrt(eta) - 2.0 * k0 * m * sqrt(1 + eta) + 6.0 * k * k - 6.0 * k0 * k0
     //    + m * m / 2.0 + 6.0 * mq * mq)
     //);
  /*  return (4.0 * sqrt(eta) * k0 * k * m * costheta - 2.0 * sqrt(1.0 + eta) * k0 * k0 * m + 6.0 * eta * k0 *
        m * m - 4.0 * k0 * k0 * k0 + 4.0 * k0 * k * k + k0 * m * m + 4.0 * k0 * mq * mq + 6.0 * sqrt(1.0 + eta) * m * m * sqrt(
            eta) * k * costheta + 6.0 * sqrt(1.0 + eta) * m * k * k + sqrt(1.0 + eta) * m * m * m / 2.0 + 6.0 * sqrt(1.0
                + eta) * m * mq * mq);*/
             //    return(4.0 * sqrt(eta) * i_ * k4 * k * m * costheta + 2.0 * sqrt(1.0 + eta) * k4 * k4 * m + 6.0 * eta * i_ * k4 *
            //        m * m + 4.0 * k4 * k4 * i_ * k4 + 4.0 * i_ * k4 * k * k + i_ * k4 * m * m + 4.0 * i_ * k4 * mq * mq + 6.0 * sqrt(1.0 + eta) * m * m * sqrt(
            //            eta) * k * costheta + 6.0 * sqrt(1.0 + eta) * m * k * k + sqrt(1.0 + eta) * m * m * m / 2.0 + 6.0 * sqrt(1.0
            //                + eta) * m * mq * mq
            //        );
                   //return(4.0 * sqrt(eta) * k0 * k * m * costheta -2.0 * sqrt(1.0 + eta) * k0 * k0 * m + 6.0 * eta  * k0 *
                   // m * m - 4.0 * k0 * k0 * k0 + 4.0  * k0 * k * k + k0 * m * m + 4.0  * k0 * mq * mq + 6.0 * sqrt(1.0 + eta) * m * m * sqrt(
                   //     eta) * k * costheta + 6.0 * sqrt(1.0 + eta) * m * k * k + sqrt(1.0 + eta) * m * m * m / 2.0 + 6.0 * sqrt(1.0
                   //         + eta) * m * mq * mq
                   //);
}

double sum_res(double* k, size_t dim, void* params)
{
    (void)(dim);
    struct my_f_params* fp = (struct my_f_params*)params;
    //double* k = new double[2];
    //k[0] = x[0] / (1 - x[0]);
    //k[1] = x[1];
    double q2 = -fp->Q2;
    double eta = -q2 / (4 * fp->m * fp->m);
    double N21 = -0.00596821;
    double N22 = -0.0175172;
    double N23 = -0.00325021;

    double k01 = -fp->m * sqrt(1 + eta) / 2.0 + sqrt(fp->m * fp->m * (1 + eta) + 4.0 * k[0] * k[1] * fp->m * sqrt(eta) + 4.0 * fp->b * fp->b + 4.0 * k[0] * k[0] - fp->m *
        fp->m) / 2.0;
    double pk1 = fp->m * sqrt(1 + eta) * k01+ fp->m * sqrt(eta) * k[0] * k[1];
    double pq1 = fp->m * fp->m * 2 * eta;
    double kq1 = -fp->m * 2 * sqrt(eta) * k[0] * k[1];
    double kk1 = k01 * k01 - k[0] * k[0];
   double num1 = k01 * (4 * pk1 + 4 * pq1 - 4 * kk1 + 3 * fp->m * fp->m + 4 * fp->mq * fp->mq) + fp->m * sqrt(1 + eta) * (-4 * kq1 - 2 * pk1 - 6 * kk1 + 05 * fp->m * fp->m + 6 * fp->mq * fp->mq);
    /*double num1= k01 * (8.0 * eta  * fp->m * fp->m + 4.0 * sqrt(eta) * k[0]*k[1] * fp->m + 4.0 * sqrt(1+eta) * k01 * fp->m + 4.0 * (k01 * k01 - k[0] * k[0]) - 4.0 * k01 * k01
        + 3.0 * fp->m * fp->m + 4.0 * fp->mq * fp->mq) + fp->m * sqrt(1+eta) * (6.0 * sqrt(eta) * k[0]*k[1] * fp->m - 2.0 * sqrt(1+eta) * k01 * fp->m + 6.0 * (k01 * k01 - k[0] * k[0]) - 6.0 * k01 * k01
            + fp->m * fp->m / 2.0 + 6.0 * fp->mq * fp->mq);*/
    long double res1 = (4 * M_PI * k[0] * k[0]*num1 / ((f2_res(k01, k[0], k[1], fp->Q2, fp->m, fp->mq, fp->b) * f3_res(k01, k[0], k[1], fp->Q2, fp->m, fp->mq, fp->b) * f4_res(k01, k[0], k[1], fp->Q2, fp->m, fp->mq, fp->b) * f5_res(k01, k[0], k[1], fp->Q2, fp->m, fp->mq, fp->b) * f6_res(k01, k[0], k[1], fp->Q2, fp->m, fp->mq, fp->b) * f7_res(k01, k[0], k[1], fp->Q2, fp->m, fp->mq, fp->b) * f8_res(k01, k[0], k[1], fp->Q2, fp->m, fp->mq, fp->b) * f9_res(k01, k[0], k[1], fp->Q2, fp->m, fp->mq, fp->b) * f10_res(k01, k[0], k[1], fp->Q2, fp->m, fp->mq, fp->b))));
    
    double k03 = -fp->m * sqrt(1 + eta) / 2.0 + sqrt((1 + eta) * fp->m * fp->m - 4.0 * k[0] * k[1] * fp->m * sqrt(eta) + 4.0 * fp->b * fp->b + 4.0 * k[0] * k[0] - fp->m *
        fp->m) / 2.0;
    double pk3 = fp->m * sqrt(1 + eta) * k03 + fp->m * sqrt(eta) * k[0] * k[1];
    double pq3 = fp->m * fp->m * 2 * eta;
    double kq3 = -fp->m * 2 * sqrt(eta) * k[0] * k[1];
    double kk3 = k03 * k03 - k[0] * k[0];
    double num3 = k03 * (4 * pk3 + 4 * pq3 - 4 * kk3 + 3 * fp->m * fp->m + 4 * fp->mq * fp->mq) + fp->m * sqrt(1 + eta) * (-4 * kq3 - 2 * pk3 - 6 * kk3 + 05 * fp->m * fp->m + 6 * fp->mq * fp->mq);
  /*  double num3 = k03 * (8.0 * eta * fp->m * fp->m + 4.0 * sqrt(eta) * k[0] * k[1] * fp->m + 4.0 * sqrt(1 + eta) * k03 * fp->m + 4.0 * (k03 * k03 - k[0] * k[0]) - 4.0 * k03 * k03
        + 3.0 * fp->m * fp->m + 4.0 * fp->mq * fp->mq) + fp->m * sqrt(1 + eta) * (6.0 * sqrt(eta) * k[0] * k[1] * fp->m - 2.0 * sqrt(1 + eta) * k03 * fp->m + 6.0 * (k03 * k03 - k[0] * k[0]) - 6.0 * k03 * k03
            + fp->m * fp->m / 2.0 + 6.0 * fp->mq * fp->mq);*/
    long double res3 = (4 * M_PI * k[0] * k[0]*num3 / ( f2_res(k03, k[0], k[1], fp->Q2, fp->m, fp->mq, fp->b) * f1_res(k03, k[0], k[1], fp->Q2, fp->m, fp->mq, fp->b) * f4_res(k03, k[0], k[1], fp->Q2, fp->m, fp->mq, fp->b) * f5_res(k03, k[0], k[1], fp->Q2, fp->m, fp->mq, fp->b) * f6_res(k03, k[0], k[1], fp->Q2, fp->m, fp->mq, fp->b) * f7_res(k03, k[0], k[1], fp->Q2, fp->m, fp->mq, fp->b) * f8_res(k03, k[0], k[1], fp->Q2, fp->m, fp->mq, fp->b) * f9_res(k03, k[0], k[1], fp->Q2, fp->m, fp->mq, fp->b) * f10_res(k03, k[0], k[1], fp->Q2, fp->m, fp->mq, fp->b)));
    
    double k05 = -fp->m * sqrt(1 + eta) + sqrt((1 + eta) * fp->m * fp->m + 2.0 * k[0] * k[1] * fp->m * sqrt(eta) + k[0] * k[0] - fp->m * fp->m + fp->mq * fp->mq);
    double pk5 = fp->m * sqrt(1 + eta) * k05 + fp->m * sqrt(eta) * k[0] * k[1];
    double pq5 = fp->m * fp->m * 2 * eta;
    double kq5 = -fp->m * 2 * sqrt(eta) * k[0] * k[1];
    double kk5 = k05 * k05 - k[0] * k[0];
    double num5 = k05 * (4 * pk5 + 4 * pq5 - 4 * kk5 + 3 * fp->m * fp->m + 4 * fp->mq * fp->mq) + fp->m * sqrt(1 + eta) * (-4 * kq5 - 2 * pk5 - 6 * kk5 + 05 * fp->m * fp->m + 6 * fp->mq * fp->mq);
    /*double num5 = k05 * (8.0  * eta * fp->m * fp->m + 4.0 * sqrt(eta) * k[0] * k[1] * fp->m + 4.0 * sqrt(1 + eta) * k05 * fp->m + 4.0 * (k05 * k05 - k[0] * k[0]) - 4.0 * k05 * k05
        + 3.0 * fp->m * fp->m + 4.0 * fp->mq * fp->mq) + fp->m * sqrt(1 + eta) * (6.0 * sqrt(eta) * k[0] * k[1] * fp->m - 2.0 * sqrt(1 + eta) * k05 * fp->m + 6.0 * (k05 * k05 - k[0] * k[0]) - 6.0 * k05 * k05
            + fp->m * fp->m / 2.0 + 6.0 * fp->mq * fp->mq);*/
    long double res5 = (4 * M_PI * k[0] * k[0]*num5 / ( f2_res(k05, k[0], k[1], fp->Q2, fp->m, fp->mq, fp->b) * f3_res(k05, k[0], k[1], fp->Q2, fp->m, fp->mq, fp->b) * f4_res(k05, k[0], k[1], fp->Q2, fp->m, fp->mq, fp->b) * f1_res(k05, k[0], k[1], fp->Q2, fp->m, fp->mq, fp->b) * f6_res(k05, k[0], k[1], fp->Q2, fp->m, fp->mq, fp->b) * f7_res(k05, k[0], k[1], fp->Q2, fp->m, fp->mq, fp->b) * f8_res(k05, k[0], k[1], fp->Q2, fp->m, fp->mq, fp->b) * f9_res(k05, k[0], k[1], fp->Q2, fp->m, fp->mq, fp->b) * f10_res(k05, k[0], k[1], fp->Q2, fp->m, fp->mq, fp->b)));
   
    double k07 = -fp->m * sqrt(1 + eta) + sqrt((1 + eta) * fp->m * fp->m - 2.0 * k[0] * k[1] * fp->m * sqrt(eta) + k[0] * k[0] - fp->m * fp->m + fp->mq * fp->mq);
    double pk7 = fp->m * sqrt(1 + eta) * k07 + fp->m * sqrt(eta) * k[0] * k[1];
    double pq7 = fp->m * fp->m * 2 * eta;
    double kq7 = -fp->m * 2 * sqrt(eta) * k[0] * k[1];
    double kk7 = k07 * k07 - k[0] * k[0];
    double num7 = k07 * (4 * pk7 + 4 * pq7 - 4 * kk7 + 3 * fp->m * fp->m + 4 * fp->mq * fp->mq) + fp->m * sqrt(1 + eta) * (-4 * kq7 - 2 * pk7 - 6 * kk7 + 05 * fp->m * fp->m + 6 * fp->mq * fp->mq);
    /*double num7 = k07 * (8.0  * eta * fp->m * fp->m + 4.0 * sqrt(eta) * k[0] * k[1] * fp->m + 4.0 * sqrt(1 + eta) * k07 * fp->m + 4.0 * (k07 * k07 - k[0] * k[0]) - 4.0 * k07 * k07
        + 3.0 * fp->m * fp->m + 4.0 * fp->mq * fp->mq) + fp->m * sqrt(1 + eta) * (6.0 * sqrt(eta) * k[0] * k[1] * fp->m - 2.0 * sqrt(1 + eta) * k07 * fp->m + 6.0 * (k01 * k01 - k[0] * k[0]) - 6.0 * k07 * k07
            + fp->m * fp->m / 2.0 + 6.0 * fp->mq * fp->mq);*/
    long double res7 = (4 * M_PI * k[0] * k[0]*num7 / ( f2_res(k07, k[0], k[1], fp->Q2, fp->m, fp->mq, fp->b) * f3_res(k07, k[0], k[1], fp->Q2, fp->m, fp->mq, fp->b) * f4_res(k07, k[0], k[1], fp->Q2, fp->m, fp->mq, fp->b) * f5_res(k07, k[0], k[1], fp->Q2, fp->m, fp->mq, fp->b) * f6_res(k07, k[0], k[1], fp->Q2, fp->m, fp->mq, fp->b) * f1_res(k07, k[0], k[1], fp->Q2, fp->m, fp->mq, fp->b) * f8_res(k07, k[0], k[1], fp->Q2, fp->m, fp->mq, fp->b) * f9_res(k07, k[0], k[1], fp->Q2, fp->m, fp->mq, fp->b) * f10_res(k07, k[0], k[1], fp->Q2, fp->m, fp->mq, fp->b)));
    
    double k09 = sqrt(k[0] * k[0] + fp->mq * fp->mq);
    double pk9 = fp->m * sqrt(1 + eta) * k09 + fp->m * sqrt(eta) * k[0] * k[1];
    double pq9= fp->m * fp->m * 2 * eta;
    double kq9 = -fp->m * 2 * sqrt(eta) * k[0] * k[1];
    double kk9 = k09 * k09 - k[0] * k[0];
    double num9 = k09 * (4 * pk9 + 4 * pq9 - 4 * kk9 + 3 * fp->m * fp->m + 4 * fp->mq * fp->mq) + fp->m * sqrt(1 + eta) * (-4 * kq9 - 2 * pk9 - 6 * kk9 + 05 * fp->m * fp->m + 6 * fp->mq * fp->mq);
   /* double num9 = k09 * (8.0  * eta * fp->m * fp->m + 4.0 * sqrt(eta) * k[0] * k[1] * fp->m + 4.0 * sqrt(1 + eta) * k09 * fp->m + 4.0 * (k09 * k09 - k[0] * k[0]) - 4.0 * k09 * k09
        + 3.0 * fp->m * fp->m + 4.0 * fp->mq * fp->mq) + fp->m * sqrt(1 + eta) * (6.0 * sqrt(eta) * k[0] * k[1] * fp->m - 2.0 * sqrt(1 + eta) * k09 * fp->m + 6.0 * (k09 * k09 - k[0] * k[0]) - 6.0 * k09 * k09
            + fp->m * fp->m / 2.0 + 6.0 * fp->mq * fp->mq);*/
    long double res9 = (4 * M_PI * k[0] * k[0]*num9 / ( f2_res(k09, k[0], k[1], fp->Q2, fp->m, fp->mq, fp->b) * f3_res(k09, k[0], k[1], fp->Q2, fp->m, fp->mq, fp->b) * f4_res(k09, k[0], k[1], fp->Q2, fp->m, fp->mq, fp->b) * f5_res(k09, k[0], k[1], fp->Q2, fp->m, fp->mq, fp->b) * f6_res(k09, k[0], k[1], fp->Q2, fp->m, fp->mq, fp->b) * f7_res(k09, k[0], k[1], fp->Q2, fp->m, fp->mq, fp->b) * f8_res(k09, k[0], k[1], fp->Q2, fp->m, fp->mq, fp->b) * f1_res(k09, k[0], k[1], fp->Q2, fp->m, fp->mq, fp->b) * f10_res(k09, k[0], k[1], fp->Q2, fp->m, fp->mq, fp->b)));
    
    return(-2 * M_PI *fp->N *(res1 + res3 + res5 + res7 + res9) / (2 * fp->m * sqrt(1 + eta)));
    //(1 - x[0])* (1 - x[0])*
    /// (2 * fp->m * sqrt(1 + eta))
    //*Sp_res(k01,k[0],k[1],fp->Q2,fp->m,fp->mq,fp->b)*fp->N 
}

double g_fpk(double* k, size_t dim, void* p)
{
    (void)(dim);

    struct my_f_params* fp = (struct my_f_params*)p;
    double x1 = k[0], x2 = k[1], x3 = k[2], x4 = k[3];
    double mpi = fp->m;
    double alpha = -0.15;
    double mq = fp->mq;
    double b22 = fp->b1 * fp->b1;
    double b12 = fp->b * fp->b;
    double q2 = -fp->Q2;
    double eta = -q2 / (4 * fp->m * fp->m);
    double pq = fp->m * fp->m * 2 * eta;
    double l0 = (-x4 * alpha / 2.0 - alpha * (1-x1-x2-x3-x4) / 2.0 - x1 / 2.0 - x2 / 2.0 + x3 / 2.0) * fp->m * sqrt(1.0 + eta);
    double p0 = fp->m * sqrt(1 + eta);
    double pl = fp->m * fp->m * (-x4 * alpha / 2.0 - alpha * (1.0 - x1 - x2 - x3 - x4) / 2.0 - x1 / 2.0 - x2 / 2.0 + x3 / 2.0)
        + 2.0 * fp->m * fp->m * eta * (-x2 / 2.0 - 1.0 / 2.0 + x1 / 2.0 + x3 / 2.0 + x4 / 2.0);

    double ql = 2.0 * fp->m * fp->m * eta * (-x4 * alpha / 2.0 - alpha * (1.0 - x1 - x2 - x3 - x4) / 2.0 - x1 / 2.0 - x2 / 2.0
        + x3 / 2.0) + q2 * (-x2 / 2.0 - 1.0 / 2.0 + x1 / 2.0 + x3 / 2.0 + x4 / 2.0);

    double l2 = fp->m * fp->m * pow(-alpha * x4 / 2.0 - (1.0 - x1 - x2 - x3 - x4) * alpha / 2.0 - x1 / 2.0 - x2 / 2.0 + x3 /
        2.0, 2.0) + 2.0 * pq * (-x2 / 2.0 - 1.0 / 2.0 + x1 / 2.0 + x3 / 2.0 + x4 / 2.0) * (-alpha * x4 / 2.0 - (1.0 - x1 -
            x2 - x3 - x4) * alpha / 2.0 - x1 / 2.0 - x2 / 2.0 + x3 / 2.0) + q2 * pow(-x2 / 2.0 - 1.0 / 2.0 + x1 / 2.0 + x3 / 2.0 +
                x4 / 2.0, 2.0);




    double D = (-1.0 + x1 + x2 + x3) * fp->b * fp->b + (-x1 - x2 - x3) * mq * mq + (x1 / 4.0 + x2 / 4.0 + x3 / 4.0) * fp->m * fp->m + x2 *
        pq + x2 * q2 + (1.0 - x1 - x2 - x3 - x4) * q2 / 4.0;

   

    double Sp1 = +4 * pl * l0 + p0 * (D - l2)
        + l0 * (+4 * pq + 3 * fp->m * fp->m + 4 * fp->mq * fp->mq)
        - 4 * l0 * (l2 + 3. * (D - l2) / 2)
        + p0 * (-4 * ql - 2 * pl)
        - 6 * p0 * (D)
        +p0 * (+1. / 2 * fp->m * fp->m + 6 * fp->mq * fp->mq);
    if (k[1] > 1 - k[0])
    {
        return 0;
    }
    if (k[2] > 1 - k[0] - k[1])
    {
        return 0;
    }
    if (k[3] > 1 - k[0] - k[1] - k[2])
    {
        return 0;
    }

    else
    {
        return (2 * M_PI * M_PI * fp->N*Sp1 / (D - l2) / (D - l2) / (D - l2)/ (2 * fp->m * sqrt(1 + eta)));
    }
    //2 * M_PI * M_PI * N21 * Sp1
    //N21*Sp1
    //* (2 * fp->m * sqrt(1 + eta))
}
//////////////////////////////////////

int main()
{


    double xl_wr[3] = { 0,0,-1 };
    double xu_wr[3] = { 1,1,1 };
    double res_f, err_f;
    double xl_f[4] = { 0,0,0,0 };
    double xu_f[4] = { 1,1,1,1 };
    double res1_res, err1_res;

    double xl1_res[2] = { 0,0 };
    double xu1_res[2] = { 5,1 };
    const gsl_rng_type* T;
    gsl_rng* r;

    gsl_rng_env_setup();

    T = gsl_rng_default;
    r = gsl_rng_alloc(T);
    double m = 0.14;
    double mq = 0.26;
    double b = 0.55;
    double b1 = 0.550001;
    double N21 = -0.00596118;//4.69579e-07
    double N22 = -0.0174739;//2.00517e-06
    double N23 = -0.00324541;//3.87599e-07
    double N24 = -0.00284119;
    double N25 = -0.0033686;
    double N26 = -0.0496939;
    double N27 = -0.0104346;
    double N28 = -0.00613619;
    double Npk1 = -0.00599878;
    ofstream file("res.txt");
    //for (double Q2 = 1e-8;Q2 <10.2;Q2+=0.5)
    {
       struct my_f_params params = { 2,m,mq,b,b1,N28};
        double q2 = -2;
        double eta = -q2 / (4 * m * m);

        {

            gsl_monte_vegas_state* s_f = gsl_monte_vegas_alloc(4);
            gsl_monte_function G_f = { &g_f, 4,&params };
            gsl_monte_vegas_integrate(&G_f, xl_f, xu_f, 4, 1000000, r, s_f,
                &res_f, &err_f);
            do
            {
                gsl_monte_vegas_integrate(&G_f, xl_f, xu_f, 4, 1000000, r, s_f,
                    &res_f, &err_f);
            } while (fabs(gsl_monte_vegas_chisq(s_f) - 1.0) > 0.5);
            cout<<res_f <<" " <<err_f<<endl ;
        }
        //{

        //    gsl_monte_vegas_state* s_res = gsl_monte_vegas_alloc(2);
        //    gsl_monte_function G_res = { &sum_res, 2,&params };
        //    gsl_monte_vegas_integrate(&G_res, xl1_res, xu1_res, 2, 10000, r, s_res,
        //        &res1_res, &err1_res);
        //    do
        //    {
        //        gsl_monte_vegas_integrate(&G_res, xl1_res, xu1_res, 2, 10000, r, s_res,
        //            &res1_res, &err1_res);
        //    } while (fabs(gsl_monte_vegas_chisq(s_res) - 1.0) > 0.5);

        //    file<< Q2 << " " << res1_res << endl;
        //}
 
    }
   // double m2 = 0.14;
   // double mq2 = 0.3;
   // double b2 = 0.75;
   // double b12 = 0.75001;

   // for (double Q2 = 1e-5;Q2 < 30.2;Q2 += 0.5)
   // {
   //     struct my_f_params params = { Q2,m2,mq2,b2,b12,N22 };
   //     double q2 = -Q2;
   //     double eta = -q2 / (4 * m * m);

   //     {

   //         gsl_monte_vegas_state* s_f = gsl_monte_vegas_alloc(4);
   //         gsl_monte_function G_f = { &g_f, 4,&params };
   //         gsl_monte_vegas_integrate(&G_f, xl_f, xu_f, 4, 1000000, r, s_f,
   //             &res_f, &err_f);
   //         do
   //         {
   //             gsl_monte_vegas_integrate(&G_f, xl_f, xu_f, 4, 1000000, r, s_f,
   //                 &res_f, &err_f);
   //         } while (fabs(gsl_monte_vegas_chisq(s_f) - 1.0) > 0.5);
   //         file  << Q2 << " " << res_f<<endl;
   //     }
   //     //{

   //     //    gsl_monte_vegas_state* s_res = gsl_monte_vegas_alloc(2);
   //     //    gsl_monte_function G_res = { &sum_res, 2,&params };
   //     //    gsl_monte_vegas_integrate(&G_res, xl1_res, xu1_res, 2, 10000, r, s_res,
   //     //        &res1_res, &err1_res);
   //     //    do
   //     //    {
   //     //        gsl_monte_vegas_integrate(&G_res, xl1_res, xu1_res, 2, 10000, r, s_res,
   //     //            &res1_res, &err1_res);
   //     //    } while (fabs(gsl_monte_vegas_chisq(s_res) - 1.0) > 0.5);

   //     //    file << " " << Q2 << " " << res1_res << endl;
   //     //    //file<< Q2 << " " << res1_res << endl;
   //     //}

   //}
   // double m3 = 0.14;
   // double mq3 = 0.2;
   // double b3 = 0.5;
   // double b13 = 0.50001;

   // for (double Q2 = 1e-5;Q2 < 30.2;Q2 += 0.5)
   // {
   //     struct my_f_params params = { Q2,m3,mq3,b3,b13,N23 };
   //     double q2 = -Q2;
   //     double eta = -q2 / (4 * m * m);

   //     {

   //         gsl_monte_vegas_state* s_f = gsl_monte_vegas_alloc(4);
   //         gsl_monte_function G_f = { &g_f, 4,&params };
   //         gsl_monte_vegas_integrate(&G_f, xl_f, xu_f, 4, 1000000, r, s_f,
   //             &res_f, &err_f);
   //         do
   //         {
   //             gsl_monte_vegas_integrate(&G_f, xl_f, xu_f, 4, 1000000, r, s_f,
   //                 &res_f, &err_f);
   //         } while (fabs(gsl_monte_vegas_chisq(s_f) - 1.0) > 0.5);
   //         file << Q2 << " " << res_f<<endl;
   //     }
   //     //{

   //     //    gsl_monte_vegas_state* s_res = gsl_monte_vegas_alloc(2);
   //     //    gsl_monte_function G_res = { &sum_res, 2,&params };
   //     //    gsl_monte_vegas_integrate(&G_res, xl1_res, xu1_res, 2, 10000, r, s_res,
   //     //        &res1_res, &err1_res);
   //     //    do
   //     //    {
   //     //        gsl_monte_vegas_integrate(&G_res, xl1_res, xu1_res, 2, 10000, r, s_res,
   //     //            &res1_res, &err1_res);
   //     //    } while (fabs(gsl_monte_vegas_chisq(s_res) - 1.0) > 0.5);

   //     //    file << " " << Q2 << " " << res1_res << endl;
   //     //    //file<< Q2 << " " << res1_res << endl;
   //     //}

   // }
    file.close();
    return 0;
}

// Запуск программы: CTRL+F5 или меню "Отладка" > "Запуск без отладки"
// Отладка программы: F5 или меню "Отладка" > "Запустить отладку"

// Советы по началу работы 
//   1. В окне обозревателя решений можно добавлять файлы и управлять ими.
//   2. В окне Team Explorer можно подключиться к системе управления версиями.
//   3. В окне "Выходные данные" можно просматривать выходные данные сборки и другие сообщения.
//   4. В окне "Список ошибок" можно просматривать ошибки.
//   5. Последовательно выберите пункты меню "Проект" > "Добавить новый элемент", чтобы создать файлы кода, или "Проект" > "Добавить существующий элемент", чтобы добавить в проект существующие файлы кода.
//   6. Чтобы снова открыть этот проект позже, выберите пункты меню "Файл" > "Открыть" > "Проект" и выберите SLN-файл.
