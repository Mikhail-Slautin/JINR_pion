﻿// Full_formfactor_Int.cpp : Этот файл содержит функцию "main". Здесь начинается и заканчивается выполнение программы.
//
#include<iostream>
#include<fstream>
#include <stdlib.h>
#include<cmath>
#define _USE_MATH_DEFINES
#include <gsl/gsl_math.h>
#include <gsl/gsl_monte.h>
#include <gsl/gsl_monte_plain.h>
#include <gsl/gsl_monte_miser.h>
#include <gsl/gsl_monte_vegas.h>
using namespace std;
double L = 5;

struct my_f_params { double Q2;double m;double mq;double b;double b1;double N; };
double F_f(double x1, double x2, double x3, double x4, double Q2, double m, double mq, double b)
{
    double q2 = -Q2;
    double eta = -q2 / (4 * m * m);
    double pq = m * m * 2 * eta;
    return((-1.0 + x1 + x2 + x3) * b * b + (-x2 * (1.0 - x1 - x2 - x3 - x4) - x2 * x2 - pow(1.0 - x1 - x2 - x3 - x4, 2.0) / 4.0 + 1.0 / 4.0 - x1 / 4.0 + 3.0 / 4.0 * x2 - x3 / 4.0 - x4 / 4.0) * q2 + (-x2 * x2 + x2 - x1 * x2 - x1 * (1.0 - x1 - x2 - x3 - x4) / 2.0 + x2 * x3 - x2 * (1.0 - x1 - x2 - x3 - x4) / 2.0 + x3 * (1.0 - x1 - x2 - x3 - x4) / 2.0) * pq + (-x1 - x2 - x3) * mq * mq + (x2 * x3 / 2.0 + x1 * x3 / 2.0 - x1 * x2 / 2.0 + x2 / 4.0 - x1 * x1 / 4.0 - x2 * x2 / 4.0 - x3 * x3 / 4.0 + x3 / 4.0 + x1 / 4.0) * m * m);
}
//double F1(double x1, double x2)
//{
//    return 1 / (2*((m * m / 4. - mq * mq) * (x2 + 1 - x1 - x2) - m * m * (x2 - 1 + x1 + x2) * (x2 - 1 + x1 + x2) / 4.));
//}

double g1_f(double* k, size_t dim, void* p)
{
    (void)(dim);

    struct my_f_params* fp = (struct my_f_params*)p;
    double x1 = k[0], x2 = k[1], x3 = k[2], x4 = k[3];
    double mpi = fp->m;
    double mq = fp->mq;
    double b22 = fp->b1 * fp->b1;
    double b12 = fp->b * fp->b;
    double b32 = b22 + 1e-5;
    double N21 = -0.00596821;
    double N22 = -0.0175172;
    double N23 = -0.00325021;
    double q2 = -fp->Q2;
    double eta = -q2 / (4 * fp->m * fp->m);
    double pq = fp->m * fp->m * 2 * eta;
    double l2 = fp->m * fp->m * (k[0] / 2.0 + k[1] / 2.0 + k[2] / 2.0 - 1.0 + k[3]) * (k[0] / 2.0 + k[1] / 2.0 + k[2] / 2.0 - 1.0 + k[3]) + k[2] * k[2] * q2 / 4.0 - pq * (k[0] / 2.0 + k[1] /
        2.0 + k[2] / 2.0 - 1.0 + k[3]) * k[2];
    double D = (-1.0 + k[0] + k[1] + k[2]) * fp->mq * fp->mq + (-3.0 / 4.0 * k[0] - 3.0 / 4.0 * k[1] - 3.0 / 4.0 * k[2] + 1.0 - k[3]) * fp->m * fp->m
        - k[0] * fp->b * fp->b - k[1] * fp->b1 * fp->b1 + k[2] * pq / 2.0 + k[2] * q2 / 4.0 - k[2] * fp->b * fp->b;
    double l0 = fp->m * sqrt(1 + eta) * (-k[0] / 2.0 - k[1] / 2.0 - k[2] / 2.0 - (1 - k[0] - k[1] - k[2] - k[3] ));
    double p0 = fp->m * sqrt(1 + eta);
    double pl = fp->m * fp->m * (-k[0] / 2.0 - k[1] / 2.0 - k[2] / 2.0 - (1 - k[0] - k[1] - k[2] - k[3])) - pq * k[2] / 2;
    double ql = pq * (-k[0] / 2.0 - k[1] / 2.0 - k[2] / 2.0 - (1 - k[0] - k[1] - k[2] - k[3])) - k[2] * q2 / 2.0;
    //double numerator= (8.0 * pl + 4 * ql + 4 * fp->m * fp->m + 4* pq) * (fp->mq * fp->mq - D - pl);
    //double numerator = (8.0 * pl + 4 * ql + 4 * fp->m * fp->m + 2 * pq) * (fp->mq * fp->mq - D - pl);
    double numerator = 8.0 * fp->mq * fp->mq * pl + 4.0 * fp->mq * fp->mq * ql + (4.0 * fp->m * fp->m + 2.0 * pq) * fp->mq * fp->mq - 8.0 * pl * (l2 + 3.0 * (D - l2) / 2.0) - 4 * ql * (l2 + 3.0 * (D - l2) / 2.0) - (4.0 * fp->m * fp->m + 2.0 * pq) * D - 8.0 * (pl * pl + fp->m * fp->m * (D - l2) / 4.0) - 4.0 * (ql * pl + pq * (D - l2) / 4.0) - (4.0 * fp->m * fp->m + 2.0 * pq) * pl;
    //double numerator = 1;
    if (k[1] > 1 - k[0])
    {
        return 0;
    }
    if (k[2] > 1 - k[0] - k[1])
    {
        return 0;
    }
    if (k[3] > 1 - k[0] - k[1] - k[2])
    {
        return 0;
    }

    else
    {
      //  return (2 * M_PI * M_PI * numerator*fp->N / ((D - l2) * (D - l2) * (D - l2)* (2 * fp->m * sqrt(1 + eta)) * (2 * fp->m * sqrt(1 + eta))));
        return(numerator/ (D - l2) / (D - l2) / (D - l2)/ (2 * fp->m * sqrt(1 + eta)) / (2 * fp->m * sqrt(1 + eta)));
      //*numerator*fp->N
        //* (2 * fp->m * sqrt(1 + eta))* (2 * fp->m * sqrt(1 + eta))
       /* return(2 * M_PI * M_PI* fp->N*(144.0 * (x1 + x2 + x3 + 2.0 * x4 - 1.0) * x2 * (mpi * mpi - q2 / 4.0) * x1 * ((x3 * x3 / 6.0 + (
            -7.0 / 12.0 + x1 / 3.0 + x2 / 3.0 + 2.0 / 3.0 * x4) * x3 + x1 * x1 / 6.0 + (-7.0 / 12.0 + x2 / 3.0 + 2.0 / 3.0 * x4) *
            x1 + x2 * x2 / 6.0 + (-7.0 / 12.0 + 2.0 / 3.0 * x4) * x2 + 2.0 / 3.0 * x4 * x4 - 2.0 / 3.0 * x4) * mpi * mpi + (2.0 *
                x3 + 1.0 / 2.0 + 2.0 * x4 + x1 + x2) * x3 * q2 / 6.0 + (mq * mq - b32) * x3 + (mq * mq - b12) * x1 + (mq * mq - b22) * x2
            - 8.0 / 3.0 * mq * mq) * x3 / pow((-x3 * x3 / 4.0 + (-x4 - x1 / 2.0 - x2 / 2.0 + 1.0 / 4.0) * x3 - x1 * x1 / 4.0 + (-
                x4 - x2 / 2.0 + 1.0 / 4.0) * x1 - x2 * x2 / 4.0 + (-x4 + 1.0 / 4.0) * x2 - x4 * x4 + x4) * mpi * mpi - q2 * x3 * (x1 + x2
                    + 2.0 * x3 + 2.0 * x4 - 2.0) / 4.0 + (mq * mq - b32) * x3 + (mq * mq - b12) * x1 + (mq * mq - b22) * x2 - mq * mq, 6.0))/ (2 * fp->m * sqrt(1 + eta)) / (2 * fp->m * sqrt(1 + eta)));*/
    }

}
double g2_f(double* k, size_t dim, void* p)
{
    (void)(dim);

    struct my_f_params* fp = (struct my_f_params*)p;
    double N21 = -0.00596821;
    double N22 = -0.0175172;
    double N23 = -0.00325021;
    double q2 = -fp->Q2;
    double eta = -q2 / (4 * fp->m * fp->m);
    double pq = fp->m * fp->m * 2 * eta;
    double l2 = fp->m * fp->m * (k[0] / 2.0 + k[1] / 2.0 + k[2] / 2.0 - 1.0 + k[3]) * (k[0] / 2.0 + k[1] / 2.0 + k[2] / 2.0 - 1.0 + k[3]) + q2 * (k[1] / 2.0 + k[2] / 2.0 - 1.0 + k[0]
        + k[3]) * (k[1] / 2.0 + k[2] / 2.0 - 1.0 + k[0] + k[3]) + 2.0 * pq * (k[0] / 2.0 + k[1] / 2.0 + k[2] / 2.0 - 1.0 + k[3]) * (k[1] / 2.0 + k[2] / 2.0 - 1.0 + k[0] + k[3]);
    /*double D = (-3.0 / 2.0 * k[1] - 3.0 / 2.0 * k[2] + 2.0 - 2.0 * k[0] - 2.0 * k[3]) * pq + (-1.0 + k[0] + k[1] + k[2]) * fp->mq * fp->mq +
        (-3.0 / 4.0 * k[0] - 3.0 / 4.0 * k[1] - 3.0 / 4.0 * k[2] + 1.0 - k[3]) * fp->m * fp->m - k[0] * fp->b * fp->b + k[1] * q2 / 4.0 - k[1] * fp->b * fp->b + k[2] * q2 /
        4.0 - k[2] * fp->b1 * fp->b1 + q2 * (1.0 - k[0]- k[1] - k[2] - k[3]);*/
    double D = (-k[0] - k[1]) * fp->b * fp->b + (-1.0 + k[0] + k[1] + k[2]) * fp->mq * fp->mq + (-3.0 / 4.0 * k[0] - 3.0 / 4.0 * k[1] - 3.0 / 4.0 *
        k[2] + 1.0 - k[3]) * fp->m * fp->m - k[2] * fp->b1 * fp->b1;

    double l0 = fp->m * sqrt(1 + eta) * ((-k[0] / 2.0 - k[1] / 2.0 - k[2] / 2.0 - (1 - k[0] - k[1] - k[2] - k[3])));
    double pl = pq * (-k[1] / 2.0 - k[2] / 2.0 - (1 - k[0] - k[1] - k[2] - k[3])) + fp->m * fp->m * (-k[0] / 2.0 - k[1] / 2.0 - k[2] / 2.0 - (1 - k[0] - k[1] - k[2] - k[3]));
    double ql = (-k[1] / 2.0 - k[2] / 2.0 - (1 - k[0] - k[1] - k[2] - k[3])) * q2 + pq * (-k[0] / 2.0 - k[1] / 2.0 - k[2] / 2.0 - (1 - k[0] - k[1] - k[2] - k[3]));

    //double numerator = (8.0 * pl + 4 * ql + 4 * fp->m * fp->m + 2* pq) * (fp->mq * fp->mq - D - pl-ql);
    //double numerator = 8.0 * pl - 8.0 * pl * D - 8.0 * pl * pl + 4.0 * ql - 4.0 * D * ql - 4.0 * ql * pl + 4.0 * fp->m * fp->m * fp->mq * fp->mq - 4.0 * fp->m * fp->m * D - 4.0 * fp->m * fp->m * pl + 4.0 * pq * fp->mq * fp->mq - 4.0 * D * pq - 4.0 * pq * pl-8.0*pl*ql-4.0*ql*ql-4.0*fp->m*fp->m-4.0*pq*ql;
    double numerator = 8.0 * fp->mq * fp->mq * pl + 4.0 * fp->mq * fp->mq * ql + (4.0 * fp->m * fp->m + 2.0 * pq) * fp->mq * fp->mq - 8.0 * pl * (l2 + 3.0 * (D - l2) / 2.0) - 4 * ql * (l2 + 3.0 * (D - l2) / 2.0) - (4.0 * fp->m * fp->m + 2.0 * pq) * D - 8.0 * (pl * pl + fp->m * fp->m * (D - l2) / 4.0) - 4.0 * (ql * pl + pq * (D - l2) / 4.0) - (4.0 * fp->m * fp->m + 2.0 * pq) * pl - 8.0 * (ql * pl + pq * (D - l2) / 4.0) - 4.0 * (ql * ql + q2 * (D - l2) / 4.0) - (4 * fp->m * fp->m + 2.0 * pq) * ql;
    //double numerator = 1;


    if (k[1] > 1 - k[0])
    {
        return 0;
    }
    if (k[2] > 1 - k[0] - k[1])
    {
        return 0;
    }
    if (k[3] > 1 - k[0] - k[1] - k[2])
    {
        return 0;
    }

    else
    {
        //return (2 * M_PI * M_PI * numerator * fp->N / ((D - l2) * (D - l2) * (D - l2) * (2 * fp->m * sqrt(1 + eta)) * (2 * fp->m * sqrt(1 + eta))));
        return(numerator / (D - l2) / (D - l2) / (D - l2)/ (2 * fp->m * sqrt(1 + eta)) / (2 * fp->m * sqrt(1 + eta)));
        //*numerator*fp->N
        //* (2 * fp->m * sqrt(1 + eta))* (2 * fp->m * sqrt(1 + eta))
    }

}
double g1_f_pk(double* k, size_t dim, void* p)
{
    (void)(dim);

    struct my_f_params* fp = (struct my_f_params*)p;
    double x1 = k[0], x2 = k[1], x3 = k[2], x4 = k[3];
    double m = fp->m;
    double alpha = -0.15;
    double mq = fp->mq;
    double b2 = fp->b1;
    double b1 = fp->b;
    double N21 = -0.00596821;
    double N22 = -0.0175172;
    double N23 = -0.00325021;
    double q2 = -fp->Q2;
    double eta = -q2 / (4 * fp->m * fp->m);
    double pq = fp->m * fp->m * 2 * eta;
    double l2 = m * m * pow(-alpha * x1 / 2.0 - x2 * alpha / 2.0 - alpha * x3 / 2.0 + x1 / 2.0 + x2 / 2.0 + x3 / 2.0
        - 1.0 + x4, 2.0) - pq * x3 * (-alpha * x1 / 2.0 - x2 * alpha / 2.0 - alpha * x3 / 2.0 + x1 / 2.0 + x2 / 2.0 + x3 /
            2.0 - 1.0 + x4) + q2 * x3 * x3 / 4.0;


    double D = (-x1 - x3) * b1 * b1 + (-1.0 + x1 + x2 + x3) * mq * mq + (-3.0 / 4.0 * x1 - 3.0 / 4.0 * x2 - 3.0 / 4.0
        * x3 + 1.0 - x4) * m * m - x2 * b2 * b2 + x3 * pq / 2.0 + x3 * q2 / 4.0;


    double l0 = (-alpha * x1 / 2.0 - x2 * alpha / 2.0 - alpha * x3 / 2.0 + x1 / 2.0 + x2 / 2.0 + x3 / 2.0 - 1.0 + x4
        ) * m * sqrt(1.0 + eta);


    double p0 = fp->m * sqrt(1 + eta);
    double pl = m * m * (-alpha * x1 / 2.0 - x2 * alpha / 2.0 - alpha * x3 / 2.0 + x1 / 2.0 + x2 / 2.0 + x3 / 2.0
        - 1.0 + x4) - x3 * m * m * eta;

    double ql = 2.0 * m * m * eta * (-alpha * x1 / 2.0 - x2 * alpha / 2.0 - alpha * x3 / 2.0 + x1 / 2.0 + x2 / 2.0 +
        x3 / 2.0 - 1.0 + x4) - x3 * q2 / 2.0;






    //double numerator= (8.0 * pl + 4 * ql + 4 * fp->m * fp->m + 4* pq) * (fp->mq * fp->mq - D - pl);
    //double numerator = (8.0 * pl + 4 * ql + 4 * fp->m * fp->m + 2 * pq) * (fp->mq * fp->mq - D - pl);
    double numerator = 8.0 * fp->mq * fp->mq * pl + 4.0 * fp->mq * fp->mq * ql + (4.0 * fp->m * fp->m + 2.0 * pq) * fp->mq * fp->mq - 8.0 * pl * (l2 + 3.0 * (D - l2) / 2.0) - 4 * ql * (l2 + 3.0 * (D - l2) / 2.0) - (4.0 * fp->m * fp->m + 2.0 * pq) * D - 8.0 * (pl * pl + fp->m * fp->m * (D - l2) / 4.0) - 4.0 * (ql * pl + pq * (D - l2) / 4.0) - (4.0 * fp->m * fp->m + 2.0 * pq) * pl;
    //double numerator = 1;
    if (k[1] > 1 - k[0])
    {
        return 0;
    }
    if (k[2] > 1 - k[0] - k[1])
    {
        return 0;
    }
    if (k[3] > 1 - k[0] - k[1] - k[2])
    {
        return 0;
    }

    else
    {
        return (2 * M_PI * M_PI  *numerator* fp->N / ((D - l2) * (D - l2) * (D - l2) * (2 * fp->m * sqrt(1 + eta)) * (2 * fp->m * sqrt(1 + eta))));
        //*numerator*fp->N
        //* (2 * fp->m * sqrt(1 + eta))* (2 * fp->m * sqrt(1 + eta))
       /* return(2 * M_PI * M_PI* fp->N*(144.0 * (x1 + x2 + x3 + 2.0 * x4 - 1.0) * x2 * (mpi * mpi - q2 / 4.0) * x1 * ((x3 * x3 / 6.0 + (
            -7.0 / 12.0 + x1 / 3.0 + x2 / 3.0 + 2.0 / 3.0 * x4) * x3 + x1 * x1 / 6.0 + (-7.0 / 12.0 + x2 / 3.0 + 2.0 / 3.0 * x4) *
            x1 + x2 * x2 / 6.0 + (-7.0 / 12.0 + 2.0 / 3.0 * x4) * x2 + 2.0 / 3.0 * x4 * x4 - 2.0 / 3.0 * x4) * mpi * mpi + (2.0 *
                x3 + 1.0 / 2.0 + 2.0 * x4 + x1 + x2) * x3 * q2 / 6.0 + (mq * mq - b32) * x3 + (mq * mq - b12) * x1 + (mq * mq - b22) * x2
            - 8.0 / 3.0 * mq * mq) * x3 / pow((-x3 * x3 / 4.0 + (-x4 - x1 / 2.0 - x2 / 2.0 + 1.0 / 4.0) * x3 - x1 * x1 / 4.0 + (-
                x4 - x2 / 2.0 + 1.0 / 4.0) * x1 - x2 * x2 / 4.0 + (-x4 + 1.0 / 4.0) * x2 - x4 * x4 + x4) * mpi * mpi - q2 * x3 * (x1 + x2
                    + 2.0 * x3 + 2.0 * x4 - 2.0) / 4.0 + (mq * mq - b32) * x3 + (mq * mq - b12) * x1 + (mq * mq - b22) * x2 - mq * mq, 6.0))/ (2 * fp->m * sqrt(1 + eta)) / (2 * fp->m * sqrt(1 + eta)));*/
    }

}
double g2_f_pk(double* k, size_t dim, void* p)
{
    (void)(dim);

    struct my_f_params* fp = (struct my_f_params*)p;
    double x1 = k[0], x2 = k[1], x3 = k[2], x4 = k[3];
    double m = fp->m;
    double alpha = -0.15;
    double mq = fp->mq;
    double b2 = fp->b1;
    double b1 = fp->b;
    double N21 = -0.00596821;
    double N22 = -0.0175172;
    double N23 = -0.00325021;
    double q2 = -fp->Q2;
    double eta = -q2 / (4 * fp->m * fp->m);
    double pq = fp->m * fp->m * 2 * eta;
    double l2 = m * m * pow(-x1 * alpha / 2.0 - alpha * x2 / 2.0 - x3 * alpha / 2.0 + x1 / 2.0 + x2 / 2.0 + x3 / 2.0
        - 1.0 + x4, 2.0) + 2.0 * pq * (-x1 * alpha / 2.0 - alpha * x2 / 2.0 - x3 * alpha / 2.0 + x1 / 2.0 + x2 / 2.0 + x3 /
            2.0 - 1.0 + x4) * (x2 / 2.0 + x3 / 2.0 - 1.0 + x1 + x4) + q2 * pow(x2 / 2.0 + x3 / 2.0 - 1.0 + x1 + x4, 2.0);

    double D = (-x1 - x3) * b1 * b1 + (2.0 - 2.0 * x1 - 3.0 / 2.0 * x2 - 3.0 / 2.0 * x3 - 2.0 * x4) * pq + (-1.0 + x1
        + x2 + x3) * mq * mq + (-3.0 / 4.0 * x1 - 3.0 / 4.0 * x2 - 3.0 / 4.0 * x3 + 1.0 - x4) * m * m + x2 * q2 / 4.0 - x2 * b2 * b2
        + x3 * q2 / 4.0 + q2 * (1.0 - x1 - x2 - x3 - x4);


    double l0 = m * sqrt(1.0 + eta) * (-x1 * alpha / 2.0 - alpha * x2 / 2.0 - x3 * alpha / 2.0 + x1 / 2.0 + x2 /
        2.0 + x3 / 2.0 - 1.0 + x4);

    double pl = m * m * (-x1 * alpha / 2.0 - alpha * x2 / 2.0 - x3 * alpha / 2.0 + x1 / 2.0 + x2 / 2.0 + x3 / 2.0
        - 1.0 + x4) + 2.0 * m * m * eta * (x2 / 2.0 + x3 / 2.0 - 1.0 + x1 + x4);

    double ql = 2.0 * m * m * eta * (-x1 * alpha / 2.0 - alpha * x2 / 2.0 - x3 * alpha / 2.0 + x1 / 2.0 + x2 / 2.0 +
        x3 / 2.0 - 1.0 + x4) + q2 * (x2 / 2.0 + x3 / 2.0 - 1.0 + x1 + x4);


    //double numerator = (8.0 * pl + 4 * ql + 4 * fp->m * fp->m + 2* pq) * (fp->mq * fp->mq - D - pl-ql);
    //double numerator = 8.0 * pl - 8.0 * pl * D - 8.0 * pl * pl + 4.0 * ql - 4.0 * D * ql - 4.0 * ql * pl + 4.0 * fp->m * fp->m * fp->mq * fp->mq - 4.0 * fp->m * fp->m * D - 4.0 * fp->m * fp->m * pl + 4.0 * pq * fp->mq * fp->mq - 4.0 * D * pq - 4.0 * pq * pl-8.0*pl*ql-4.0*ql*ql-4.0*fp->m*fp->m-4.0*pq*ql;
    double numerator = 8.0 * fp->mq * fp->mq * pl + 4.0 * fp->mq * fp->mq * ql + (4.0 * fp->m * fp->m + 2.0 * pq) * fp->mq * fp->mq - 8.0 * pl * (l2 + 3.0 * (D - l2) / 2.0) - 4 * ql * (l2 + 3.0 * (D - l2) / 2.0) - (4.0 * fp->m * fp->m + 2.0 * pq) * D - 8.0 * (pl * pl + fp->m * fp->m * (D - l2) / 4.0) - 4.0 * (ql * pl + pq * (D - l2) / 4.0) - (4.0 * fp->m * fp->m + 2.0 * pq) * pl - 8.0 * (ql * pl + pq * (D - l2) / 4.0) - 4.0 * (ql * ql + q2 * (D - l2) / 4.0) - (4 * fp->m * fp->m + 2.0 * pq) * ql;
    //double numerator = 1;


    if (k[1] > 1 - k[0])
    {
        return 0;
    }
    if (k[2] > 1 - k[0] - k[1])
    {
        return 0;
    }
    if (k[3] > 1 - k[0] - k[1] - k[2])
    {
        return 0;
    }

    else
    {
        return (2 * M_PI * M_PI * numerator * fp->N / ((D - l2) * (D - l2) * (D - l2) * (2 * fp->m * sqrt(1 + eta)) * (2 * fp->m * sqrt(1 + eta))));
        //*numerator*fp->N
        //* (2 * fp->m * sqrt(1 + eta))* (2 * fp->m * sqrt(1 + eta))
    }

}

/////////////////////

long double f1(double k0, double k, double costheta, double Q2, double m, double mq, double b)
{
    double q2 = -Q2;
    double eta = -q2 / (4 * m * m);
    return (k0 + m * sqrt(1.0 + eta) / 2.0 - sqrt(-4.0 * sqrt(eta) * k * costheta * m + m * m * eta + 4.0
        * b * b + 4.0 * k * k) / 2.0
        );
}
long double f2(double k0, double k, double costheta, double Q2, double m, double mq, double b)
{
    double q2 = -Q2;
    double eta = -q2 / (4 * m * m);
    return (k0 + m * sqrt(1.0 + eta) / 2.0 + sqrt(-4.0 * sqrt(eta) * k * costheta * m + m * m * eta + 4.0
        * b * b + 4.0 * k * k) / 2.0
        );
}
long double f3(double k0, double k, double costheta, double Q2, double m, double mq, double b, double b1)
{
    double q2 = -Q2;
    double eta = -q2 / (4 * m * m);
    return (k0 + m * sqrt(1.0 + eta) / 2.0 - sqrt(-4.0 * sqrt(eta) * k * costheta * m + m * m * eta + 4.0
        * b1 * b1 + 4.0 * k * k) / 2.0
        );
}
long double f4(double k0, double k, double costheta, double Q2, double m, double mq, double b, double b1)
{
    double q2 = -Q2;
    double eta = -q2 / (4 * m * m);
    return (k0 + m * sqrt(1.0 + eta) / 2.0 + sqrt(-4.0 * sqrt(eta) * k * costheta * m + m * m * eta + 4.0
        * b1 * b1 + 4.0 * k * k) / 2.0

        );
}
long double f5(double k0, double k, double costheta, double Q2, double m, double mq, double b)
{
    double q2 = -Q2;
    double eta = -q2 / (4 * m * m);
    return (k0 + m * sqrt(1.0 + eta) / 2.0 - sqrt(4.0 * sqrt(eta) * k * costheta * m - 3.0 * m * m * eta +
        4.0 * b * b + 4.0 * k * k - q2) / 2.0
        );
}
long double f6(double k0, double k, double costheta, double Q2, double m, double mq, double b)
{
    double q2 = -Q2;
    double eta = -q2 / (4 * m * m);
    return (k0 + m * sqrt(1.0 + eta) / 2.0 + sqrt(4.0 * sqrt(eta) * k * costheta * m - 3.0 * m * m * eta +
        4.0 * b * b + 4.0 * k * k - q2) / 2.0
        );
}
long double f7(double k0, double k, double costheta, double Q2, double m, double mq, double b, double b1)
{
    double q2 = -Q2;
    double eta = -q2 / (4 * m * m);
    return (k0 + m * sqrt(1.0 + eta) / 2.0 - sqrt(4.0 * sqrt(eta) * k * costheta * m - 3.0 * m * m * eta +
        4.0 * b1 * b1 + 4.0 * k * k - q2) / 2.0
        );
}
long double f8(double k0, double k, double costheta, double Q2, double m, double mq, double b, double b1)
{
    double q2 = -Q2;
    double eta = -q2 / (4 * m * m);
    return (k0 + m * sqrt(1.0 + eta) / 2.0 + sqrt(4.0 * sqrt(eta) * k * costheta * m - 3.0 * m * m * eta +
        4.0 * b1 * b1 + 4.0 * k * k - q2) / 2.0

        );
}
long double f9(double k0, double k, double costheta, double Q2, double m, double mq, double b)
{
    double q2 = -Q2;
    double eta = -q2 / (4 * m * m);
    return (k0 - sqrt(k * k + mq * mq));
}
long double f10(double k0, double k, double costheta, double Q2, double m, double mq, double b)
{
    double q2 = -Q2;
    double eta = -q2 / (4 * m * m);
    return (k0 + sqrt(k * k + mq * mq));
}
long double f11(double k0, double k, double costheta, double Q2, double m, double mq, double b)
{
    double q2 = -Q2;
    double eta = -q2 / (4 * m * m);
    return (k0 + m * sqrt(1.0 + eta) - sqrt(-2.0 * sqrt(eta) * k * costheta * m + m * m * eta + k * k +
        mq * mq)
        );
}
long double f12(double k0, double k, double costheta, double Q2, double m, double mq, double b)
{
    double q2 = -Q2;
    double eta = -q2 / (4 * m * m);
    return (k0 + m * sqrt(1.0 + eta) + sqrt(-2.0 * sqrt(eta) * k * costheta * m + m * m * eta + k * k +
        mq * mq)
        );
}
long double f13(double k0, double k, double costheta, double Q2, double m, double mq, double b)
{
    double q2 = -Q2;
    double eta = -q2 / (4 * m * m);
    return (k0 + m * sqrt(1.0 + eta) - sqrt(2.0 * sqrt(eta) * k * costheta * m - 3.0 * m * m * eta + k *
        k + mq * mq - q2)
        );
}
long double f14(double k0, double k, double costheta, double Q2, double m, double mq, double b)
{
    double q2 = -Q2;
    double eta = -q2 / (4 * m * m);
    return (k0 + m * sqrt(1.0 + eta) + sqrt(2.0 * sqrt(eta) * k * costheta * m - 3.0 * m * m * eta + k *
        k + mq * mq - q2)
        );
}
double g1_res(double* k, size_t dim, void* p)
{
    (void)(dim);
    struct my_f_params* fp = (struct my_f_params*)p;
    //double* k = new double[2];
    //k[0] = x[0] / (1 - x[0]);
   // k[1] = x[1];
    double q2 = -fp->Q2;
    double eta = -q2 / (4 * fp->m * fp->m);
    double N21 = -0.00596821;
    double N22 = -0.0175172;
    double N23 = -0.00325021;
    //(1 - x[0])* (1 - x[0])*
    double k01 = -fp->m * sqrt(1.0 + eta) / 2.0 + sqrt(-4.0 * sqrt(eta) * k[0] * k[1] * fp->m + fp->m * fp->m * eta + 4.0 * fp->b
        * fp->b + 4.0 * k[0] * k[0]) / 2.0;
    double num1 = (8 * (fp->m * sqrt(1 + eta) * k01 + fp->m * sqrt(eta) * k[0] * k[1]) + 4 * (-2 * fp->m * sqrt(eta) * k[0] * k[1]) + 4 * fp->m * fp->m + 2 * (fp->m * fp->m * 2 * eta)) * (fp->mq * fp->mq - (k01 * k01 - k[0] * k[0]) - (fp->m * sqrt(1 + eta) * k01 + fp->m * sqrt(eta) * k[0] * k[1]));
    long  double res1 = (k[0] * k[0] * 2 * 2 * M_PI * num1 / ((f2(k01, k[0], k[1], fp->Q2, fp->m, fp->mq, fp->b)) * (f3(k01, k[0], k[1], fp->Q2, fp->m, fp->mq, fp->b, fp->b1)) * (f4(k01, k[0], k[1], fp->Q2, fp->m, fp->mq, fp->b, fp->b1)) * (f5(k01, k[0], k[1], fp->Q2, fp->m, fp->mq, fp->b)) * (f6(k01, k[0], k[1], fp->Q2, fp->m, fp->mq, fp->b)) * (f9(k01, k[0], k[1], fp->Q2, fp->m, fp->mq, fp->b)) * (f10(k01, k[0], k[1], fp->Q2, fp->m, fp->mq, fp->b)) * (f11(k01, k[0], k[1], fp->Q2, fp->m, fp->mq, fp->b)) * (f12(k01, k[0], k[1], fp->Q2, fp->m, fp->mq, fp->b))));

    double k03 = -fp->m * sqrt(1.0 + eta) / 2.0 + sqrt(-4.0 * sqrt(eta) * k[0] * k[1] * fp->m + fp->m * fp->m * eta + 4.0
        * fp->b1 * fp->b1 + 4.0 * k[0] * k[0]) / 2.0;
    double num3 = (8 * (fp->m * sqrt(1 + eta) * k03 + fp->m * sqrt(eta) * k[0] * k[1]) + 4 * (-2 * fp->m * sqrt(eta) * k[0] * k[1]) + 4 * fp->m * fp->m + 2 * (fp->m * fp->m * 2 * eta)) * (fp->mq * fp->mq - (k03 * k03 - k[0] * k[0]) - (fp->m * sqrt(1 + eta) * k03 + fp->m * sqrt(eta) * k[0] * k[1]));
    long double res3 = (k[0] * k[0] * 2 * 2 * M_PI * num3 / ((f2(k03, k[0], k[1], fp->Q2, fp->m, fp->mq, fp->b)) * (f1(k03, k[0], k[1], fp->Q2, fp->m, fp->mq, fp->b)) * (f4(k03, k[0], k[1], fp->Q2, fp->m, fp->mq, fp->b, fp->b1)) * (f5(k03, k[0], k[1], fp->Q2, fp->m, fp->mq, fp->b)) * (f6(k03, k[0], k[1], fp->Q2, fp->m, fp->mq, fp->b)) * (f9(k03, k[0], k[1], fp->Q2, fp->m, fp->mq, fp->b)) * (f10(k03, k[0], k[1], fp->Q2, fp->m, fp->mq, fp->b)) * (f11(k03, k[0], k[1], fp->Q2, fp->m, fp->mq, fp->b)) * (f12(k03, k[0], k[1], fp->Q2, fp->m, fp->mq, fp->b))));

    double k05 = -fp->m * sqrt(1.0 + eta) / 2.0 + sqrt(4.0 * sqrt(eta) * k[0] * k[1] * fp->m - 3.0 * fp->m * fp->m * eta +
        4.0 * fp->b * fp->b + 4.0 * k[0] * k[0] - q2) / 2.0;
    double num5 = (8 * (fp->m * sqrt(1 + eta) * k05 + fp->m * sqrt(eta) * k[0] * k[1]) + 4 * (-2 * fp->m * sqrt(eta) * k[0] * k[1]) + 4 * fp->m * fp->m + 2 * (fp->m * fp->m * 2 * eta)) * (fp->mq * fp->mq - (k05 * k05 - k[0] * k[0]) - (fp->m * sqrt(1 + eta) * k05 + fp->m * sqrt(eta) * k[0] * k[1]));
    long double res5 = (k[0] * k[0] * 2 * 2 * M_PI * num5 / ((f2(k05, k[0], k[1], fp->Q2, fp->m, fp->mq, fp->b)) * (f1(k05, k[0], k[1], fp->Q2, fp->m, fp->mq, fp->b)) * (f4(k05, k[0], k[1], fp->Q2, fp->m, fp->mq, fp->b, fp->b1)) * (f3(k05, k[0], k[1], fp->Q2, fp->m, fp->mq, fp->b, fp->b1) * (f6(k05, k[0], k[1], fp->Q2, fp->m, fp->mq, fp->b)) * (f9(k05, k[0], k[1], fp->Q2, fp->m, fp->mq, fp->b)) * (f10(k05, k[0], k[1], fp->Q2, fp->m, fp->mq, fp->b)) * (f11(k05, k[0], k[1], fp->Q2, fp->m, fp->mq, fp->b)) * (f12(k05, k[0], k[1], fp->Q2, fp->m, fp->mq, fp->b)))));

    double k09 = sqrt(k[0] * k[0] + fp->mq * fp->mq);
    double num9 = (8 * (fp->m * sqrt(1 + eta) * k09 + fp->m * sqrt(eta) * k[0] * k[1]) + 4 * (-2 * fp->m * sqrt(eta) * k[0] * k[1]) + 4 * fp->m * fp->m + 2 * (fp->m * fp->m * 2 * eta)) * (fp->mq * fp->mq - (k09 * k09 - k[0] * k[0]) - (fp->m * sqrt(1 + eta) * k09 + fp->m * sqrt(eta) * k[0] * k[1]));
    long double res9 = (k[0] * k[0] * 2 * 2 * M_PI * num9 / ((f2(k09, k[0], k[1], fp->Q2, fp->m, fp->mq, fp->b)) * (f1(k09, k[0], k[1], fp->Q2, fp->m, fp->mq, fp->b)) * (f4(k09, k[0], k[1], fp->Q2, fp->m, fp->mq, fp->b, fp->b1)) * (f3(k09, k[0], k[1], fp->Q2, fp->m, fp->mq, fp->b, fp->b1) * (f6(k09, k[0], k[1], fp->Q2, fp->m, fp->mq, fp->b)) * (f5(k09, k[0], k[1], fp->Q2, fp->m, fp->mq, fp->b)) * (f10(k09, k[0], k[1], fp->Q2, fp->m, fp->mq, fp->b)) * (f11(k09, k[0], k[1], fp->Q2, fp->m, fp->mq, fp->b)) * (f12(k09, k[0], k[1], fp->Q2, fp->m, fp->mq, fp->b)))));

    double k011 = -fp->m * sqrt(1.0 + eta) + sqrt(-2.0 * sqrt(eta) * k[0] * k[1] * fp->m + fp->m * fp->m * eta + k[0] * k[0] +
        fp->mq * fp->mq);
    double num11 = (8 * (fp->m * sqrt(1 + eta) * k011 + fp->m * sqrt(eta) * k[0] * k[1]) + 4 * (-2 * fp->m * sqrt(eta) * k[0] * k[1]) + 4 * fp->m * fp->m + 2 * (fp->m * fp->m * 2 * eta)) * (fp->mq * fp->mq - (k011 * k011 - k[0] * k[0]) - (fp->m * sqrt(1 + eta) * k011 + fp->m * sqrt(eta) * k[0] * k[1]));
    long  double res11 = (k[0] * k[0] * 2 * 2 * M_PI * num11 / ((f2(k011, k[0], k[1], fp->Q2, fp->m, fp->mq, fp->b)) * (f1(k011, k[0], k[1], fp->Q2, fp->m, fp->mq, fp->b)) * (f4(k011, k[0], k[1], fp->Q2, fp->m, fp->mq, fp->b, fp->b1)) * (f3(k011, k[0], k[1], fp->Q2, fp->m, fp->mq, fp->b, fp->b1) * (f6(k011, k[0], k[1], fp->Q2, fp->m, fp->mq, fp->b)) * (f5(k011, k[0], k[1], fp->Q2, fp->m, fp->mq, fp->b)) * (f9(k011, k[0], k[1], fp->Q2, fp->m, fp->mq, fp->b)) * (f10(k011, k[0], k[1], fp->Q2, fp->m, fp->mq, fp->b)) * (f12(k011, k[0], k[1], fp->Q2, fp->m, fp->mq, fp->b)))));

    long double sum = -2 * M_PI * fp->N * (res1 + res3 + res5 + res9 + res11) / ((2 * fp->m * sqrt(1 + eta)) * (2 * fp->m * sqrt(1 + eta)));
    //((2 * fp->m * sqrt(1 + eta)) * (2 * fp->m * sqrt(1 + eta)))
     //N21*
    return sum;
    //(1 - x[0]) * (1 - x[0])
    //f2(k01, k[0], k[1], fp->Q2, fp->m, fp->mq, fp->b) * f3(k01, k[0], k[1], fp->Q2, fp->m, fp->mq, fp->b, fp->b1)*f4(k01, k[0], k[1], fp->Q2, fp->m, fp->mq, fp->b, fp->b1)* f5(k01, k[0], k[1], fp->Q2, fp->m, fp->mq, fp->b)* f6(k01, k[0], k[1], fp->Q2, fp->m, fp->mq, fp->b)* f9(k01, k[0], k[1], fp->Q2, fp->m, fp->mq, fp->b)* f10(k01, k[0], k[1], fp->Q2, fp->m, fp->mq, fp->b)* f11(k01, k[0], k[1], fp->Q2, fp->m, fp->mq, fp->b)* f12(k01, k[0], k[1], fp->Q2, fp->m, fp->mq, fp->b)));
}
double g2_res(double* k, size_t dim, void* p)
{

    (void)(dim);
    struct my_f_params* fp = (struct my_f_params*)p;
    //double* k = new double[2];
    //k[0] = x[0] / (1 - x[0]);
   // k[1] = x[1];
    double q2 = -fp->Q2;
    double eta = -q2 / (4 * fp->m * fp->m);
    double N21 = -0.00596821;
    double N22 = -0.0175172;
    double N23 = -0.00325021;

    //(1 - x[0]) * (1 - x[0]) * 
    double k01 = -fp->m * sqrt(1.0 + eta) / 2.0 + sqrt(-4.0 * sqrt(eta) * k[0] * k[1] * fp->m + fp->m * fp->m * eta + 4.0 * fp->b
        * fp->b + 4.0 * k[0] * k[0]) / 2.0;
    double num1 = (8 * (fp->m * sqrt(1 + eta) * k01 + fp->m * sqrt(eta) * k[0] * k[1]) + 4 * (-2 * fp->m * sqrt(eta) * k[0] * k[1]) + 4 * fp->m * fp->m + 2 * (fp->m * fp->m * 2 * eta)) * (fp->mq * fp->mq - (k01 * k01 - k[0] * k[0]) - (fp->m * sqrt(1 + eta) * k01 + fp->m * sqrt(eta) * k[0] * k[1]) - (-2 * fp->m * sqrt(eta) * k[0] * k[1]));
    long  double res1 = (k[0] * k[0] * 2 * 2 * M_PI * num1 / ((f2(k01, k[0], k[1], fp->Q2, fp->m, fp->mq, fp->b)) * (f7(k01, k[0], k[1], fp->Q2, fp->m, fp->mq, fp->b, fp->b1)) * (f8(k01, k[0], k[1], fp->Q2, fp->m, fp->mq, fp->b, fp->b1)) * (f5(k01, k[0], k[1], fp->Q2, fp->m, fp->mq, fp->b)) * (f6(k01, k[0], k[1], fp->Q2, fp->m, fp->mq, fp->b)) * (f9(k01, k[0], k[1], fp->Q2, fp->m, fp->mq, fp->b)) * (f10(k01, k[0], k[1], fp->Q2, fp->m, fp->mq, fp->b)) * (f13(k01, k[0], k[1], fp->Q2, fp->m, fp->mq, fp->b)) * (f14(k01, k[0], k[1], fp->Q2, fp->m, fp->mq, fp->b))));

    double k07 = -fp->m * sqrt(1.0 + eta) / 2.0 + sqrt(4.0 * sqrt(eta) * k[0] * k[1] * fp->m - 3.0 * fp->m * fp->m * eta +
        4.0 * fp->b1 * fp->b1 + 4.0 * k[0] * k[0] - q2) / 2.0;
    double num7 = (8 * (fp->m * sqrt(1 + eta) * k07 + fp->m * sqrt(eta) * k[0] * k[1]) + 4 * (-2 * fp->m * sqrt(eta) * k[0] * k[1]) + 4 * fp->m * fp->m + 2 * (fp->m * fp->m * 2 * eta)) * (fp->mq * fp->mq - (k07 * k07 - k[0] * k[0]) - (fp->m * sqrt(1 + eta) * k07 + fp->m * sqrt(eta) * k[0] * k[1]) - (-2 * fp->m * sqrt(eta) * k[0] * k[1]));
    long double res7 = (k[0] * k[0] * 2 * 2 * M_PI * num7 / ((f2(k07, k[0], k[1], fp->Q2, fp->m, fp->mq, fp->b)) * (f1(k07, k[0], k[1], fp->Q2, fp->m, fp->mq, fp->b)) * (f8(k07, k[0], k[1], fp->Q2, fp->m, fp->mq, fp->b, fp->b1)) * (f5(k07, k[0], k[1], fp->Q2, fp->m, fp->mq, fp->b)) * (f6(k07, k[0], k[1], fp->Q2, fp->m, fp->mq, fp->b)) * (f9(k07, k[0], k[1], fp->Q2, fp->m, fp->mq, fp->b)) * (f10(k07, k[0], k[1], fp->Q2, fp->m, fp->mq, fp->b)) * (f13(k07, k[0], k[1], fp->Q2, fp->m, fp->mq, fp->b)) * (f14(k07, k[0], k[1], fp->Q2, fp->m, fp->mq, fp->b))));

    double k05 = -fp->m * sqrt(1.0 + eta) / 2.0 + sqrt(4.0 * sqrt(eta) * k[0] * k[1] * fp->m - 3.0 * fp->m * fp->m * eta +
        4.0 * fp->b * fp->b + 4.0 * k[0] * k[0] - q2) / 2.0;
    double num5 = (8 * (fp->m * sqrt(1 + eta) * k05 + fp->m * sqrt(eta) * k[0] * k[1]) + 4 * (-2 * fp->m * sqrt(eta) * k[0] * k[1]) + 4 * fp->m * fp->m + 2 * (fp->m * fp->m * 2 * eta)) * (fp->mq * fp->mq - (k05 * k05 - k[0] * k[0]) - (fp->m * sqrt(1 + eta) * k05 + fp->m * sqrt(eta) * k[0] * k[1]) - (-2 * fp->m * sqrt(eta) * k[0] * k[1]));
    long double res5 = (k[0] * k[0] * 2 * 2 * M_PI * num5 / ((f2(k05, k[0], k[1], fp->Q2, fp->m, fp->mq, fp->b)) * (f1(k05, k[0], k[1], fp->Q2, fp->m, fp->mq, fp->b)) * (f8(k05, k[0], k[1], fp->Q2, fp->m, fp->mq, fp->b, fp->b1)) * (f7(k05, k[0], k[1], fp->Q2, fp->m, fp->mq, fp->b, fp->b1) * (f6(k05, k[0], k[1], fp->Q2, fp->m, fp->mq, fp->b)) * (f9(k05, k[0], k[1], fp->Q2, fp->m, fp->mq, fp->b)) * (f10(k05, k[0], k[1], fp->Q2, fp->m, fp->mq, fp->b)) * (f13(k05, k[0], k[1], fp->Q2, fp->m, fp->mq, fp->b)) * (f14(k05, k[0], k[1], fp->Q2, fp->m, fp->mq, fp->b)))));

    double k09 = sqrt(k[0] * k[0] + fp->mq * fp->mq);
    double num9 = (8 * (fp->m * sqrt(1 + eta) * k09 + fp->m * sqrt(eta) * k[0] * k[1]) + 4 * (-2 * fp->m * sqrt(eta) * k[0] * k[1]) + 4 * fp->m * fp->m + 2 * (fp->m * fp->m * 2 * eta)) * (fp->mq * fp->mq - (k09 * k09 - k[0] * k[0]) - (fp->m * sqrt(1 + eta) * k09 + fp->m * sqrt(eta) * k[0] * k[1]) - (-2 * fp->m * sqrt(eta) * k[0] * k[1]));
    long double res9 = (k[0] * k[0] * 2 * 2 * M_PI * num9 / ((f2(k09, k[0], k[1], fp->Q2, fp->m, fp->mq, fp->b)) * (f1(k09, k[0], k[1], fp->Q2, fp->m, fp->mq, fp->b)) * (f8(k09, k[0], k[1], fp->Q2, fp->m, fp->mq, fp->b, fp->b1)) * (f7(k09, k[0], k[1], fp->Q2, fp->m, fp->mq, fp->b, fp->b1) * (f6(k09, k[0], k[1], fp->Q2, fp->m, fp->mq, fp->b)) * (f5(k09, k[0], k[1], fp->Q2, fp->m, fp->mq, fp->b)) * (f10(k09, k[0], k[1], fp->Q2, fp->m, fp->mq, fp->b)) * (f13(k09, k[0], k[1], fp->Q2, fp->m, fp->mq, fp->b)) * (f14(k09, k[0], k[1], fp->Q2, fp->m, fp->mq, fp->b)))));

    double k013 = -fp->m * sqrt(1.0 + eta) + sqrt(2.0 * sqrt(eta) * k[0] * k[1] * fp->m - 3.0 * fp->m * fp->m * eta + k[0] *
        k[0] + fp->mq * fp->mq - q2);
    double num13 = (8 * (fp->m * sqrt(1 + eta) * k013 + fp->m * sqrt(eta) * k[0] * k[1]) + 4 * (-2 * fp->m * sqrt(eta) * k[0] * k[1]) + 4 * fp->m * fp->m + 2 * (fp->m * fp->m * 2 * eta)) * (fp->mq * fp->mq - (k013 * k013 - k[0] * k[0]) - (fp->m * sqrt(1 + eta) * k013 + fp->m * sqrt(eta) * k[0] * k[1]) - (-2 * fp->m * sqrt(eta) * k[0] * k[1]));
    long  double res13 = (k[0] * k[0] * 2 * 2 * M_PI * num13 / ((f2(k013, k[0], k[1], fp->Q2, fp->m, fp->mq, fp->b)) * (f1(k013, k[0], k[1], fp->Q2, fp->m, fp->mq, fp->b)) * (f8(k013, k[0], k[1], fp->Q2, fp->m, fp->mq, fp->b, fp->b1)) * (f7(k013, k[0], k[1], fp->Q2, fp->m, fp->mq, fp->b, fp->b1) * (f6(k013, k[0], k[1], fp->Q2, fp->m, fp->mq, fp->b)) * (f5(k013, k[0], k[1], fp->Q2, fp->m, fp->mq, fp->b)) * (f9(k013, k[0], k[1], fp->Q2, fp->m, fp->mq, fp->b)) * (f10(k013, k[0], k[1], fp->Q2, fp->m, fp->mq, fp->b)) * (f14(k013, k[0], k[1], fp->Q2, fp->m, fp->mq, fp->b)))));

    double sum = -2 * M_PI * fp->N * (res1 + res7 + res5 + res9 + res13) / ((2 * fp->m * sqrt(1 + eta)) * (2 * fp->m * sqrt(1 + eta)));
    //((2 * fp->m * sqrt(1 + eta)) * (2 * fp->m * sqrt(1 + eta)))
    return sum;
}
int main()
{
    double res_f, err_f, res1_f, err1_f;

    double xl_f[4] = { 0,0,0,0 };
    double xu_f[4] = { 1,1,1,1 };

    double  res1_res, err1_res, res2_res, err2_res;

    double xl_res[2] = { 0,0 };
    double xu_res[2] = { 5,1 };
    const gsl_rng_type* T;
    gsl_rng* r;

    gsl_rng_env_setup();

    T = gsl_rng_default;
    r = gsl_rng_alloc(T);
    double m = 0.14;
    double mq = 0.26;
    double b = 0.55;
    double b1 = 0.550001;
    double N21 = -0.00596118;//4.69579e-07
    double N22 = -0.0174739;//2.00517e-06
    double N23 = -0.00324541;//3.87599e-07
    double N24 = -0.00284119;
    double N26 = -0.0496939;
    double N27 = -0.0104346;
    double N28 = -0.00613619;
    double Npk1 = -0.00599878;
    ofstream file("res.txt");
    //for (double Q2 = 1e-8;Q2 < 10.1;Q2 += 0.5)
    {
        struct my_f_params params = { 2,m,mq,b,b1,N28 };
        {

                    gsl_monte_vegas_state* s_f = gsl_monte_vegas_alloc(4);
                    gsl_monte_function G_f = { &g1_f , 4,&params };
                    gsl_monte_vegas_integrate(&G_f, xl_f, xu_f, 4, 1000000, r, s_f,
                        &res_f, &err_f);
                    do
                    {
                        gsl_monte_vegas_integrate(&G_f, xl_f, xu_f, 4, 1000000, r, s_f,
                            &res_f, &err_f);
                    } while (fabs(gsl_monte_vegas_chisq(s_f) - 1.0) > 0.5);


        }
                {
                    gsl_monte_vegas_state* s1_f = gsl_monte_vegas_alloc(4);
                    gsl_monte_function G1_f = { &g2_f , 4,&params };
                    gsl_monte_vegas_integrate(&G1_f, xl_f, xu_f, 4, 1000000, r, s1_f,
                        &res1_f, &err1_f);
                    do
                    {
                        gsl_monte_vegas_integrate(&G1_f, xl_f, xu_f, 4, 1000000, r, s1_f,
                            &res1_f, &err1_f);
                    } while (fabs(gsl_monte_vegas_chisq(s1_f) - 1.0) > 0.5);
                }
                cout<<res_f+ res1_f << " " << err_f << endl;
                //cout << res1_f <<" "<< err1_f << endl;
            }
        //    {
        //        gsl_monte_vegas_state* s1_res = gsl_monte_vegas_alloc(2);
        //        gsl_monte_function G1_res = { &g1_res, 2,&params };
        //        gsl_monte_vegas_integrate(&G1_res, xl_res, xu_res, 2, 10000, r, s1_res,
        //            &res1_res, &err1_res);
        //        do
        //        {
        //            gsl_monte_vegas_integrate(&G1_res, xl_res, xu_res, 2, 10000, r, s1_res,
        //                &res1_res, &err1_res);
        //        } while (fabs(gsl_monte_vegas_chisq(s1_res) - 1.0) > 0.5);

        //    }
        //    {
        //        gsl_monte_vegas_state* s2_res = gsl_monte_vegas_alloc(2);
        //        gsl_monte_function G2_res = { &g2_res, 2,&params };
        //        gsl_monte_vegas_integrate(&G2_res, xl_res, xu_res, 2, 10000, r, s2_res,
        //            &res2_res, &err2_res);
        //        do
        //        {
        //            gsl_monte_vegas_integrate(&G2_res, xl_res, xu_res, 2, 10000, r, s2_res,
        //                &res2_res, &err2_res);
        //        } while (fabs(gsl_monte_vegas_chisq(s2_res) - 1.0) > 0.5);

        //    }
        //    file << " " << Q2 << " " << res1_res + res2_res << endl;
        //}
    double m1 = 0.14;
    double mq1 = 0.3;
    double b11 = 0.75;
    double b111 = 0.75001;


 /*   for (double Q2 = 1e-5;Q2 < 30.2;Q2 += 0.5)
    {
        struct my_f_params params = { Q2,m1,mq1,b11,b111,N22 };
        {

            gsl_monte_vegas_state* s_f = gsl_monte_vegas_alloc(4);
            gsl_monte_function G_f = { &g1_f , 4,&params };
            gsl_monte_vegas_integrate(&G_f, xl_f, xu_f, 4, 100000, r, s_f,
                &res_f, &err_f);
            do
            {
                gsl_monte_vegas_integrate(&G_f, xl_f, xu_f, 4, 100000, r, s_f,
                    &res_f, &err_f);
            } while (fabs(gsl_monte_vegas_chisq(s_f) - 1.0) > 0.5);

            
        }
        {
            gsl_monte_vegas_state* s1_f = gsl_monte_vegas_alloc(4);
            gsl_monte_function G1_f = { &g2_f , 4,&params };
            gsl_monte_vegas_integrate(&G1_f, xl_f, xu_f, 4, 100000, r, s1_f,
                &res1_f, &err1_f);
            do
            {
                gsl_monte_vegas_integrate(&G1_f, xl_f, xu_f, 4, 100000, r, s1_f,
                    &res1_f, &err1_f);
            } while (fabs(gsl_monte_vegas_chisq(s1_f) - 1.0) > 0.5);
        }
        cout << Q2 << " " << res_f <<" "<< res1_f << endl;*/
        /*{
            gsl_monte_vegas_state* s1_res = gsl_monte_vegas_alloc(2);
            gsl_monte_function G1_res = { &g1_res, 2,&params };
            gsl_monte_vegas_integrate(&G1_res, xl_res, xu_res, 2, 10000, r, s1_res,
                &res1_res, &err1_res);
            do
            {
                gsl_monte_vegas_integrate(&G1_res, xl_res, xu_res, 2, 10000, r, s1_res,
                    &res1_res, &err1_res);
            } while (fabs(gsl_monte_vegas_chisq(s1_res) - 1.0) > 0.5);

        }
        {
            gsl_monte_vegas_state* s2_res = gsl_monte_vegas_alloc(2);
            gsl_monte_function G2_res = { &g2_res, 2,&params };
            gsl_monte_vegas_integrate(&G2_res, xl_res, xu_res, 2, 10000, r, s2_res,
                &res2_res, &err2_res);
            do
            {
                gsl_monte_vegas_integrate(&G2_res, xl_res, xu_res, 2, 10000, r, s2_res,
                    &res2_res, &err2_res);
            } while (fabs(gsl_monte_vegas_chisq(s2_res) - 1.0) > 0.5);

        }
        file << " " << Q2 << " " << (res1_res + res2_res) << endl;*/
    //}
    //double m2 = 0.14;
    //double mq2 = 0.2;
    //double b2 = 0.5;
    //double b12 = 0.50001;


    //for (double Q2 = 1e-5;Q2 < 30.2;Q2 += 0.5)
    //{
    //    struct my_f_params params = { Q2,m2,mq2,b2,b12,N23 };
    //    {

    //        gsl_monte_vegas_state* s_f = gsl_monte_vegas_alloc(4);
    //        gsl_monte_function G_f = { &g1_f , 4,&params };
    //        gsl_monte_vegas_integrate(&G_f, xl_f, xu_f, 4, 1000000, r, s_f,
    //            &res_f, &err_f);
    //        do
    //        {
    //            gsl_monte_vegas_integrate(&G_f, xl_f, xu_f, 4, 1000000, r, s_f,
    //                &res_f, &err_f);
    //        } while (fabs(gsl_monte_vegas_chisq(s_f) - 1.0) > 0.5);


    //    }
    //    {
    //        gsl_monte_vegas_state* s1_f = gsl_monte_vegas_alloc(4);
    //        gsl_monte_function G1_f = { &g2_f , 4,&params };
    //        gsl_monte_vegas_integrate(&G1_f, xl_f, xu_f, 4, 1000000, r, s1_f,
    //            &res1_f, &err1_f);
    //        do
    //        {
    //            gsl_monte_vegas_integrate(&G1_f, xl_f, xu_f, 4, 1000000, r, s1_f,
    //                &res1_f, &err1_f);
    //        } while (fabs(gsl_monte_vegas_chisq(s1_f) - 1.0) > 0.5);
    //    }
    //    file << Q2 << " " << res_f + res1_f << endl;
        /*{
            gsl_monte_vegas_state* s1_res = gsl_monte_vegas_alloc(2);
            gsl_monte_function G1_res = { &g1_res, 2,&params };
            gsl_monte_vegas_integrate(&G1_res, xl_res, xu_res, 2, 10000, r, s1_res,
                &res1_res, &err1_res);
            do
            {
                gsl_monte_vegas_integrate(&G1_res, xl_res, xu_res, 2, 10000, r, s1_res,
                    &res1_res, &err1_res);
            } while (fabs(gsl_monte_vegas_chisq(s1_res) - 1.0) > 0.5);

        }
        {
            gsl_monte_vegas_state* s2_res = gsl_monte_vegas_alloc(2);
            gsl_monte_function G2_res = { &g2_res, 2,&params };
            gsl_monte_vegas_integrate(&G2_res, xl_res, xu_res, 2, 10000, r, s2_res,
                &res2_res, &err2_res);
            do
            {
                gsl_monte_vegas_integrate(&G2_res, xl_res, xu_res, 2, 10000, r, s2_res,
                    &res2_res, &err2_res);
            } while (fabs(gsl_monte_vegas_chisq(s2_res) - 1.0) > 0.5);

        }
        file << " " << Q2 << " " << (res1_res + res2_res) << endl;*/
    //}
}
    /*file.close();*/
   
    

// Запуск программы: CTRL+F5 или меню "Отладка" > "Запуск без отладки"
// Отладка программы: F5 или меню "Отладка" > "Запустить отладку"

// Советы по началу работы 
//   1. В окне обозревателя решений можно добавлять файлы и управлять ими.
//   2. В окне Team Explorer можно подключиться к системе управления версиями.
//   3. В окне "Выходные данные" можно просматривать выходные данные сборки и другие сообщения.
//   4. В окне "Список ошибок" можно просматривать ошибки.
//   5. Последовательно выберите пункты меню "Проект" > "Добавить новый элемент", чтобы создать файлы кода, или "Проект" > "Добавить существующий элемент", чтобы добавить в проект существующие файлы кода.
//   6. Чтобы снова открыть этот проект позже, выберите пункты меню "Файл" > "Открыть" > "Проект" и выберите SLN-файл.
