﻿// WTI_SYM.cpp : Этот файл содержит функцию "main". Здесь начинается и заканчивается выполнение программы.
//

// offshell.cpp : Этот файл содержит функцию "main". Здесь начинается и заканчивается выполнение программы.
//

// Full_formfactor.cpp : Этот файл содержит функцию "main". Здесь начинается и заканчивается выполнение программы.
//

#include<iostream>
#include<fstream>
#include <stdlib.h>
#include<cmath>
#include<complex>
#define _USE_MATH_DEFINES
#include <gsl/gsl_math.h>
#include <gsl/gsl_monte.h>
#include <gsl/gsl_monte_plain.h>
#include <gsl/gsl_monte_miser.h>
#include <gsl/gsl_monte_vegas.h>
using namespace std;

struct my_f_params { double Q2;double t;double m;double mq;double b;double b1;double N; };
struct my_f_params_1 { double Q2;double t;double m;double mq; };



double g_friaPmu1(double* k, size_t dim, void* p)
{
    (void)(dim);

    struct my_f_params* fp = (struct my_f_params*)p;
    double x1 = k[0], x2 = k[1], x3 = k[2], x4 = k[3];
    double mpi = fp->m;
    double mq = fp->mq;
    double t = fp->t;
    double b = fp->b;
    double q2 = -fp->Q2;
    double x5 = 1 - x1 - x2 - x3 - x4;
    double pq = 0.5 * (-t + mpi * mpi - q2);

   
    double pl = (-x2 - x5 / 2.0) * pq + (-x1 / 2.0 - x2 / 2.0 + x3 / 2.0) * t;
 
    double ql = (-x2 - x5 / 2.0) * q2 + (-x1 / 2.0 - x2 / 2.0 + x3 / 2.0) * pq;


    double l2 = t * pow(-x1 / 2.0 - x2 / 2.0 + x3 / 2.0, 2.0) + 2.0 * pq * (-x1 / 2.0 - x2 / 2.0 + x3 / 2.0) * (-x2
        / 2.0 - 1.0 / 2.0 + x1 / 2.0 + x3 / 2.0 + x4 / 2.0) + q2 * pow(-x2 / 2.0 - 1.0 / 2.0 + x1 / 2.0 + x3 / 2.0 + x4 / 2.0,
            2.0);

    double D = (-1.0 + x1 + x2 + x3) * b * b + (3.0 / 4.0 * x2 + 1.0 / 4.0 - x1 / 4.0 - x3 / 4.0 - x4 / 4.0) * q2 + (-
        x1 - x2 - x3) * mq * mq + (x1 / 4.0 + x2 / 4.0 + x3 / 4.0) * t + x2 * pq;

    double kk = D;

    double SpPmu3 = -2.0 * ql - pl - 3.0 * kk + 3.0 * mq * mq + t / 4.0 + (-x1 / 4.0 - x2 / 4.0 + x3 / 4.0) * (4.0 * mq * mq
        + 4.0 * pq + 3.0 * t) + D / 2.0 - l2 / 2.0 + 4.0 * (-x1 / 4.0 - x2 / 4.0 + x3 / 4.0) * pl - 4.0 * (-x1 / 4.0 - x2 / 4.0 +
            x3 / 4.0) * (-l2 / 2.0 + 3.0 / 2.0 * D);



    if (k[1] > 1 - k[0])
    {
        return 0;
    }
    if (k[2] > 1 - k[0] - k[1])
    {
        return 0;
    }
    if (k[3] > 1 - k[0] - k[1] - k[2])
    {
        return 0;
    }

    else
    {

        return (SpPmu3 / (D - l2) / (D - l2) / (D - l2));
 
    }

}

double g_friaqmu1(double* k, size_t dim, void* p)
{
    (void)(dim);

    struct my_f_params* fp = (struct my_f_params*)p;
    double x1 = k[0], x2 = k[1], x3 = k[2], x4 = k[3];
    double mpi = fp->m;
    double mq = fp->mq;
    double t = fp->t;
    double b = fp->b;
    double q2 = -fp->Q2;
    double x5 = 1 - x1 - x2 - x3 - x4;
    double pq = 0.5 * (-t + mpi * mpi - q2);
    double pl = (-x2 / 2.0 - 1.0 / 2.0 + x1 / 2.0 + x3 / 2.0 + x4 / 2.0) * pq + t * (-x1 / 2.0 - x2 / 2.0 + x3 / 2.0);
    double ql = q2 * (-x2 / 2.0 - 1.0 / 2.0 + x1 / 2.0 + x3 / 2.0 + x4 / 2.0) + pq * (-x1 / 2.0 - x2 / 2.0 + x3 / 2.0);

    double l2 = t * pow(-x1 / 2.0 - x2 / 2.0 + x3 / 2.0, 2.0) + 2.0 * pq * (-x1 / 2.0 - x2 / 2.0 + x3 / 2.0) * (-x2
        / 2.0 - 1.0 / 2.0 + x1 / 2.0 + x3 / 2.0 + x4 / 2.0) + q2 * pow(-x2 / 2.0 - 1.0 / 2.0 + x1 / 2.0 + x3 / 2.0 + x4 / 2.0,
            2.0);




 double D = (-1.0 + x1 + x2 + x3) * b * b + (3.0 / 4.0 * x2 + 1.0 / 4.0 - x1 / 4.0 - x3 / 4.0 - x4 / 4.0) * q2 + (-
     x1 - x2 - x3) * mq * mq + (x1 / 4.0 + x2 / 4.0 + x3 / 4.0) * t + x2 * pq;




    double kk = D;



    double Spqmu3 = (-3.0 / 4.0 * x2 - x5 / 2.0 + x1 / 4.0 - x3 / 4.0) * (4.0 * mq * mq + 4.0 * pq + 3.0 * t) + 2.0 * ql +
        pl - kk + mq * mq + 3.0 / 4.0 * t - D / 2.0 + l2 / 2.0 + 4.0 * (-3.0 / 4.0 * x2 - x5 / 2.0 + x1 / 4.0 - x3 / 4.0) * pl
        - 4.0 * (-3.0 / 4.0 * x2 - x5 / 2.0 + x1 / 4.0 - x3 / 4.0) * (-l2 / 2.0 + 3.0 / 2.0 * D);




    if (k[1] > 1 - k[0])
    {
        return 0;
    }
    if (k[2] > 1 - k[0] - k[1])
    {
        return 0;
    }
    if (k[3] > 1 - k[0] - k[1] - k[2])
    {
        return 0;
    }

    else
    {

        return (Spqmu3 / (D - l2) / (D - l2) / (D - l2));
      
    }

}

double g_friaPmu2(double* k, size_t dim, void* p)
{
    (void)(dim);

    struct my_f_params* fp = (struct my_f_params*)p;
    double x1 = k[0], x2 = k[1], x3 = k[2], x4 = k[3];
    double mpi = fp->m;
    double mq = fp->mq;
    double t = fp->t;
    double b = fp->b;
    double q2 = -fp->Q2;
    double x5 = 1 - x1 - x2 - x3 - x4;
    double pq = 0.5 * (-t + mpi * mpi - q2);

    //k'p'
    double pl = (-x2 + x5 / 2.0) * pq + (-x1 / 2.0 - x2 / 2.0 + x3 / 2.0 + x5) * t;



    double ql = q2 * (-x2 + x5 / 2.0) + (-x1 / 2.0 - x2 / 2.0 + x3 / 2.0 + x5) * pq;


  /*  double l2 = t * pow(-3.0 / 2.0 * x1 - 3.0 / 2.0 * x2 - x3 / 2.0 + 1.0 - x4, 2.0) + 2.0 * pq * (-3.0 / 2.0 * x1
        - 3.0 / 2.0 * x2 - x3 / 2.0 + 1.0 - x4) * (-3.0 / 2.0 * x2 + 1.0 / 2.0 - x1 / 2.0 - x3 / 2.0 - x4 / 2.0) + q2 * pow(
            -3.0 / 2.0 * x2 + 1.0 / 2.0 - x1 / 2.0 - x3 / 2.0 - x4 / 2.0, 2.0);*/
    double l2= t * pow(-x1 / 2.0 - x2 / 2.0 + x3 / 2.0 + x5, 2.0) + 2.0 * pq * (-x1 / 2.0 - x2 / 2.0 + x3 / 2.0 + x5
        ) * (-x2 + x5 / 2.0) + q2 * pow(-x2 + x5 / 2.0, 2.0);



  /*  double D = (-1.0 + x1 + x2 + x3) * b * b + (3.0 / 4.0 * x2 + 1.0 / 4.0 - x1 / 4.0 - x3 / 4.0 - x4 / 4.0) * q2 + (
        1.0 - x1 - x3 - x4) * pq + (-x1 - x2 - x3) * mq * mq + (-3.0 / 4.0 * x1 - 3.0 / 4.0 * x2 - 3.0 / 4.0 * x3 + 1.0 - x4) * t
        ;*/
    double D= (-x4 - x5) * b * b + (x2 + x5 / 4.0) * q2 + (x2 + x5) * pq + (-x1 - x2 - x3) * mq * mq + (x1 / 4.0 + x2 /
        4.0 + x3 / 4.0 + x5) * t;



  



    double kk = D;

    //double SpPmu3 = -2.0 * ql - pl - 3.0 * kk + 3.0 * mq * mq + t / 4.0 + (-x1 / 4.0 - x2 / 4.0 + x3 / 4.0) * (4.0 * mq * mq
    //    + 4.0 * pq + 3.0 * t) + D / 2.0 - l2 / 2.0 + 4.0 * (-x1 / 4.0 - x2 / 4.0 + x3 / 4.0) * pl - 4.0 * (-x1 / 4.0 - x2 / 4.0 +
    //        x3 / 4.0) * (-l2 / 2.0 + 3.0 / 2.0 * D);
    double SpPmu3=-2.0 * ql - pl - 3.0 * kk + 3.0 * mq * mq + t / 4.0 + (-x1 / 4.0 - x2 / 4.0 + x3 / 4.0 + x5 / 2.0) * (
        4.0 * mq * mq + 4.0 * pq + 3.0 * t) + D / 2.0 - l2 / 2.0 + 4.0 * (-x1 / 4.0 - x2 / 4.0 + x3 / 4.0 + x5 / 2.0) * pl - 4.0 *
        (-x1 / 4.0 - x2 / 4.0 + x3 / 4.0 + x5 / 2.0) * (-l2 / 2.0 + 3.0 / 2.0 * D);




    if (k[1] > 1 - k[0])
    {
        return 0;
    }
    if (k[2] > 1 - k[0] - k[1])
    {
        return 0;
    }
    if (k[3] > 1 - k[0] - k[1] - k[2])
    {
        return 0;
    }

    else
    {

        return (SpPmu3 / (D - l2) / (D - l2) / (D - l2));

    }

}

double g_friaqmu2(double* k, size_t dim, void* p)
{
    (void)(dim);

    struct my_f_params* fp = (struct my_f_params*)p;
    double x1 = k[0], x2 = k[1], x3 = k[2], x4 = k[3];
    double mpi = fp->m;
    double mq = fp->mq;
    double t = fp->t;
    double b = fp->b;
    double q2 = -fp->Q2;
    double x5 = 1 - x1 - x2 - x3 - x4;
    double pq = 0.5 * (-t + mpi * mpi - q2);

    //k'p'
    double pl = (-3.0 / 2.0 * x2 + 1.0 / 2.0 - x1 / 2.0 - x3 / 2.0 - x4 / 2.0) * pq + t * (-3.0 / 2.0 * x1 - 3.0 / 2.0
        * x2 - x3 / 2.0 + 1.0 - x4);

    

    double ql = q2 * (-3.0 / 2.0 * x2 + 1.0 / 2.0 - x1 / 2.0 - x3 / 2.0 - x4 / 2.0) + pq * (-3.0 / 2.0 * x1 - 3.0 /
        2.0 * x2 - x3 / 2.0 + 1.0 - x4);

    double l2 = t * pow(-3.0 / 2.0 * x1 - 3.0 / 2.0 * x2 - x3 / 2.0 + 1.0 - x4, 2.0) + 2.0 * pq * (-3.0 / 2.0 * x1
        - 3.0 / 2.0 * x2 - x3 / 2.0 + 1.0 - x4) * (-3.0 / 2.0 * x2 + 1.0 / 2.0 - x1 / 2.0 - x3 / 2.0 - x4 / 2.0) + q2 * pow(
            -3.0 / 2.0 * x2 + 1.0 / 2.0 - x1 / 2.0 - x3 / 2.0 - x4 / 2.0, 2.0);


    double D = (-1.0 + x1 + x2 + x3) * b * b + (3.0 / 4.0 * x2 + 1.0 / 4.0 - x1 / 4.0 - x3 / 4.0 - x4 / 4.0) * q2 + (
        1.0 - x1 - x3 - x4) * pq + (-x1 - x2 - x3) * mq * mq + (-3.0 / 4.0 * x1 - 3.0 / 4.0 * x2 - 3.0 / 4.0 * x3 + 1.0 - x4) * t
        ;

    //k'
    //double pl = (-x2 / 2.0 - 1.0 / 2.0 + x1 / 2.0 + x3 / 2.0 + x4 / 2.0) * pq + (-3.0 / 2.0 * x1 - 3.0 / 2.0 * x2 - x3
    //    / 2.0 + 1.0 - x4) * t;




    //double ql = q2 * (-x2 / 2.0 - 1.0 / 2.0 + x1 / 2.0 + x3 / 2.0 + x4 / 2.0) + (-3.0 / 2.0 * x1 - 3.0 / 2.0 * x2 - x3
    //    / 2.0 + 1.0 - x4) * pq;



    //double l2 = t * pow(-3.0 / 2.0 * x1 - 3.0 / 2.0 * x2 - x3 / 2.0 + 1.0 - x4, 2.0) + 2.0 * pq * (-3.0 / 2.0 * x1
    //    - 3.0 / 2.0 * x2 - x3 / 2.0 + 1.0 - x4) * (-x2 / 2.0 - 1.0 / 2.0 + x1 / 2.0 + x3 / 2.0 + x4 / 2.0) + q2 * pow(-x2 /
    //        2.0 - 1.0 / 2.0 + x1 / 2.0 + x3 / 2.0 + x4 / 2.0, 2.0);



    //double D = (-1.0 + x1 + x2 + x3) * b * b + (3.0 / 4.0 * x2 + 1.0 / 4.0 - x1 / 4.0 - x3 / 4.0 - x4 / 4.0) * q2 + (
    //    2.0 * x2 - 1.0 + x1 + x3 + x4) * pq + (-x1 - x2 - x3) * mq * mq + (-3.0 / 4.0 * x1 - 3.0 / 4.0 * x2 - 3.0 / 4.0 * x3 +
    //        1.0 - x4) * t;

    double kk = D;

    //double Spqmu3 = (-3.0 / 4.0 * x2 - x5 / 2.0 + x1 / 4.0 - x3 / 4.0) * (4.0 * mq * mq + 4.0 * pq + 3.0 * t) + 2.0 * ql +
    //    pl - kk + mq * mq + 3.0 / 4.0 * t - D / 2.0 + l2 / 2.0 + 4.0 * (-3.0 / 4.0 * x2 - x5 / 2.0 + x1 / 4.0 - x3 / 4.0) * pl
    //    - 4.0 * (-3.0 / 4.0 * x2 - x5 / 2.0 + x1 / 4.0 - x3 / 4.0) * (-l2 / 2.0 + 3.0 / 2.0 * D);
    double Spqmu3=(-3.0 / 4.0 * x2 - x5 / 2.0 + x1 / 4.0 - x3 / 4.0)* (4.0 * mq * mq + 4.0 * pq + 3.0 * t) + 2.0 * ql +
        pl - kk + mq * mq + 3.0 / 4.0 * t - D / 2.0 + l2 / 2.0 + 4.0 * (-3.0 / 4.0 * x2 - x5 / 2.0 + x1 / 4.0 - x3 / 4.0) * pl
        - 4.0 * (-3.0 / 4.0 * x2 - x5 / 2.0 + x1 / 4.0 - x3 / 4.0) * (-l2 / 2.0 + 3.0 / 2.0 * D);




    if (k[1] > 1 - k[0])
    {
        return 0;
    }
    if (k[2] > 1 - k[0] - k[1])
    {
        return 0;
    }
    if (k[3] > 1 - k[0] - k[1] - k[2])
    {
        return 0;
    }

    else
    {

        return (Spqmu3 / (D - l2) / (D - l2) / (D - l2));

    }

}


double g_friaPmu3(double* k, size_t dim, void* p)
{
    (void)(dim);

    struct my_f_params* fp = (struct my_f_params*)p;
    double x1 = k[0], x2 = k[1], x3 = k[2], x4 = k[3];
    double mpi = fp->m;
    double mq = fp->mq;
    double t = fp->t;
    double b = fp->b;
    double q2 = -fp->Q2;
    double x5 = 1 - x1 - x2 - x3 - x4;
    double pq = 0.5 * (-t + mpi * mpi - q2);

    //k'p'

    double pl = (-x2 / 2.0 - 1.0 / 2.0 + x1 / 2.0 + x3 / 2.0 + x4 / 2.0) * pq + t * (-x1 / 2.0 - x2 / 2.0 + x3 / 2.0 +
        x4);

    double ql = q2 * (-x2 / 2.0 - 1.0 / 2.0 + x1 / 2.0 + x3 / 2.0 + x4 / 2.0) + (-x1 / 2.0 - x2 / 2.0 + x3 / 2.0 + x4)
        * pq;

    double l2 = t * pow(-3.0 / 2.0 * x1 - 3.0 / 2.0 * x2 - x3 / 2.0 + 1.0, 2.0) + 2.0 * pq * (-3.0 / 2.0 * x1 - 3.0
        / 2.0 * x2 - x3 / 2.0 + 1.0) * (-3.0 / 2.0 * x2 + 1.0 / 2.0 - x1 / 2.0 - x3 / 2.0 - x4 / 2.0) + q2 * pow(-3.0 / 2.0 *
            x2 + 1.0 / 2.0 - x1 / 2.0 - x3 / 2.0 - x4 / 2.0, 2.0);



    double D = (-1.0 + x1 + x2 + x3) * b * b + (3.0 / 4.0 * x2 + 1.0 / 4.0 - x1 / 4.0 - x3 / 4.0 - x4 / 4.0) * q2 + (
        1.0 - x1 - x3 - x4) * pq + (-x1 - x2 - x3) * mq * mq + (-3.0 / 4.0 * x1 - 3.0 / 4.0 * x2 - 3.0 / 4.0 * x3 + 1.0) * t;

    //k'

    //double pl = (-x2 / 2.0 - 1.0 / 2.0 + x1 / 2.0 + x3 / 2.0 + x4 / 2.0) * pq + t * (-3.0 / 2.0 * x1 - 3.0 / 2.0 * x2 -
    //    x3 / 2.0 + 1.0);



    //double ql = q2 * (-x2 / 2.0 - 1.0 / 2.0 + x1 / 2.0 + x3 / 2.0 + x4 / 2.0) + pq * (-3.0 / 2.0 * x1 - 3.0 / 2.0 * x2
    //    - x3 / 2.0 + 1.0);


    //double l2 = t * pow(-3.0 / 2.0 * x1 - 3.0 / 2.0 * x2 - x3 / 2.0 + 1.0, 2.0) + 2.0 * pq * (-3.0 / 2.0 * x1 - 3.0
    //    / 2.0 * x2 - x3 / 2.0 + 1.0) * (-x2 / 2.0 - 1.0 / 2.0 + x1 / 2.0 + x3 / 2.0 + x4 / 2.0) + q2 * pow(-x2 / 2.0 - 1.0 /
    //        2.0 + x1 / 2.0 + x3 / 2.0 + x4 / 2.0, 2.0);



    //double D = (-1.0 + x1 + x2 + x3) * b * b + (3.0 / 4.0 * x2 + 1.0 / 4.0 - x1 / 4.0 - x3 / 4.0 - x4 / 4.0) * q2 + (
    //    2.0 * x2 - 1.0 + x1 + x3 + x4) * pq + (-x1 - x2 - x3) * mq * mq + (-3.0 / 4.0 * x1 - 3.0 / 4.0 * x2 - 3.0 / 4.0 * x3 +
    //        1.0) * t;


    double kk = D;

    double SpPmu3 = -2.0 * ql - pl - 3.0 * kk + 3.0 * mq * mq + t / 4.0 + (-x1 / 4.0 - x2 / 4.0 + x3 / 4.0) * (4.0 * mq * mq
        + 4.0 * pq + 3.0 * t) + D / 2.0 - l2 / 2.0 + 4.0 * (-x1 / 4.0 - x2 / 4.0 + x3 / 4.0) * pl - 4.0 * (-x1 / 4.0 - x2 / 4.0 +
            x3 / 4.0) * (-l2 / 2.0 + 3.0 / 2.0 * D);



    if (k[1] > 1 - k[0])
    {
        return 0;
    }
    if (k[2] > 1 - k[0] - k[1])
    {
        return 0;
    }
    if (k[3] > 1 - k[0] - k[1] - k[2])
    {
        return 0;
    }

    else
    {

        return (SpPmu3 / (D - l2) / (D - l2) / (D - l2));

    }

}

double g_friaqmu3(double* k, size_t dim, void* p)
{
    (void)(dim);

    struct my_f_params* fp = (struct my_f_params*)p;
    double x1 = k[0], x2 = k[1], x3 = k[2], x4 = k[3];
    double mpi = fp->m;
    double mq = fp->mq;
    double t = fp->t;
    double b = fp->b;
    double q2 = -fp->Q2;
    double x5 = 1 - x1 - x2 - x3 - x4;
    double pq = 0.5 * (-t + mpi * mpi - q2);
 

    //k'p'

    double pl = (-x2 / 2.0 - 1.0 / 2.0 + x1 / 2.0 + x3 / 2.0 + x4 / 2.0) * pq + t * (-x1 / 2.0 - x2 / 2.0 + x3 / 2.0 +
        x4);
    double ql = q2 * (-x2 / 2.0 - 1.0 / 2.0 + x1 / 2.0 + x3 / 2.0 + x4 / 2.0) + (-x1 / 2.0 - x2 / 2.0 + x3 / 2.0 + x4)
        * pq;


    double l2 = t * pow(-3.0 / 2.0 * x1 - 3.0 / 2.0 * x2 - x3 / 2.0 + 1.0, 2.0) + 2.0 * pq * (-3.0 / 2.0 * x1 - 3.0
        / 2.0 * x2 - x3 / 2.0 + 1.0) * (-3.0 / 2.0 * x2 + 1.0 / 2.0 - x1 / 2.0 - x3 / 2.0 - x4 / 2.0) + q2 * pow(-3.0 / 2.0 *
            x2 + 1.0 / 2.0 - x1 / 2.0 - x3 / 2.0 - x4 / 2.0, 2.0);



    double D = (-1.0 + x1 + x2 + x3) * b * b + (3.0 / 4.0 * x2 + 1.0 / 4.0 - x1 / 4.0 - x3 / 4.0 - x4 / 4.0) * q2 + (
        1.0 - x1 - x3 - x4) * pq + (-x1 - x2 - x3) * mq * mq + (-3.0 / 4.0 * x1 - 3.0 / 4.0 * x2 - 3.0 / 4.0 * x3 + 1.0) * t;

    //k'

    //double pl = (-x2 / 2.0 - 1.0 / 2.0 + x1 / 2.0 + x3 / 2.0 + x4 / 2.0) * pq + t * (-3.0 / 2.0 * x1 - 3.0 / 2.0 * x2 -
    //    x3 / 2.0 + 1.0);



    //double ql = q2 * (-x2 / 2.0 - 1.0 / 2.0 + x1 / 2.0 + x3 / 2.0 + x4 / 2.0) + pq * (-3.0 / 2.0 * x1 - 3.0 / 2.0 * x2
    //    - x3 / 2.0 + 1.0);


    //double l2 = t * pow(-3.0 / 2.0 * x1 - 3.0 / 2.0 * x2 - x3 / 2.0 + 1.0, 2.0) + 2.0 * pq * (-3.0 / 2.0 * x1 - 3.0
    //    / 2.0 * x2 - x3 / 2.0 + 1.0) * (-x2 / 2.0 - 1.0 / 2.0 + x1 / 2.0 + x3 / 2.0 + x4 / 2.0) + q2 * pow(-x2 / 2.0 - 1.0 /
    //        2.0 + x1 / 2.0 + x3 / 2.0 + x4 / 2.0, 2.0);



    //double D = (-1.0 + x1 + x2 + x3) * b * b + (3.0 / 4.0 * x2 + 1.0 / 4.0 - x1 / 4.0 - x3 / 4.0 - x4 / 4.0) * q2 + (
    //    2.0 * x2 - 1.0 + x1 + x3 + x4) * pq + (-x1 - x2 - x3) * mq * mq + (-3.0 / 4.0 * x1 - 3.0 / 4.0 * x2 - 3.0 / 4.0 * x3 +
    //        1.0) * t;


    double kk = D;

    double Spqmu3 = (-3.0 / 4.0 * x2 - x5 / 2.0 + x1 / 4.0 - x3 / 4.0) * (4.0 * mq * mq + 4.0 * pq + 3.0 * t) + 2.0 * ql +
        pl - kk + mq * mq + 3.0 / 4.0 * t - D / 2.0 + l2 / 2.0 + 4.0 * (-3.0 / 4.0 * x2 - x5 / 2.0 + x1 / 4.0 - x3 / 4.0) * pl
        - 4.0 * (-3.0 / 4.0 * x2 - x5 / 2.0 + x1 / 4.0 - x3 / 4.0) * (-l2 / 2.0 + 3.0 / 2.0 * D);




    if (k[1] > 1 - k[0])
    {
        return 0;
    }
    if (k[2] > 1 - k[0] - k[1])
    {
        return 0;
    }
    if (k[3] > 1 - k[0] - k[1] - k[2])
    {
        return 0;
    }

    else
    {

        return (Spqmu3 / (D - l2) / (D - l2) / (D - l2));

    }

}

double g_friaPmu4(double* k, size_t dim, void* p)
{
    (void)(dim);

    struct my_f_params* fp = (struct my_f_params*)p;
    double x1 = k[0], x2 = k[1], x3 = k[2], x4 = k[3];
    double mpi = fp->m;
    double mq = fp->mq;
    double t = fp->t;
    double b = fp->b;
    double q2 = -fp->Q2;
    double x5 = 1 - x1 - x2 - x3 - x4;
    double pq = 0.5 * (-t + mpi * mpi - q2);

 
    double pl = (-x2 / 2.0 - 1.0 / 2.0 + x1 / 2.0 + x3 / 2.0 + x4 / 2.0) * pq + t * (-x1 / 2.0 - x2 / 2.0 + x3 / 2.0 +
        x4);

    double ql = q2 * (-x2 / 2.0 - 1.0 / 2.0 + x1 / 2.0 + x3 / 2.0 + x4 / 2.0) + (-x1 / 2.0 - x2 / 2.0 + x3 / 2.0 + x4)
        * pq;


    double l2 = t * pow(-x1 / 2.0 - x2 / 2.0 + x3 / 2.0 + x4, 2.0) + 2.0 * pq * (-x1 / 2.0 - x2 / 2.0 + x3 / 2.0 + x4
        ) * (-x2 / 2.0 - 1.0 / 2.0 + x1 / 2.0 + x3 / 2.0 + x4 / 2.0) + q2 * pow(-x2 / 2.0 - 1.0 / 2.0 + x1 / 2.0 + x3 / 2.0 +
            x4 / 2.0, 2.0);

    double D = (-1.0 + x1 + x2 + x3) * b * b + (3.0 / 4.0 * x2 + 1.0 / 4.0 - x1 / 4.0 - x3 / 4.0 - x4 / 4.0) * q2 + (-
        x1 - x2 - x3) * mq * mq + (x1 / 4.0 + x2 / 4.0 + x3 / 4.0 + x4) * t + x2 * pq;

   


    double kk = D;

    double SpPmu3 = -2.0 * ql - pl - 3.0 * kk + 3.0 * mq * mq + t / 4.0 + (-x1 / 4.0 - x2 / 4.0 + x3 / 4.0) * (4.0 * mq * mq
        + 4.0 * pq + 3.0 * t) + D / 2.0 - l2 / 2.0 + 4.0 * (-x1 / 4.0 - x2 / 4.0 + x3 / 4.0) * pl - 4.0 * (-x1 / 4.0 - x2 / 4.0 +
            x3 / 4.0) * (-l2 / 2.0 + 3.0 / 2.0 * D);



    if (k[1] > 1 - k[0])
    {
        return 0;
    }
    if (k[2] > 1 - k[0] - k[1])
    {
        return 0;
    }
    if (k[3] > 1 - k[0] - k[1] - k[2])
    {
        return 0;
    }

    else
    {

        return (SpPmu3/ (D - l2) / (D - l2) / (D - l2));
        
    }

}

double g_friaqmu4(double* k, size_t dim, void* p)
{
    (void)(dim);

    struct my_f_params* fp = (struct my_f_params*)p;
    double x1 = k[0], x2 = k[1], x3 = k[2], x4 = k[3];
    double mpi = fp->m;
    double mq = fp->mq;
    double t = fp->t;
    double b = fp->b;
    double q2 = -fp->Q2;
    double x5 = 1 - x1 - x2 - x3 - x4;
    double pq = 0.5 * (-t + mpi * mpi - q2);
    double pl = (-x2 / 2.0 - 1.0 / 2.0 + x1 / 2.0 + x3 / 2.0 + x4 / 2.0) * pq + t * (-x1 / 2.0 - x2 / 2.0 + x3 / 2.0 +
        x4);

    double ql = q2 * (-x2 / 2.0 - 1.0 / 2.0 + x1 / 2.0 + x3 / 2.0 + x4 / 2.0) + (-x1 / 2.0 - x2 / 2.0 + x3 / 2.0 + x4)
        * pq;


    double l2 = t * pow(-x1 / 2.0 - x2 / 2.0 + x3 / 2.0 + x4, 2.0) + 2.0 * pq * (-x1 / 2.0 - x2 / 2.0 + x3 / 2.0 + x4
        ) * (-x2 / 2.0 - 1.0 / 2.0 + x1 / 2.0 + x3 / 2.0 + x4 / 2.0) + q2 * pow(-x2 / 2.0 - 1.0 / 2.0 + x1 / 2.0 + x3 / 2.0 +
            x4 / 2.0, 2.0);

    double D = (-1.0 + x1 + x2 + x3) * b * b + (3.0 / 4.0 * x2 + 1.0 / 4.0 - x1 / 4.0 - x3 / 4.0 - x4 / 4.0) * q2 + (-
        x1 - x2 - x3) * mq * mq + (x1 / 4.0 + x2 / 4.0 + x3 / 4.0 + x4) * t + x2 * pq;

    double kk = D;

    double Spqmu3 = (-3.0 / 4.0 * x2 - x5 / 2.0 + x1 / 4.0 - x3 / 4.0) * (4.0 * mq * mq + 4.0 * pq + 3.0 * t) + 2.0 * ql +
        pl - kk + mq * mq + 3.0 / 4.0 * t - D / 2.0 + l2 / 2.0 + 4.0 * (-3.0 / 4.0 * x2 - x5 / 2.0 + x1 / 4.0 - x3 / 4.0) * pl
        - 4.0 * (-3.0 / 4.0 * x2 - x5 / 2.0 + x1 / 4.0 - x3 / 4.0) * (-l2 / 2.0 + 3.0 / 2.0 * D);




    if (k[1] > 1 - k[0])
    {
        return 0;
    }
    if (k[2] > 1 - k[0] - k[1])
    {
        return 0;
    }
    if (k[3] > 1 - k[0] - k[1] - k[2])
    {
        return 0;
    }

    else
    {

        return (Spqmu3 / (D - l2) / (D - l2) / (D - l2));
       
    }

}




int main()
{



    double res_f, err_f;
    double xl_f[4] = { 0,0,0,0 };
    double xu_f[4] = { 1,1,1,1 };

    double res_f11, res_f12, res_f110, err_f11, err_f12, err_f110, res_f21, res_f22, res_f210, err_f21, err_f22, err_f210;
    double res_f31, res_f32, res_f310, err_f31, err_f32, err_f310, res_f41, res_f42, res_f410, err_f41, err_f42, err_f410;

    const gsl_rng_type* T;
    gsl_rng* r;

    gsl_rng_env_setup();

    T = gsl_rng_default;
    r = gsl_rng_alloc(T);
    double m = 0.14;
    double mq = 0.22;
    double Q2 = 0.526;
    double t = -0.026;
    double b = 0.6;
    double b1 = 0.600001;
    double N21 = -0.00596118;//4.69579e-07
    double N22 = -0.0174739;//2.00517e-06
    double N23 = -0.00324541;//3.87599e-07
    double N24 = -0.00284119;
    double N25 = -0.0033686;
    double N26 = -0.0496939;
    double N27 = -0.0104346;
    double N28 = -0.00613619;
    double Npk1 = -0.00599878;
    double norm_pk = -33.7521;
    double norm_k = -33.701;
    ofstream file("WTI.txt");
    //for (double Q2 = 0;Q2 < 5.1;Q2 += 0.05)
    {

        {


            struct my_f_params params1 = { Q2,t,m,mq,b,b1,N21 };

            gsl_monte_vegas_state* s_f11 = gsl_monte_vegas_alloc(4);
            gsl_monte_function G_f11 = { &g_friaPmu1, 4,&params1 };
            gsl_monte_vegas_integrate(&G_f11, xl_f, xu_f, 4, 100000, r, s_f11,
                &res_f11, &err_f11);
            do
            {
                gsl_monte_vegas_integrate(&G_f11, xl_f, xu_f, 4, 100000, r, s_f11,
                    &res_f11, &err_f11);
            } while (fabs(gsl_monte_vegas_chisq(s_f11) - 1.0) > 0.5);

            struct my_f_params params10 = { 0,t,m,mq,b,b1,N21 };
            gsl_monte_vegas_state* s_f110 = gsl_monte_vegas_alloc(4);
            gsl_monte_function G_f110 = { &g_friaPmu1, 4,&params10 };
            gsl_monte_vegas_integrate(&G_f110, xl_f, xu_f, 4, 100000, r, s_f110,
                &res_f110, &err_f110);
            do
            {
                gsl_monte_vegas_integrate(&G_f110, xl_f, xu_f, 4, 100000, r, s_f110,
                    &res_f110, &err_f110);
            } while (fabs(gsl_monte_vegas_chisq(s_f110) - 1.0) > 0.5);

            gsl_monte_vegas_state* s_f12 = gsl_monte_vegas_alloc(4);
            gsl_monte_function G_f12 = { &g_friaqmu1, 4,&params1 };
            gsl_monte_vegas_integrate(&G_f12, xl_f, xu_f, 4, 100000, r, s_f12,
                &res_f12, &err_f12);
            do
            {
                gsl_monte_vegas_integrate(&G_f12, xl_f, xu_f, 4, 100000, r, s_f12,
                    &res_f12, &err_f12);
            } while (fabs(gsl_monte_vegas_chisq(s_f12) - 1.0) > 0.5);

            //-----------------------------------------------------

            
            gsl_monte_vegas_state* s_f21 = gsl_monte_vegas_alloc(4);
            gsl_monte_function G_f21 = { &g_friaPmu2, 4,&params1 };
            gsl_monte_vegas_integrate(&G_f21, xl_f, xu_f, 4, 100000, r, s_f21,
                &res_f21, &err_f21);
            do
            {
                gsl_monte_vegas_integrate(&G_f21, xl_f, xu_f, 4, 100000, r, s_f21,
                    &res_f21, &err_f21);
            } while (fabs(gsl_monte_vegas_chisq(s_f21) - 1.0) > 0.5);

        
            gsl_monte_vegas_state* s_f210 = gsl_monte_vegas_alloc(4);
            gsl_monte_function G_f210 = { &g_friaPmu2, 4,&params10 };
            gsl_monte_vegas_integrate(&G_f210, xl_f, xu_f, 4, 100000, r, s_f210,
                &res_f210, &err_f210);
            do
            {
                gsl_monte_vegas_integrate(&G_f210, xl_f, xu_f, 4, 100000, r, s_f210,
                    &res_f210, &err_f210);
            } while (fabs(gsl_monte_vegas_chisq(s_f210) - 1.0) > 0.5);

            gsl_monte_vegas_state* s_f22 = gsl_monte_vegas_alloc(4);
            gsl_monte_function G_f22 = { &g_friaqmu2, 4,&params1 };
            gsl_monte_vegas_integrate(&G_f22, xl_f, xu_f, 4, 100000, r, s_f22,
                &res_f22, &err_f22);
            do
            {
                gsl_monte_vegas_integrate(&G_f22, xl_f, xu_f, 4, 100000, r, s_f22,
                    &res_f22, &err_f22);
            } while (fabs(gsl_monte_vegas_chisq(s_f22) - 1.0) > 0.5);

            //------------------------------------------------------------------

         
            gsl_monte_vegas_state* s_f31 = gsl_monte_vegas_alloc(4);
            gsl_monte_function G_f31 = { &g_friaPmu3, 4,&params1 };
            gsl_monte_vegas_integrate(&G_f31, xl_f, xu_f, 4, 100000, r, s_f31,
                &res_f31, &err_f31);
            do
            {
                gsl_monte_vegas_integrate(&G_f31, xl_f, xu_f, 4, 100000, r, s_f31,
                    &res_f31, &err_f31);
            } while (fabs(gsl_monte_vegas_chisq(s_f31) - 1.0) > 0.5);

         
            gsl_monte_vegas_state* s_f310 = gsl_monte_vegas_alloc(4);
            gsl_monte_function G_f310 = { &g_friaPmu3, 4,&params10 };
            gsl_monte_vegas_integrate(&G_f310, xl_f, xu_f, 4, 100000, r, s_f310,
                &res_f310, &err_f310);
            do
            {
                gsl_monte_vegas_integrate(&G_f310, xl_f, xu_f, 4, 100000, r, s_f310,
                    &res_f310, &err_f310);
            } while (fabs(gsl_monte_vegas_chisq(s_f310) - 1.0) > 0.5);

            gsl_monte_vegas_state* s_f32 = gsl_monte_vegas_alloc(4);
            gsl_monte_function G_f32 = { &g_friaqmu3, 4,&params1 };
            gsl_monte_vegas_integrate(&G_f32, xl_f, xu_f, 4, 100000, r, s_f32,
                &res_f32, &err_f32);
            do
            {
                gsl_monte_vegas_integrate(&G_f32, xl_f, xu_f, 4, 100000, r, s_f32,
                    &res_f32, &err_f32);
            } while (fabs(gsl_monte_vegas_chisq(s_f32) - 1.0) > 0.5);

            //------------------------------------------------------------

       
            gsl_monte_vegas_state* s_f41 = gsl_monte_vegas_alloc(4);
            gsl_monte_function G_f41 = { &g_friaPmu4, 4,&params1 };
            gsl_monte_vegas_integrate(&G_f41, xl_f, xu_f, 4, 100000, r, s_f41,
                &res_f41, &err_f41);
            do
            {
                gsl_monte_vegas_integrate(&G_f41, xl_f, xu_f, 4, 100000, r, s_f41,
                    &res_f41, &err_f41);
            } while (fabs(gsl_monte_vegas_chisq(s_f41) - 1.0) > 0.5);

            gsl_monte_vegas_state* s_f410 = gsl_monte_vegas_alloc(4);
            gsl_monte_function G_f410 = { &g_friaPmu4, 4,&params10 };
            gsl_monte_vegas_integrate(&G_f410, xl_f, xu_f, 4, 100000, r, s_f410,
                &res_f410, &err_f410);
            do
            {
                gsl_monte_vegas_integrate(&G_f410, xl_f, xu_f, 4, 100000, r, s_f410,
                    &res_f410, &err_f410);
            } while (fabs(gsl_monte_vegas_chisq(s_f410) - 1.0) > 0.5);

            gsl_monte_vegas_state* s_f42 = gsl_monte_vegas_alloc(4);
            gsl_monte_function G_f42 = { &g_friaqmu4, 4,&params1 };
            gsl_monte_vegas_integrate(&G_f42, xl_f, xu_f, 4, 100000, r, s_f42,
                &res_f42, &err_f42);
            do
            {
                gsl_monte_vegas_integrate(&G_f42, xl_f, xu_f, 4, 100000, r, s_f42,
                    &res_f42, &err_f42);
            } while (fabs(gsl_monte_vegas_chisq(s_f42) - 1.0) > 0.5);

            //////-------------------------------------------------------------
            //cout <<" F1: "<< (res_f11+ res_f21+ res_f31 + res_f41)/ norm_pk << endl;
            //cout << " F10: " << (res_f110 + res_f210 + res_f310 + res_f410) / norm_pk << endl;
            //cout << "g " << (res_f12+ res_f22+ res_f32+ res_f42) / norm_pk / (t - m * m) << endl;
            //cout << " eqg " <<  (res_f110 - res_f11)/Q2/norm_pk;
           // cout << res_f11 << " " << res_f21 << " " << res_f31 << " " << res_f41 << endl;
            //cout << res_f110 << " " << res_f210 << " " << res_f310 << " " << res_f410 << endl;
            //cout << res_f12 << " " << res_f22 << " " << res_f32 << " " << res_f42 << endl;*/
           // cout << " F10: " << (res_f110 + res_f210 + res_f310 + res_f410)  << endl;
            cout << " F1: " << (res_f21 ) << endl;
        }


    }

   

    file.close();
    return 0;
}

// Запуск программы: CTRL+F5 или меню "Отладка" > "Запуск без отладки"
// Отладка программы: F5 или меню "Отладка" > "Запустить отладку"

// Советы по началу работы 
//   1. В окне обозревателя решений можно добавлять файлы и управлять ими.
//   2. В окне Team Explorer можно подключиться к системе управления версиями.
//   3. В окне "Выходные данные" можно просматривать выходные данные сборки и другие сообщения.
//   4. В окне "Список ошибок" можно просматривать ошибки.
//   5. Последовательно выберите пункты меню "Проект" > "Добавить новый элемент", чтобы создать файлы кода, или "Проект" > "Добавить существующий элемент", чтобы добавить в проект существующие файлы кода.
//   6. Чтобы снова открыть этот проект позже, выберите пункты меню "Файл" > "Открыть" > "Проект" и выберите SLN-файл.


// Запуск программы: CTRL+F5 или меню "Отладка" > "Запуск без отладки"
// Отладка программы: F5 или меню "Отладка" > "Запустить отладку"

// Советы по началу работы 
//   1. В окне обозревателя решений можно добавлять файлы и управлять ими.
//   2. В окне Team Explorer можно подключиться к системе управления версиями.
//   3. В окне "Выходные данные" можно просматривать выходные данные сборки и другие сообщения.
//   4. В окне "Список ошибок" можно просматривать ошибки.
//   5. Последовательно выберите пункты меню "Проект" > "Добавить новый элемент", чтобы создать файлы кода, или "Проект" > "Добавить существующий элемент", чтобы добавить в проект существующие файлы кода.
//   6. Чтобы снова открыть этот проект позже, выберите пункты меню "Файл" > "Открыть" > "Проект" и выберите SLN-файл.


// Запуск программы: CTRL+F5 или меню "Отладка" > "Запуск без отладки"
// Отладка программы: F5 или меню "Отладка" > "Запустить отладку"

// Советы по началу работы 
//   1. В окне обозревателя решений можно добавлять файлы и управлять ими.
//   2. В окне Team Explorer можно подключиться к системе управления версиями.
//   3. В окне "Выходные данные" можно просматривать выходные данные сборки и другие сообщения.
//   4. В окне "Список ошибок" можно просматривать ошибки.
//   5. Последовательно выберите пункты меню "Проект" > "Добавить новый элемент", чтобы создать файлы кода, или "Проект" > "Добавить существующий элемент", чтобы добавить в проект существующие файлы кода.
//   6. Чтобы снова открыть этот проект позже, выберите пункты меню "Файл" > "Открыть" > "Проект" и выберите SLN-файл.
