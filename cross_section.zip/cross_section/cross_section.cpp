﻿// cross_section.cpp : Этот файл содержит функцию "main". Здесь начинается и заканчивается выполнение программы.
//

#include<iostream>
#include<fstream>
#include <stdlib.h>
#include<cmath>
#include<complex>
#define _USE_MATH_DEFINES
#include <gsl/gsl_math.h>
#include <gsl/gsl_monte.h>
#include <gsl/gsl_monte_plain.h>
#include <gsl/gsl_monte_miser.h>
#include <gsl/gsl_monte_vegas.h>
using namespace std;

int main()
{
  
    double mpi = 0.14;
    double Fpi = 0.1691;
    double Q2 = 2.215;
    double t = -0.145;
    double W = 2.308;
    double mp = 0.938272089;
    double lambdapi = 0.8;
    double Gpinn = 13.4;
    double G = Gpinn * ((lambdapi * lambdapi - mpi * mpi) / (lambdapi * lambdapi - t));
    double N = 32.0 * M_PI * (W * W - mp * mp) * sqrt((W * W - mp * mp) * (W * W - mp * mp) + Q2 * Q2 + 2.0 * Q2 * (W * W + mp * mp));
    double con = 15372.0571;
    double dsigma,dsigma1;
    dsigma = (4.0 / M_PI) * (con / N) * G * G * (-t) * Q2 * Fpi*Fpi / (t - mpi * mpi) / (t - mpi * mpi)/137.0;
    cout << dsigma;
}

// Запуск программы: CTRL+F5 или меню "Отладка" > "Запуск без отладки"
// Отладка программы: F5 или меню "Отладка" > "Запустить отладку"

// Советы по началу работы 
//   1. В окне обозревателя решений можно добавлять файлы и управлять ими.
//   2. В окне Team Explorer можно подключиться к системе управления версиями.
//   3. В окне "Выходные данные" можно просматривать выходные данные сборки и другие сообщения.
//   4. В окне "Список ошибок" можно просматривать ошибки.
//   5. Последовательно выберите пункты меню "Проект" > "Добавить новый элемент", чтобы создать файлы кода, или "Проект" > "Добавить существующий элемент", чтобы добавить в проект существующие файлы кода.
//   6. Чтобы снова открыть этот проект позже, выберите пункты меню "Файл" > "Открыть" > "Проект" и выберите SLN-файл.
