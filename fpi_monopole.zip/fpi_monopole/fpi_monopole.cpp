﻿// fpi_monopole.cpp : Этот файл содержит функцию "main". Здесь начинается и заканчивается выполнение программы.
//

#include<iostream>
#include<fstream>
#include <stdlib.h>
#include<cmath>
#include<complex>
#define _USE_MATH_DEFINES
#include <gsl/gsl_math.h>
#include <gsl/gsl_monte.h>
#include <gsl/gsl_monte_plain.h>
#include <gsl/gsl_monte_miser.h>
#include <gsl/gsl_monte_vegas.h>
using namespace std;
struct my_f_params { double Q2;double m;double mq;double b;double b2;double N; };
struct my_f_params_1 { double Q2;double m;double mq;double b;double b2;double N;double alpha; };
const double hc = 0.197327053;
const double fpiexp = 0.13041;
const double rpigexp = 0.659;
const double fpiexperr = 0.0002;
const double rpigexperr = 0.004;

complex<double> i_ = 0. + 1i;
double f1(double k4, double k, double Q2, double m, double mq, double b)
{
    double q2 = -Q2;
    double eta = -q2 / (4 * m * m);
    return (-k4 * k4 - k * k - b * b);
}
complex<double> f2(double k4, double k, double costheta, double Q2, double m, double mq, double b)
{
    double q2 = -Q2;
    double eta = -q2 / (4 * m * m);

    return(m * m / 4 + i_ * m * sqrt(1 + eta) * k4 + m * sqrt(eta) * k * costheta - k4 * k4 - k * k - mq * mq);
}
complex<double> f4(double k4, double k, double costheta, double Q2, double m, double mq, double b)
{
    double q2 = -Q2;
    double eta = -q2 / (4 * m * m);

    return(m * m / 4 - i_ * m * sqrt(1 + eta) * k4 - m * sqrt(eta) * k * costheta - k4 * k4 - k * k - mq * mq);
}
double gwrmonopole(double* x, size_t dim, void* p)
{
    (void)(dim);
    struct my_f_params* fp = (struct my_f_params*)p;
    double* k = new double[3];
    k[0] = x[0] / (1 - x[0]);
    k[1] = x[1] / (1 - x[1]);
    k[2] = x[2];
    return real(-4 * sqrt(3.) * sqrt(-fp->N) *(k[1] * k[1] * 2 * 2 * M_PI * fp->mq /(sqrt(2.)*4 * M_PI * M_PI )/ ((1 - x[0]) * (1 - x[0]) * (1 - x[1]) * (1 - x[1]) * f1(k[0], k[1], fp->Q2, fp->m, fp->mq,fp->b) * f2(k[0], k[1], k[2], fp->Q2, fp->m, fp->mq, fp->b) * f4(k[0], k[1], k[2], fp->Q2, fp->m, fp->mq, fp->b))));

}
double gfmonopole(double* k, size_t dim, void* p)
{
    (void)(dim);
    struct my_f_params* fp = (struct my_f_params*)p;
    double x1 = k[0], x2 = k[1];
    double D = (-fp->m * fp->m / 4 + fp->mq * fp->mq) * (1 - x1) + fp->b * fp->b * x1;
    double l2 = -fp->m * fp->m * (2 * x2 - 1 + x1) * (2 * x2 - 1 + x1) / 4.;
    if (k[1] > 1 - k[0])
    {
        return 0;
    }
    //else return (M_PI * M_PI * fp->mq*4*sqrt(3)*sqrt(-fp->N) / (D-l2)/(sqrt(2)*4*M_PI*M_PI));
    else return (M_PI * M_PI * fp->mq * 4 * sqrt(3) * sqrt(-fp->N) / ((fp->mq * fp->mq - fp->m * fp->m / 4) * (x1 + x2) + (-x2 - x1 + 1) * fp->b * fp->b + fp->m * fp->m / 4 * (x1 - x2) * (x1 - x2)) / (sqrt(2) * 4 * M_PI * M_PI));
    //(fp->mq* fp->mq - fp->m* fp->m / 4)* (x1 + x2) + (-x2 - x1 + 1) * fp->b* fp->b + fp->m* fp->m / 4 * (x1 - x2)*(x1-x2)
    //4*sqrt(3)*sqrt(-fp->N)/sqrt(2)
    //-4 * sqrt(3.) * N2 * res2 / (sqrt(2.))
}
double gfmonopole_pk(double* k, size_t dim, void* p)
{
    (void)(dim);
    struct my_f_params_1* fp = (struct my_f_params_1*)p;
    double x1 = k[0], x2 = k[1];
    double alpha = fp->alpha;
    double D = -fp->b * fp->b * x1 - fp->m*fp->m * x1 / 4.0 + fp->m * fp->m / 4.0 + fp->mq * fp->mq * x1 - fp->mq * fp->mq;
    double l2 = fp->m * fp->m * pow(-alpha * x1 / 2.0 + x2 - 1.0 / 2.0 + x1 / 2.0, 2.0);
    if (k[1] > 1 - k[0])
    {
        return 0;
    }
    else return (-M_PI * M_PI * fp->mq * 4 * sqrt(3) * sqrt(-fp->N) / (D - l2) / (sqrt(2) * 4 * M_PI * M_PI));
    //4*sqrt(3)*sqrt(-fp->N)/sqrt(2)
    //-4 * sqrt(3.) * N2 * res2 / (sqrt(2.))
}
double gfdipole(double* k, size_t dim, void* p)
{
    (void)(dim);
    struct my_f_params* fp = (struct my_f_params*)p;
    double x1 = k[0], x2 = k[1];
    double D = (-fp->m * fp->m / 4 + fp->mq * fp->mq) * (1 - x1 ) + fp->b * fp->b * x1;
    double l2 = -fp->m * fp->m * (2*x2- 1 + x1 ) * (2*x2 - 1 + x1 ) / 4.;
    if (k[1] > 1 - k[0])
    {
        return 0;
    }
    else return (M_PI * M_PI * fp->mq * 4 * sqrt(3) * sqrt(-fp->N)*x1 / (D-l2)/(D-l2) / ((sqrt(2.))* 4 * M_PI * M_PI));
    //4*sqrt(3)*sqrt(-fp->N)/sqrt(2)
    //-4 * sqrt(3.) * N2 * res2 / (sqrt(2.))
}
double gwrdipole(double* x, size_t dim, void* p)
{
    (void)(dim);
    struct my_f_params* fp = (struct my_f_params*)p;
    double* k = new double[3];
    k[0] = x[0] / (1 - x[0]);
    k[1] = x[1] / (1 - x[1]);
    k[2] = x[2];
    return real(4 * sqrt(3.) * sqrt(-fp->N) * (k[1] * k[1] * 2 * 2 * M_PI * fp->mq / (sqrt(2.) * 4 * M_PI * M_PI) / ((1 - x[0]) * (1 - x[0]) * (1 - x[1]) * (1 - x[1])* f1(k[0], k[1], fp->Q2, fp->m, fp->mq, fp->b) * f1(k[0], k[1], fp->Q2, fp->m, fp->mq, fp->b) * f2(k[0], k[1], k[2], fp->Q2, fp->m, fp->mq, fp->b) * f4(k[0], k[1], k[2], fp->Q2, fp->m, fp->mq, fp->b))));

}
double grianorm(double* k, size_t dim, void* p)
{
    (void)(dim);

    struct my_f_params* fp = (struct my_f_params*)p;
    double x1 = k[0], x2 = k[1], x3 = k[2], x4 = k[3];
    double mpi = fp->m;
    double mq = fp->mq;
    double b22 = fp->b2 * fp->b2;
    double b12 = fp->b * fp->b;
    double q2 = -fp->Q2;
    double eta = -q2 / (4 * fp->m * fp->m);
    double pq = fp->m * fp->m * 2 * eta;
    double l0 = -0.5 * (fp->m * sqrt(1 + eta) * (k[0] + k[1] - k[2]));
    double p0 = fp->m * sqrt(1 + eta);
    double pl = -0.5 * (fp->m * fp->m * (k[0] + k[1] - k[2]) + pq * (2 * k[1] + 1 - k[0] - k[1] - k[2] - k[3]));
    double ql = -0.5 * (pq * (k[0] + k[1] - k[2]) + q2 * (2 * k[1] + 1 - k[0] - k[1] - k[2] - k[3]));
    double l2 = 0.25 * (fp->m * fp->m * (k[0] + k[1] - k[2]) * (k[0] + k[1] - k[2]) + 2 * pq * (k[0] + k[1] - k[2]) * (2 * k[1] + 1 - k[0] - k[1] - k[2] - k[3]) + q2 * (2 * k[1] + 1 - k[0] - k[1] - k[2] - k[3]) * (2 * k[1] + 1 - k[0] - k[1] - k[2] - k[3]));
    double D = -(fp->mq * fp->mq - fp->m * fp->m / 4.) * (k[0] + k[1] + k[2]) + pq * k[1] + q2 * (k[1] + (1 - k[0] - k[1] - k[2] - k[3]) / 4.) - fp->b * fp->b * k[3] - fp->b2 * fp->b2*(1 - k[0] - k[1] - k[2] - k[3]);
    double Sp1 = +4 * pl * l0 + p0 * (D - l2)
        + l0 * (+4 * pq + 3 * fp->m * fp->m + 4 * fp->mq * fp->mq)
        - 4 * l0 * (l2 + 3. * (D - l2) / 2)
        + p0 * (-4 * ql - 2 * pl)
        - 6 * p0 * (D)
        +p0 * (+1. / 2 * fp->m * fp->m + 6 * fp->mq * fp->mq);
    if (k[1] > 1 - k[0])
    {
        return 0;
    }
    if (k[2] > 1 - k[0] - k[1])
    {
        return 0;
    }
    if (k[3] > 1 - k[0] - k[1] - k[2])
    {
        return 0;
    }

    else
    {
       return (2 * M_PI * M_PI * Sp1  / (D - l2) / (D - l2) / (D - l2));//monopole
        //return (2 * M_PI * M_PI * (-9.0 * mpi * (-1.0 + x1 + x2 + x3 + x4) * ((x3 * x3 * x3 / 12.0 + (1.0 / 6.0 - x1 / 4.0 - x2 / 4.0) *
        //    x3 * x3 + (x2 * x2 / 4.0 + (x1 / 2.0 + 1.0 / 6.0) * x2 + x1 * x1 / 4.0 + x1 / 6.0 + 1.0 / 12.0) * x3 - (x2 * x2 + (2.0 *
        //        x1 + 5.0) * x2 + x1 * x1 + 5.0 * x1 - 4.0) * (x2 - 1.0 + x1) / 12.0) * mpi * mpi - (x1 + x4 / 2.0) * (-x2 - 1.0 + x1 +
        //            x3 + x4) * (x1 + x2 - x3 - 7.0) * q2 / 6.0 + (-mq * mq + b22) * x3 * x3 + ((x4 + 2.0 / 3.0) * b22 - 3.0 * mq * mq - b12
        //                * x4) * x3 - (x1 + x2 - 5.0 / 3.0) * (x1 + x2 + x4 - 1.0) * b22 + mq * mq * x2 * x2 + ((2.0 * x1 - 1.0 / 3.0) * mq * mq +
        //                    b12 * x4) * x2 + (-4.0 + x1 * x1 - x1 / 3.0) * mq * mq + x4 * b12 * (x1 - 5.0 / 3.0)) * x4 * sqrt((4.0 * mpi * mpi -
        //                        q2) / (mpi * mpi)) / pow((x3 * x3 / 4.0 + (-x1 / 2.0 - x2 / 2.0 - 1.0 / 4.0) * x3 + (x1 + x2) * (x2 - 1.0 + x1) /
        //                            4.0) * mpi * mpi + (x1 + x4 / 2.0) * (-x2 - 1.0 + x1 + x3 + x4) * q2 / 2.0 + (mq * mq - b22) * x3 + (-x1 - x2 - x4 +
        //                                1.0) * b22 + mq * mq * x1 + mq * mq * x2 + b12 * x4, 5.0)));
    }
}
double grianorm_pk(double* k, size_t dim, void* p)
{
    (void)(dim);

    struct my_f_params_1* fp = (struct my_f_params_1*)p;
    double x1 = k[0], x2 = k[1], x3 = k[2], x4 = k[3];
    double alpha = fp->alpha;
    double mpi = fp->m;
    double mq = fp->mq;
    double b12 = fp->b * fp->b;
    double q2 = -fp->Q2;
    double eta = -q2 / (4 * fp->m * fp->m);
    double pq = fp->m * fp->m * 2 * eta;
    double l0 = (-x4 * alpha / 2.0 - alpha * (1 - x1 - x2 - x3 - x4) / 2.0 - x1 / 2.0 - x2 / 2.0 + x3 / 2.0) * fp->m * sqrt(1.0 + eta);
    double p0 = fp->m * sqrt(1 + eta);
    double pl = fp->m * fp->m * (-x4 * alpha / 2.0 - alpha * (1.0 - x1 - x2 - x3 - x4) / 2.0 - x1 / 2.0 - x2 / 2.0 + x3 / 2.0)
        + 2.0 * fp->m * fp->m * eta * (-x2 / 2.0 - 1.0 / 2.0 + x1 / 2.0 + x3 / 2.0 + x4 / 2.0);

    double ql = 2.0 * fp->m * fp->m * eta * (-x4 * alpha / 2.0 - alpha * (1.0 - x1 - x2 - x3 - x4) / 2.0 - x1 / 2.0 - x2 / 2.0
        + x3 / 2.0) + q2 * (-x2 / 2.0 - 1.0 / 2.0 + x1 / 2.0 + x3 / 2.0 + x4 / 2.0);

    double l2 = fp->m * fp->m * pow(-alpha * x4 / 2.0 - (1.0 - x1 - x2 - x3 - x4) * alpha / 2.0 - x1 / 2.0 - x2 / 2.0 + x3 /
        2.0, 2.0) + 2.0 * pq * (-x2 / 2.0 - 1.0 / 2.0 + x1 / 2.0 + x3 / 2.0 + x4 / 2.0) * (-alpha * x4 / 2.0 - (1.0 - x1 -
            x2 - x3 - x4) * alpha / 2.0 - x1 / 2.0 - x2 / 2.0 + x3 / 2.0) + q2 * pow(-x2 / 2.0 - 1.0 / 2.0 + x1 / 2.0 + x3 / 2.0 +
                x4 / 2.0, 2.0);

    double D = (-1.0 + x1 + x2 + x3) * fp->b * fp->b + (-x1 - x2 - x3) * mq * mq + (x1 / 4.0 + x2 / 4.0 + x3 / 4.0) * fp->m * fp->m + x2 *
        pq + x2 * q2 + (1.0 - x1 - x2 - x3 - x4) * q2 / 4.0;
    double Sp1 = +4 * pl * l0 + p0 * (D - l2)
        + l0 * (+4 * pq + 3 * fp->m * fp->m + 4 * fp->mq * fp->mq)
        - 4 * l0 * (l2 + 3. * (D - l2) / 2)
        + p0 * (-4 * ql - 2 * pl)
        - 6 * p0 * (D)
        +p0 * (+1. / 2 * fp->m * fp->m + 6 * fp->mq * fp->mq);
    if (k[1] > 1 - k[0])
    {
        return 0;
    }
    if (k[2] > 1 - k[0] - k[1])
    {
        return 0;
    }
    if (k[3] > 1 - k[0] - k[1] - k[2])
    {
        return 0;
    }

    else
    {
        return (2 * M_PI * M_PI * Sp1 / (D - l2) / (D - l2) / (D - l2) );//monopole
         //return (2 * M_PI * M_PI * (-9.0 * mpi * (-1.0 + x1 + x2 + x3 + x4) * ((x3 * x3 * x3 / 12.0 + (1.0 / 6.0 - x1 / 4.0 - x2 / 4.0) *
         //    x3 * x3 + (x2 * x2 / 4.0 + (x1 / 2.0 + 1.0 / 6.0) * x2 + x1 * x1 / 4.0 + x1 / 6.0 + 1.0 / 12.0) * x3 - (x2 * x2 + (2.0 *
         //        x1 + 5.0) * x2 + x1 * x1 + 5.0 * x1 - 4.0) * (x2 - 1.0 + x1) / 12.0) * mpi * mpi - (x1 + x4 / 2.0) * (-x2 - 1.0 + x1 +
         //            x3 + x4) * (x1 + x2 - x3 - 7.0) * q2 / 6.0 + (-mq * mq + b22) * x3 * x3 + ((x4 + 2.0 / 3.0) * b22 - 3.0 * mq * mq - b12
         //                * x4) * x3 - (x1 + x2 - 5.0 / 3.0) * (x1 + x2 + x4 - 1.0) * b22 + mq * mq * x2 * x2 + ((2.0 * x1 - 1.0 / 3.0) * mq * mq +
         //                    b12 * x4) * x2 + (-4.0 + x1 * x1 - x1 / 3.0) * mq * mq + x4 * b12 * (x1 - 5.0 / 3.0)) * x4 * sqrt((4.0 * mpi * mpi -
         //                        q2) / (mpi * mpi)) / pow((x3 * x3 / 4.0 + (-x1 / 2.0 - x2 / 2.0 - 1.0 / 4.0) * x3 + (x1 + x2) * (x2 - 1.0 + x1) /
         //                            4.0) * mpi * mpi + (x1 + x4 / 2.0) * (-x2 - 1.0 + x1 + x3 + x4) * q2 / 2.0 + (mq * mq - b22) * x3 + (-x1 - x2 - x4 +
         //                                1.0) * b22 + mq * mq * x1 + mq * mq * x2 + b12 * x4, 5.0)));
    }
}
double fn1(double k4, double k, double Q2, double m, double mq, double b)
{
    double q2 = -Q2;
    double eta = -q2 / (4 * m * m);
    return (-k4 * k4 - k * k - b * b);
}
complex<double> fn2(double k4, double k, double costheta, double Q2, double m, double mq, double b)
{
    double q2 = -Q2;
    double eta = -q2 / (4 * m * m);

    return(m * m / 4 + i_ * m * sqrt(1 + eta) * k4 + m * sqrt(eta) * k * costheta - k4 * k4 - k * k - mq * mq);
}
complex<double> fn3(double k4, double k, double costheta, double Q2, double m, double mq, double b)
{
    double q2 = -Q2;
    double eta = -q2 / (4 * m * m);

    return(m * m / 4 - k4 * k4 - k * k + q2 + i_ * m * sqrt(1 + eta) * k4 + -3 * m * sqrt(eta) * k * costheta + m * m * 2 * eta - mq * mq);
}
complex<double> fn4(double k4, double k, double costheta, double Q2, double m, double mq, double b)
{
    double q2 = -Q2;
    double eta = -q2 / (4 * m * m);

    return(m * m / 4 - i_ * m * sqrt(1 + eta) * k4 - m * sqrt(eta) * k * costheta - k4 * k4 - k * k - mq * mq);
}
double fn5(double k4, double k, double costheta, double Q2, double m, double mq, double b)
{
    double q2 = -Q2;
    double eta = -q2 / (4 * m * m);

    return(-k4 * k4 - k * k - 2 * m * sqrt(eta) * k * costheta + q2 / 4 - b * b);
}
double fng1(double k4, double k, double Q2, double m, double mq, double b)
{
    double q2 = -Q2;
    double eta = -q2 / (4 * m * m);
    return (exp((-k4 * k4 - k * k)/(b*b) ));
}
double fng5(double k4, double k, double costheta, double Q2, double m, double mq, double b)
{
    double q2 = -Q2;
    double eta = -q2 / (4 * m * m);

    return(exp((-k4 * k4 - k * k - 2 * m * sqrt(eta) * k * costheta + q2 / 4)/(b*b) ));
}
double gwrrianorm(double* x, size_t dim, void* p)
{
    (void)(dim);
    struct my_f_params* fp = (struct my_f_params*)p;
    double* k_ = new double[3];
    double q2 = -fp->Q2;
    double eta = -q2 / (4 * fp->m * fp->m);
    k_[0] = x[0] / (1 - x[0]);
    k_[1] = x[1] / (1 - x[1]);
    k_[2] = x[2];
    double k4 = k_[0], k = k_[1], costheta = k_[2];
    complex<double> Sp = 4.0* sqrt(eta) * i_ * k4 * k *fp-> m * costheta + 2.0 * sqrt(1.0 + eta) * k4 * k4 * fp->m + 6.0 * eta * i_ * k4 *
        fp->m * fp->m + 4.0 * k4 * k4 * i_ * k4 + 4.0 * i_ * k4 * k * k + i_ * k4 * fp->m * fp->m + 4.0 * i_ * k4 * fp->mq * fp->mq + 6.0 * sqrt(1.0 + eta) * fp->m * fp->m * sqrt(
            eta) * k * costheta + 6.0 * sqrt(1.0 + eta) * fp->m * k * k + sqrt(1.0 + eta) * fp->m * fp->m * fp->m / 2.0 + 6.0 * sqrt(1.0
                + eta) * fp->m * fp->mq * fp->mq;
    //return real((k_[1] * k_[1] * 2 * 2 * M_PI*Sp / ((1 - x[0]) * (1 - x[0]) * (1 - x[1]) * (1 - x[1]) * fn1(k_[0], k_[1], fp->Q2, fp->m, fp->mq, fp->b)* fn1(k_[0], k_[1], fp->Q2, fp->m, fp->mq, fp->b) * fn2(k_[0], k_[1], k_[2], fp->Q2, fp->m, fp->mq, fp->b) * fn3(k_[0], k_[1], k_[2], fp->Q2, fp->m, fp->mq, fp->b) * fn4(k_[0], k_[1], k_[2], fp->Q2, fp->m, fp->mq, fp->b) )));//monopole
     return real((k_[1] * k_[1] * 2 * 2 * M_PI*Sp / ((1 - x[0]) * (1 - x[0]) * (1 - x[1]) * (1 - x[1]) * fn1(k_[0], k_[1], fp->Q2, fp->m, fp->mq, fp->b) * fn1(k_[0], k_[1], fp->Q2, fp->m, fp->mq, fp->b)* fn1(k_[0], k_[1], fp->Q2, fp->m, fp->mq, fp->b) * fn1(k_[0], k_[1], fp->Q2, fp->m, fp->mq, fp->b)  * fn2(k_[0], k_[1], k_[2], fp->Q2, fp->m, fp->mq, fp->b) * fn3(k_[0], k_[1], k_[2], fp->Q2, fp->m, fp->mq, fp->b) * fn4(k_[0], k_[1], k_[2], fp->Q2, fp->m, fp->mq, fp->b) )));//dipole

}
double rpif(double* k, size_t dim, void* p)//rpifRIA
{
    (void)(dim);
    struct my_f_params* fp = (struct my_f_params*)p;
    double x1 = k[0], x2 = k[1],x3=k[2],x4=k[3];
    double MapleGenVar1, MapleGenVar2, MapleGenVar3, MapleGenVar4, t0;
    double mpi = fp->m;
    double mq = fp->mq;
    double b = fp->b;
    double b2 = fp->b2;
    MapleGenVar3 = -(x2 / 4.0 + 1.0 / 4.0 - x1 / 4.0 - x3 / 4.0 - x4 / 4.0) * mpi * sqrt(4.0) * (x1 +
        x2 - x3) / 4.0 - mpi * pow(x1 + x2 - x3, 2.0) * sqrt(4.0) / 64.0 - 1 / mpi * sqrt(4.0) * (-(mq * mq - mpi *
            mpi / 4.0) * (x1 + x2 + x3) - b * b * x4 - b2 * b2 * (1.0 - x1 - x2 - x3 - x4) - mpi * mpi * pow(x1 + x2 - x3, 2.0) /
            4.0) / 64.0 + mpi * sqrt(4.0) * (x2 / 4.0 + 1.0 / 4.0 - x1 / 4.0 - x3 / 4.0 - x4 / 4.0 + (x1 + x2 - x3) * (x2 + 1.0
                - x1 - x3 - x4) / 4.0 - pow(x2 + 1.0 - x1 - x3 - x4, 2.0) / 4.0) / 8.0 + 1 / mpi * sqrt(4.0) * (x1 + x2 - x3) * (
                    3.0 * mpi * mpi + 4.0 * mq * mq) / 128.0 + 7.0 / 64.0 * mpi * sqrt(4.0) * (x1 + x2 - x3);
    MapleGenVar2 = MapleGenVar3 - 1 / mpi * sqrt(4.0) * (x1 + x2 - x3) * (-mpi * mpi * pow(x1 +
        x2 - x3, 2.0) / 8.0 - 3.0 / 2.0 * (mq * mq - mpi * mpi / 4.0) * (x1 + x2 + x3) - 3.0 / 2.0 * b * b * x4 - 3.0 / 2.0 * b2
        * b2 * (1.0 - x1 - x2 - x3 - x4)) / 32.0 + mpi * sqrt(4.0) * (x1 + x2 - x3) * ((x1 + x2 - x3) * (x2 + 1.0 - x1 - x3 -
            x4) / 8.0 - pow(x2 + 1.0 - x1 - x3 - x4, 2.0) / 8.0 + 3.0 / 8.0 * x2 + 3.0 / 8.0 - 3.0 / 8.0 * x1 - 3.0 / 8.0 * x3
            - 3.0 / 8.0 * x4) / 4.0 + mpi * sqrt(4.0) * (-5.0 / 2.0 * x1 + x2 / 2.0 - x3 / 2.0 + 3.0 / 2.0 - 3.0 / 2.0 * x4) /
        8.0 + 3.0 / 32.0 / mpi * sqrt(4.0) * (-(mq * mq - mpi * mpi / 4.0) * (x1 + x2 + x3) - b * b * x4 - b2 * b2 * (1.0 -
            x1 - x2 - x3 - x4)) - 3.0 / 4.0 * mpi * sqrt(4.0) * (x2 / 4.0 + 1.0 / 4.0 - x1 / 4.0 - x3 / 4.0 - x4 / 4.0) - 1 / mpi
        * sqrt(4.0) * (mpi * mpi / 2.0 + 6.0 * mq * mq) / 64.0;
    MapleGenVar3 = 1 / mpi * sqrt(4.0) / pow(-(mq * mq - mpi * mpi / 4.0) * (x1 + x2 + x3) - b * b * x4
        - b2 * b2 * (1.0 - x1 - x2 - x3 - x4) - mpi * mpi * pow(x1 + x2 - x3, 2.0) / 4.0, 3.0);
    MapleGenVar1 = MapleGenVar2 * MapleGenVar3;
    MapleGenVar3 = (mpi * mpi * mpi * pow(x1 + x2 - x3, 2.0) * sqrt(4.0) / 2.0 + mpi * sqrt(4.0)
        * (-(mq * mq - mpi * mpi / 4.0) * (x1 + x2 + x3) - b * b * x4 - b2 * b2 * (1.0 - x1 - x2 - x3 - x4) - mpi * mpi * pow(x1
            + x2 - x3, 2.0) / 4.0) / 2.0 - mpi * sqrt(4.0) * (x1 + x2 - x3) * (3.0 * mpi * mpi + 4.0 * mq * mq) / 4.0 + mpi *
        sqrt(4.0) * (x1 + x2 - x3) * (-mpi * mpi * pow(x1 + x2 - x3, 2.0) / 8.0 - 3.0 / 2.0 * (mq * mq - mpi * mpi / 4.0
            ) * (x1 + x2 + x3) - 3.0 / 2.0 * b * b * x4 - 3.0 / 2.0 * b2 * b2 * (1.0 - x1 - x2 - x3 - x4)) + mpi * mpi * mpi * sqrt(
                4.0) * (x1 + x2 - x3) / 2.0 - 3.0 * mpi * sqrt(4.0) * (-(mq * mq - mpi * mpi / 4.0) * (x1 + x2 + x3) - b * b * x4 -
                    b2 * b2 * (1.0 - x1 - x2 - x3 - x4)) + mpi * sqrt(4.0) * (mpi * mpi / 2.0 + 6.0 * mq * mq) / 2.0) / (mpi * mpi *
                        mpi) * sqrt(4.0) / pow(-(mq * mq - mpi * mpi / 4.0) * (x1 + x2 + x3) - b * b * x4 - b2 * b2 * (1.0 - x1 - x2 - x3 -
                            x4) - mpi * mpi * pow(x1 + x2 - x3, 2.0) / 4.0, 3.0) / 32.0;
    MapleGenVar4 = -3.0 / 4.0 * (mpi * mpi * mpi * pow(x1 + x2 - x3, 2.0) * sqrt(4.0) / 2.0 + mpi *
        sqrt(4.0) * (-(mq * mq - mpi * mpi / 4.0) * (x1 + x2 + x3) - b * b * x4 - b2 * b2 * (1.0 - x1 - x2 - x3 - x4) - mpi *
            mpi * pow(x1 + x2 - x3, 2.0) / 4.0) / 2.0 - mpi * sqrt(4.0) * (x1 + x2 - x3) * (3.0 * mpi * mpi + 4.0 * mq * mq)
        / 4.0 + mpi * sqrt(4.0) * (x1 + x2 - x3) * (-mpi * mpi * pow(x1 + x2 - x3, 2.0) / 8.0 - 3.0 / 2.0 * (mq * mq -
            mpi * mpi / 4.0) * (x1 + x2 + x3) - 3.0 / 2.0 * b * b * x4 - 3.0 / 2.0 * b2 * b2 * (1.0 - x1 - x2 - x3 - x4)) + mpi * mpi
        * mpi * sqrt(4.0) * (x1 + x2 - x3) / 2.0 - 3.0 * mpi * sqrt(4.0) * (-(mq * mq - mpi * mpi / 4.0) * (x1 + x2 + x3
            ) - b * b * x4 - b2 * b2 * (1.0 - x1 - x2 - x3 - x4)) + mpi * sqrt(4.0) * (mpi * mpi / 2.0 + 6.0 * mq * mq) / 2.0) /
        mpi * sqrt(4.0) / pow(-(mq * mq - mpi * mpi / 4.0) * (x1 + x2 + x3) - b * b * x4 - b2 * b2 * (1.0 - x1 - x2 - x3 - x4
            ) - mpi * mpi * pow(x1 + x2 - x3, 2.0) / 4.0, 4.0) * (x2 / 4.0 + 1.0 / 4.0 - x1 / 4.0 - x3 / 4.0 - x4 / 4.0 + (x1 +
                x2 - x3) * (x2 + 1.0 - x1 - x3 - x4) / 4.0 - pow(x2 + 1.0 - x1 - x3 - x4, 2.0) / 4.0);
    MapleGenVar2 = MapleGenVar3 + MapleGenVar4;
    t0 = MapleGenVar1 + MapleGenVar2;

    if ( x2> 1 - x1)
    {
        return 0;
    }
    if (x3 > 1 - x1 - x2)
    {
        return 0;
    }
    if (x4 > 1 - x1 - x2 - x3)
    {
        return 0;
    }

    else
    {
        return (2 * M_PI * M_PI*t0);
    }


}
double rpif_pk(double* k, size_t dim, void* p)//rpifRIA
{
    (void)(dim);
    struct my_f_params_1* fp = (struct my_f_params_1*)p;
    double x1 = k[0], x2 = k[1], x3 = k[2], x4 = k[3];
    double mpi = fp->m;
    double mq = fp->mq;
    double b = fp->b;
    double alpha = fp->alpha;
    double MapleGenVar1, MapleGenVar2, MapleGenVar3, MapleGenVar4, MapleGenVar5, MapleGenVar6, MapleGenVar7, MapleGenVar8, MapleGenVar9,t0;
    MapleGenVar4 = (x2 / 4.0 + 1.0 / 4.0 - x1 / 4.0 - x3 / 4.0 - x4 / 4.0) * (-x4 * alpha / 2.0 - alpha
        * (1.0 - x1 - x2 - x3 - x4) / 2.0 - x1 / 2.0 - x2 / 2.0 + x3 / 2.0) * mpi * sqrt(4.0) / 2.0 - mpi * pow(-x4 *
            alpha / 2.0 - alpha * (1.0 - x1 - x2 - x3 - x4) / 2.0 - x1 / 2.0 - x2 / 2.0 + x3 / 2.0, 2.0) * sqrt(4.0) / 16.0 -
        1 / mpi * sqrt(4.0) * ((-1.0 + x1 + x2 + x3) * b * b + (-x1 - x2 - x3) * mq * mq + (x1 / 4.0 + x2 / 4.0 + x3 / 4.0) *
            mpi * mpi - mpi * mpi * pow(-x4 * alpha / 2.0 - alpha * (1.0 - x1 - x2 - x3 - x4) / 2.0 - x1 / 2.0 - x2 / 2.0 + x3 /
                2.0, 2.0)) / 64.0;
    MapleGenVar3 = MapleGenVar4 + mpi * sqrt(4.0) * (x2 / 4.0 + 1.0 / 4.0 - x1 / 4.0 - x3 / 4.0 -
        x4 / 4.0 + (-x2 / 2.0 - 1.0 / 2.0 + x1 / 2.0 + x3 / 2.0 + x4 / 2.0) * (-x4 * alpha / 2.0 - alpha * (1.0 - x1 - x2 -
            x3 - x4) / 2.0 - x1 / 2.0 - x2 / 2.0 + x3 / 2.0) - pow(-x2 / 2.0 - 1.0 / 2.0 + x1 / 2.0 + x3 / 2.0 + x4 / 2.0, 2.0))
        / 8.0 - (-x4 * alpha / 2.0 - alpha * (1.0 - x1 - x2 - x3 - x4) / 2.0 - x1 / 2.0 - x2 / 2.0 + x3 / 2.0) / mpi * sqrt(
            4.0) * (3.0 * mpi * mpi + 4.0 * mq * mq) / 64.0 - 7.0 / 32.0 * (-x4 * alpha / 2.0 - alpha * (1.0 - x1 - x2 - x3 -
                x4) / 2.0 - x1 / 2.0 - x2 / 2.0 + x3 / 2.0) * mpi * sqrt(4.0);
    MapleGenVar4 = MapleGenVar3 + (-x4 * alpha / 2.0 - alpha * (1.0 - x1 - x2 - x3 - x4) / 2.0 - x1
        / 2.0 - x2 / 2.0 + x3 / 2.0) / mpi * sqrt(4.0) * (-mpi * mpi * pow(-x4 * alpha / 2.0 - alpha * (1.0 - x1 - x2 -
            x3 - x4) / 2.0 - x1 / 2.0 - x2 / 2.0 + x3 / 2.0, 2.0) / 2.0 + 3.0 / 2.0 * (-1.0 + x1 + x2 + x3) * b * b + 3.0 / 2.0 * (-
                x1 - x2 - x3) * mq * mq + 3.0 / 2.0 * (x1 / 4.0 + x2 / 4.0 + x3 / 4.0) * mpi * mpi) / 16.0 - (-x4 * alpha / 2.0 -
                    alpha * (1.0 - x1 - x2 - x3 - x4) / 2.0 - x1 / 2.0 - x2 / 2.0 + x3 / 2.0) * mpi * sqrt(4.0) * ((-x2 / 2.0 - 1.0 /
                        2.0 + x1 / 2.0 + x3 / 2.0 + x4 / 2.0) * (-x4 * alpha / 2.0 - alpha * (1.0 - x1 - x2 - x3 - x4) / 2.0 - x1 / 2.0 - x2 /
                            2.0 + x3 / 2.0) / 2.0 - pow(-x2 / 2.0 - 1.0 / 2.0 + x1 / 2.0 + x3 / 2.0 + x4 / 2.0, 2.0) / 2.0 + 3.0 / 8.0 * x2 +
                        3.0 / 8.0 - 3.0 / 8.0 * x1 - 3.0 / 8.0 * x3 - 3.0 / 8.0 * x4) / 2.0;
    MapleGenVar2 = MapleGenVar4 + mpi * sqrt(4.0) * (-x4 * alpha - alpha * (1.0 - x1 - x2 - x3 -
        x4) - 5.0 / 2.0 * x1 + x2 / 2.0 - x3 / 2.0 + 3.0 / 2.0 - 3.0 / 2.0 * x4) / 8.0 + 3.0 / 32.0 / mpi * sqrt(4.0) * ((
            -1.0 + x1 + x2 + x3) * b * b + (-x1 - x2 - x3) * mq * mq + (x1 / 4.0 + x2 / 4.0 + x3 / 4.0) * mpi * mpi) - 3.0 / 4.0 *
        mpi * sqrt(4.0) * (x2 / 4.0 + 1.0 / 4.0 - x1 / 4.0 - x3 / 4.0 - x4 / 4.0) - 1 / mpi * sqrt(4.0) * (mpi * mpi /
            2.0 + 6.0 * mq * mq) / 64.0;
    MapleGenVar3 = 1 / mpi * sqrt(4.0) / pow((-1.0 + x1 + x2 + x3) * b * b + (-x1 - x2 - x3) * mq * mq +
        (x1 / 4.0 + x2 / 4.0 + x3 / 4.0) * mpi * mpi - mpi * mpi * pow(-x4 * alpha / 2.0 - alpha * (1.0 - x1 - x2 - x3 - x4
            ) / 2.0 - x1 / 2.0 - x2 / 2.0 + x3 / 2.0, 2.0), 3.0);
    MapleGenVar1 = MapleGenVar2 * MapleGenVar3;
    MapleGenVar5 = mpi * mpi * mpi * pow(-x4 * alpha / 2.0 - alpha * (1.0 - x1 - x2 - x3 - x4) / 2.0 -
        x1 / 2.0 - x2 / 2.0 + x3 / 2.0, 2.0) * sqrt(4.0) / 16.0 + mpi * sqrt(4.0) * ((-1.0 + x1 + x2 + x3) * b * b + (-
            x1 - x2 - x3) * mq * mq + (x1 / 4.0 + x2 / 4.0 + x3 / 4.0) * mpi * mpi - mpi * mpi * pow(-x4 * alpha / 2.0 - alpha *
                (1.0 - x1 - x2 - x3 - x4) / 2.0 - x1 / 2.0 - x2 / 2.0 + x3 / 2.0, 2.0)) / 64.0 + (-x4 * alpha / 2.0 - alpha * (1.0
                    - x1 - x2 - x3 - x4) / 2.0 - x1 / 2.0 - x2 / 2.0 + x3 / 2.0) * mpi * sqrt(4.0) * (3.0 * mpi * mpi + 4.0 * mq * mq) /
        64.0;
    MapleGenVar4 = MapleGenVar5 - (-x4 * alpha / 2.0 - alpha * (1.0 - x1 - x2 - x3 - x4) / 2.0 - x1
        / 2.0 - x2 / 2.0 + x3 / 2.0) * mpi * sqrt(4.0) * (-mpi * mpi * pow(-x4 * alpha / 2.0 - alpha * (1.0 - x1 - x2 -
            x3 - x4) / 2.0 - x1 / 2.0 - x2 / 2.0 + x3 / 2.0, 2.0) / 2.0 + 3.0 / 2.0 * (-1.0 + x1 + x2 + x3) * b * b + 3.0 / 2.0 * (-
                x1 - x2 - x3) * mq * mq + 3.0 / 2.0 * (x1 / 4.0 + x2 / 4.0 + x3 / 4.0) * mpi * mpi) / 16.0 - mpi * mpi * mpi * sqrt(
                    4.0) * (-x4 * alpha / 2.0 - alpha * (1.0 - x1 - x2 - x3 - x4) / 2.0 - x1 / 2.0 - x2 / 2.0 + x3 / 2.0) / 32.0 - 3.0 /
        32.0 * mpi * sqrt(4.0) * ((-1.0 + x1 + x2 + x3) * b * b + (-x1 - x2 - x3) * mq * mq + (x1 / 4.0 + x2 / 4.0 + x3 / 4.0
            ) * mpi * mpi) + mpi * sqrt(4.0) * (mpi * mpi / 2.0 + 6.0 * mq * mq) / 64.0;
    MapleGenVar5 = 1 / (mpi * mpi * mpi) * sqrt(4.0) / pow((-1.0 + x1 + x2 + x3) * b * b + (-x1 - x2 -
        x3) * mq * mq + (x1 / 4.0 + x2 / 4.0 + x3 / 4.0) * mpi * mpi - mpi * mpi * pow(-x4 * alpha / 2.0 - alpha * (1.0 -
            x1 - x2 - x3 - x4) / 2.0 - x1 / 2.0 - x2 / 2.0 + x3 / 2.0, 2.0), 3.0);
    MapleGenVar3 = MapleGenVar4 * MapleGenVar5;
    MapleGenVar6 = -3.0 / 4.0;
    MapleGenVar9 = 2.0 * mpi * mpi * mpi * pow(-x4 * alpha / 2.0 - alpha * (1.0 - x1 - x2 - x3 - x4) /
        2.0 - x1 / 2.0 - x2 / 2.0 + x3 / 2.0, 2.0) * sqrt(4.0) + mpi * sqrt(4.0) * ((-1.0 + x1 + x2 + x3) * b * b + (-x1
            - x2 - x3) * mq * mq + (x1 / 4.0 + x2 / 4.0 + x3 / 4.0) * mpi * mpi - mpi * mpi * pow(-x4 * alpha / 2.0 - alpha * (
                1.0 - x1 - x2 - x3 - x4) / 2.0 - x1 / 2.0 - x2 / 2.0 + x3 / 2.0, 2.0)) / 2.0 + (-x4 * alpha / 2.0 - alpha * (1.0 -
                    x1 - x2 - x3 - x4) / 2.0 - x1 / 2.0 - x2 / 2.0 + x3 / 2.0) * mpi * sqrt(4.0) * (3.0 * mpi * mpi + 4.0 * mq * mq) /
        2.0;
    MapleGenVar8 = MapleGenVar9 - 2.0 * (-x4 * alpha / 2.0 - alpha * (1.0 - x1 - x2 - x3 - x4) /
        2.0 - x1 / 2.0 - x2 / 2.0 + x3 / 2.0) * mpi * sqrt(4.0) * (-mpi * mpi * pow(-x4 * alpha / 2.0 - alpha * (1.0 -
            x1 - x2 - x3 - x4) / 2.0 - x1 / 2.0 - x2 / 2.0 + x3 / 2.0, 2.0) / 2.0 + 3.0 / 2.0 * (-1.0 + x1 + x2 + x3) * b * b + 3.0 /
            2.0 * (-x1 - x2 - x3) * mq * mq + 3.0 / 2.0 * (x1 / 4.0 + x2 / 4.0 + x3 / 4.0) * mpi * mpi) - mpi * mpi * mpi * sqrt(
                4.0) * (-x4 * alpha / 2.0 - alpha * (1.0 - x1 - x2 - x3 - x4) / 2.0 - x1 / 2.0 - x2 / 2.0 + x3 / 2.0) - 3.0 * mpi *
        sqrt(4.0) * ((-1.0 + x1 + x2 + x3) * b * b + (-x1 - x2 - x3) * mq * mq + (x1 / 4.0 + x2 / 4.0 + x3 / 4.0) * mpi * mpi
            ) + mpi * sqrt(4.0) * (mpi * mpi / 2.0 + 6.0 * mq * mq) / 2.0;
    MapleGenVar9 = 1 / mpi;
    MapleGenVar7 = MapleGenVar8 * MapleGenVar9;
    MapleGenVar5 = MapleGenVar6 * MapleGenVar7;
    MapleGenVar6 = sqrt(4.0) / pow((-1.0 + x1 + x2 + x3) * b * b + (-x1 - x2 - x3) * mq * mq + (x1 /
        4.0 + x2 / 4.0 + x3 / 4.0) * mpi * mpi - mpi * mpi * pow(-x4 * alpha / 2.0 - alpha * (1.0 - x1 - x2 - x3 - x4) /
            2.0 - x1 / 2.0 - x2 / 2.0 + x3 / 2.0, 2.0), 4.0) * (x2 / 4.0 + 1.0 / 4.0 - x1 / 4.0 - x3 / 4.0 - x4 / 4.0 + (-x2 /
                2.0 - 1.0 / 2.0 + x1 / 2.0 + x3 / 2.0 + x4 / 2.0) * (-x4 * alpha / 2.0 - alpha * (1.0 - x1 - x2 - x3 - x4) / 2.0 - x1
                    / 2.0 - x2 / 2.0 + x3 / 2.0) - pow(-x2 / 2.0 - 1.0 / 2.0 + x1 / 2.0 + x3 / 2.0 + x4 / 2.0, 2.0));
    MapleGenVar4 = MapleGenVar5 * MapleGenVar6;
    MapleGenVar2 = MapleGenVar3 + MapleGenVar4;
    t0 = MapleGenVar1 + MapleGenVar2;



    if (x2 > 1 - x1)
    {
        return 0;
    }
    if (x3 > 1 - x1 - x2)
    {
        return 0;
    }
    if (x4 > 1 - x1 - x2 - x3)
    {
        return 0;
    }

    else
    {
        return (2 * M_PI * M_PI * t0);
    }


}
double rpifINT1(double* k, size_t dim, void* p)//rpifINT1
{
    (void)(dim);
    struct my_f_params* fp = (struct my_f_params*)p;
    double x1 = k[0], x2 = k[1], x3 = k[2], x4 = k[3];
    double MapleGenVar1, MapleGenVar2, MapleGenVar3, MapleGenVar4, MapleGenVar5, MapleGenVar6, t0;
    double mpi = fp->m;
    double mq = fp->mq;
    double b = fp->b;
    double b2 = fp->b2;
    MapleGenVar3 = mq * mq * x3 / 2.0 + mq * mq * (-x1 / 4.0 - x2 / 4.0 - 3.0 / 4.0 * x3 + 1.0 / 2.0 - x4 /
        2.0) - mq * mq / 4.0 - 2.0 * mpi * mpi * (x1 / 2.0 + x2 / 2.0 + x3 / 2.0 - 1.0 + x4) * (-x3 * x3 / 8.0 - (x1 / 2.0 + x2
            / 2.0 + x3 / 2.0 - 1.0 + x4) * x3 / 4.0) - x3 * (-mpi * mpi * pow(x1 / 2.0 + x2 / 2.0 + x3 / 2.0 - 1.0 + x4, 2.0) /
                2.0 + 3.0 / 2.0 * (-1.0 + x1 + x2 + x3) * mq * mq + 3.0 / 2.0 * (-3.0 / 4.0 * x1 - 3.0 / 4.0 * x2 - 3.0 / 4.0 * x3 +
                    1.0 - x4) * mpi * mpi - 3.0 / 2.0 * x1 * b * b - 3.0 / 2.0 * x2 * b2 * b2 - 3.0 / 2.0 * x3 * b * b) / 2.0 - (-x1 / 4.0 - x2
                        / 4.0 - 3.0 / 4.0 * x3 + 1.0 / 2.0 - x4 / 2.0) * (-mpi * mpi * pow(x1 / 2.0 + x2 / 2.0 + x3 / 2.0 - 1.0 + x4, 2.0) /
                            2.0 + 3.0 / 2.0 * (-1.0 + x1 + x2 + x3) * mq * mq + 3.0 / 2.0 * (-3.0 / 4.0 * x1 - 3.0 / 4.0 * x2 - 3.0 / 4.0 * x3 +
                                1.0 - x4) * mpi * mpi - 3.0 / 2.0 * x1 * b * b - 3.0 / 2.0 * x2 * b2 * b2 - 3.0 / 2.0 * x3 * b * b) + 3.0 / 8.0 * (-1.0 +
                                    x1 + x2 + x3) * mq * mq + 3.0 / 8.0 * (-3.0 / 4.0 * x1 - 3.0 / 4.0 * x2 - 3.0 / 4.0 * x3 + 1.0 - x4) * mpi * mpi;
    MapleGenVar2 = MapleGenVar3 - 3.0 / 8.0 * x1 * b * b - 3.0 / 8.0 * x2 * b2 * b2 - 3.0 / 8.0 * x3 * b *
        b - mpi * mpi * (x1 / 2.0 + x2 / 2.0 + x3 / 2.0 - 1.0 + x4) * x3 - mpi * mpi * (-x3 * x3 / 4.0 - (x1 / 2.0 + x2 / 2.0 +
            x3 / 2.0 - 1.0 + x4) * x3 / 2.0) / 2.0 - (-x1 / 4.0 - x2 / 4.0 - 3.0 / 4.0 * x3 + 1.0 / 2.0 - x4 / 2.0) * mpi * mpi * (
                x1 / 2.0 + x2 / 2.0 + x3 / 2.0 - 1.0 + x4) - mpi * mpi * pow(x1 / 2.0 + x2 / 2.0 + x3 / 2.0 - 1.0 + x4, 2.0) / 8.0 -
        mpi * mpi * x3 / 4.0 + mpi * mpi * (x1 / 2.0 + x2 / 2.0 + x3 / 2.0 - 1.0 + x4) / 4.0;
    MapleGenVar3 = 1 / (mpi * mpi) / pow((-1.0 + x1 + x2 + x3) * mq * mq + (-3.0 / 4.0 * x1 - 3.0 / 4.0
        * x2 - 3.0 / 4.0 * x3 + 1.0 - x4) * mpi * mpi - x1 * b * b - x2 * b2 * b2 - x3 * b * b - mpi * mpi * pow(x1 / 2.0 + x2 / 2.0
            + x3 / 2.0 - 1.0 + x4, 2.0), 3.0);
    MapleGenVar1 = MapleGenVar2 * MapleGenVar3;
    MapleGenVar3 = (8.0 * mq * mq * (x1 / 2.0 + x2 / 2.0 + x3 / 2.0 - 1.0 + x4) * mpi * mpi + 4.0 * mq * mq
        * mpi * mpi - 8.0 * mpi * mpi * (x1 / 2.0 + x2 / 2.0 + x3 / 2.0 - 1.0 + x4) * (-mpi * mpi * pow(x1 / 2.0 + x2 / 2.0 +
            x3 / 2.0 - 1.0 + x4, 2.0) / 2.0 + 3.0 / 2.0 * (-1.0 + x1 + x2 + x3) * mq * mq + 3.0 / 2.0 * (-3.0 / 4.0 * x1 - 3.0 /
                4.0 * x2 - 3.0 / 4.0 * x3 + 1.0 - x4) * mpi * mpi - 3.0 / 2.0 * x1 * b * b - 3.0 / 2.0 * x2 * b2 * b2 - 3.0 / 2.0 * x3 * b *
            b) - 4.0 * mpi * mpi * ((-1.0 + x1 + x2 + x3) * mq * mq + (-3.0 / 4.0 * x1 - 3.0 / 4.0 * x2 - 3.0 / 4.0 * x3 + 1.0 - x4
                ) * mpi * mpi - x1 * b * b - x2 * b2 * b2 - x3 * b * b) - 8.0 * mpi * mpi * mpi * mpi * pow(x1 / 2.0 + x2 / 2.0 + x3 / 2.0
                    - 1.0 + x4, 2.0) - 2.0 * mpi * mpi * ((-1.0 + x1 + x2 + x3) * mq * mq + (-3.0 / 4.0 * x1 - 3.0 / 4.0 * x2 - 3.0 / 4.0
                        * x3 + 1.0 - x4) * mpi * mpi - x1 * b * b - x2 * b2 * b2 - x3 * b * b - mpi * mpi * pow(x1 / 2.0 + x2 / 2.0 + x3 / 2.0 - 1.0
                            + x4, 2.0)) - 4.0 * mpi * mpi * mpi * mpi * (x1 / 2.0 + x2 / 2.0 + x3 / 2.0 - 1.0 + x4)) / (mpi * mpi * mpi * mpi) /
        pow((-1.0 + x1 + x2 + x3) * mq * mq + (-3.0 / 4.0 * x1 - 3.0 / 4.0 * x2 - 3.0 / 4.0 * x3 + 1.0 - x4) * mpi * mpi - x1
            * b * b - x2 * b2 * b2 - x3 * b * b - mpi * mpi * pow(x1 / 2.0 + x2 / 2.0 + x3 / 2.0 - 1.0 + x4, 2.0), 3.0) / 16.0;
    MapleGenVar5 = -6.0 * mq * mq * (x1 / 2.0 + x2 / 2.0 + x3 / 2.0 - 1.0 + x4) * mpi * mpi - 3.0 * mq * mq
        * mpi * mpi + 6.0 * mpi * mpi * (x1 / 2.0 + x2 / 2.0 + x3 / 2.0 - 1.0 + x4) * (-mpi * mpi * pow(x1 / 2.0 + x2 / 2.0 +
            x3 / 2.0 - 1.0 + x4, 2.0) / 2.0 + 3.0 / 2.0 * (-1.0 + x1 + x2 + x3) * mq * mq + 3.0 / 2.0 * (-3.0 / 4.0 * x1 - 3.0 /
                4.0 * x2 - 3.0 / 4.0 * x3 + 1.0 - x4) * mpi * mpi - 3.0 / 2.0 * x1 * b * b - 3.0 / 2.0 * x2 * b2 * b2 - 3.0 / 2.0 * x3 * b *
            b) + 3.0 * mpi * mpi * ((-1.0 + x1 + x2 + x3) * mq * mq + (-3.0 / 4.0 * x1 - 3.0 / 4.0 * x2 - 3.0 / 4.0 * x3 + 1.0 - x4
                ) * mpi * mpi - x1 * b * b - x2 * b2 * b2 - x3 * b * b) + 6.0 * mpi * mpi * mpi * mpi * pow(x1 / 2.0 + x2 / 2.0 + x3 / 2.0
                    - 1.0 + x4, 2.0) + 3.0 / 2.0 * mpi * mpi * ((-1.0 + x1 + x2 + x3) * mq * mq + (-3.0 / 4.0 * x1 - 3.0 / 4.0 * x2 - 3.0
                        / 4.0 * x3 + 1.0 - x4) * mpi * mpi - x1 * b * b - x2 * b2 * b2 - x3 * b * b - mpi * mpi * pow(x1 / 2.0 + x2 / 2.0 + x3 / 2.0
                            - 1.0 + x4, 2.0)) + 3.0 * mpi * mpi * mpi * mpi * (x1 / 2.0 + x2 / 2.0 + x3 / 2.0 - 1.0 + x4);
    MapleGenVar6 = 1 / (mpi * mpi) / pow((-1.0 + x1 + x2 + x3) * mq * mq + (-3.0 / 4.0 * x1 - 3.0 / 4.0
        * x2 - 3.0 / 4.0 * x3 + 1.0 - x4) * mpi * mpi - x1 * b * b - x2 * b2 * b2 - x3 * b * b - mpi * mpi * pow(x1 / 2.0 + x2 / 2.0
            + x3 / 2.0 - 1.0 + x4, 2.0), 4.0) * (-x3 * x3 / 4.0 - (x1 / 2.0 + x2 / 2.0 + x3 / 2.0 - 1.0 + x4) * x3 / 2.0);
    MapleGenVar4 = MapleGenVar5 * MapleGenVar6;
    MapleGenVar2 = MapleGenVar3 + MapleGenVar4;
    t0 = MapleGenVar1 + MapleGenVar2;



    if (x2 > 1 - x1)
    {
        return 0;
    }
    if (x3 > 1 - x1 - x2)
    {
        return 0;
    }
    if (x4 > 1 - x1 - x2 - x3)
    {
        return 0;
    }

    else
    {
        return (-2 * M_PI * M_PI * t0);
    }


}
double rpifINT1_pk(double* k, size_t dim, void* p)//rpifINT1
{
    (void)(dim);
    struct my_f_params_1* fp = (struct my_f_params_1*)p;
    double x1 = k[0], x2 = k[1], x3 = k[2], x4 = k[3];
    double mpi = fp->m;
    double mq = fp->mq;
    double b1 = fp->b;
    double b2 = fp->b2;
    double alpha = fp->alpha;
    double  MapleGenVar1, MapleGenVar2, MapleGenVar3, MapleGenVar4, MapleGenVar5, MapleGenVar6, MapleGenVar7, MapleGenVar8, MapleGenVar9, t0;
    MapleGenVar4 = -3.0 / 8.0 * x2 * b2 * b2 + mq * mq * x3 / 2.0 + 3.0 / 8.0 * (-x1 - x3) * b1 * b1 + mq *
        mq * (alpha * x1 / 4.0 + x2 * alpha / 4.0 + alpha * x3 / 4.0 - x1 / 4.0 - x2 / 4.0 - 3.0 / 4.0 * x3 + 1.0 / 2.0 - x4 /
            2.0);
    MapleGenVar5 = MapleGenVar4 - 2.0 * mpi * mpi * (-alpha * x1 / 2.0 - x2 * alpha / 2.0 - alpha
        * x3 / 2.0 + x1 / 2.0 + x2 / 2.0 + x3 / 2.0 - 1.0 + x4) * (-x3 * (-alpha * x1 / 2.0 - x2 * alpha / 2.0 - alpha * x3 /
            2.0 + x1 / 2.0 + x2 / 2.0 + x3 / 2.0 - 1.0 + x4) / 4.0 - x3 * x3 / 8.0);
    MapleGenVar3 = MapleGenVar5 - x3 * (-mpi * mpi * pow(-alpha * x1 / 2.0 - x2 * alpha / 2.0 -
        alpha * x3 / 2.0 + x1 / 2.0 + x2 / 2.0 + x3 / 2.0 - 1.0 + x4, 2.0) / 2.0 + 3.0 / 2.0 * (-x1 - x3) * b1 * b1 + 3.0 /
        2.0 * (-1.0 + x1 + x2 + x3) * mq * mq + 3.0 / 2.0 * (-3.0 / 4.0 * x1 - 3.0 / 4.0 * x2 - 3.0 / 4.0 * x3 + 1.0 - x4) *
        mpi * mpi - 3.0 / 2.0 * x2 * b2 * b2) / 2.0 - (alpha * x1 / 4.0 + x2 * alpha / 4.0 + alpha * x3 / 4.0 - x1 / 4.0 - x2
            / 4.0 - 3.0 / 4.0 * x3 + 1.0 / 2.0 - x4 / 2.0) * (-mpi * mpi * pow(-alpha * x1 / 2.0 - x2 * alpha / 2.0 - alpha *
                x3 / 2.0 + x1 / 2.0 + x2 / 2.0 + x3 / 2.0 - 1.0 + x4, 2.0) / 2.0 + 3.0 / 2.0 * (-x1 - x3) * b1 * b1 + 3.0 / 2.0 * (
                    -1.0 + x1 + x2 + x3) * mq * mq + 3.0 / 2.0 * (-3.0 / 4.0 * x1 - 3.0 / 4.0 * x2 - 3.0 / 4.0 * x3 + 1.0 - x4) * mpi * mpi
                - 3.0 / 2.0 * x2 * b2 * b2) - mpi * mpi * (-alpha * x1 / 2.0 - x2 * alpha / 2.0 - alpha * x3 / 2.0 + x1 / 2.0 + x2 /
                    2.0 + x3 / 2.0 - 1.0 + x4) * x3;
    MapleGenVar2 = MapleGenVar3 - mpi * mpi * (-x3 * (-alpha * x1 / 2.0 - x2 * alpha / 2.0 -
        alpha * x3 / 2.0 + x1 / 2.0 + x2 / 2.0 + x3 / 2.0 - 1.0 + x4) / 2.0 - x3 * x3 / 4.0) / 2.0 - (alpha * x1 / 4.0 + x2 *
            alpha / 4.0 + alpha * x3 / 4.0 - x1 / 4.0 - x2 / 4.0 - 3.0 / 4.0 * x3 + 1.0 / 2.0 - x4 / 2.0) * mpi * mpi * (-alpha
                * x1 / 2.0 - x2 * alpha / 2.0 - alpha * x3 / 2.0 + x1 / 2.0 + x2 / 2.0 + x3 / 2.0 - 1.0 + x4) - x3 * mpi * mpi / 4.0 +
        mpi * mpi * (-alpha * x1 / 2.0 - x2 * alpha / 2.0 - alpha * x3 / 2.0 + x1 / 2.0 + x2 / 2.0 + x3 / 2.0 - 1.0 + x4) /
        4.0 - mpi * mpi * pow(-alpha * x1 / 2.0 - x2 * alpha / 2.0 - alpha * x3 / 2.0 + x1 / 2.0 + x2 / 2.0 + x3 / 2.0
            - 1.0 + x4, 2.0) / 8.0 + 3.0 / 8.0 * (-1.0 + x1 + x2 + x3) * mq * mq + 3.0 / 8.0 * (-3.0 / 4.0 * x1 - 3.0 / 4.0 * x2
                - 3.0 / 4.0 * x3 + 1.0 - x4) * mpi * mpi - mq * mq / 4.0;
    MapleGenVar3 = 1 / (mpi * mpi) / pow((-x1 - x3) * b1 * b1 + (-1.0 + x1 + x2 + x3) * mq * mq + (-3.0
        / 4.0 * x1 - 3.0 / 4.0 * x2 - 3.0 / 4.0 * x3 + 1.0 - x4) * mpi * mpi - x2 * b2 * b2 - mpi * mpi * pow(-alpha * x1 /
            2.0 - x2 * alpha / 2.0 - alpha * x3 / 2.0 + x1 / 2.0 + x2 / 2.0 + x3 / 2.0 - 1.0 + x4, 2.0), 3.0);
    MapleGenVar1 = MapleGenVar2 * MapleGenVar3;
    MapleGenVar5 = mq * mq * mpi * mpi * (-alpha * x1 / 2.0 - x2 * alpha / 2.0 - alpha * x3 / 2.0 + x1 /
        2.0 + x2 / 2.0 + x3 / 2.0 - 1.0 + x4) / 2.0 + mpi * mpi * mq * mq / 4.0 - mpi * mpi * (-alpha * x1 / 2.0 - x2 * alpha
            / 2.0 - alpha * x3 / 2.0 + x1 / 2.0 + x2 / 2.0 + x3 / 2.0 - 1.0 + x4) * (-mpi * mpi * pow(-alpha * x1 / 2.0 - x2 *
                alpha / 2.0 - alpha * x3 / 2.0 + x1 / 2.0 + x2 / 2.0 + x3 / 2.0 - 1.0 + x4, 2.0) / 2.0 + 3.0 / 2.0 * (-x1 - x3) * b1
                * b1 + 3.0 / 2.0 * (-1.0 + x1 + x2 + x3) * mq * mq + 3.0 / 2.0 * (-3.0 / 4.0 * x1 - 3.0 / 4.0 * x2 - 3.0 / 4.0 * x3 +
                    1.0 - x4) * mpi * mpi - 3.0 / 2.0 * x2 * b2 * b2) / 2.0;
    MapleGenVar4 = MapleGenVar5 - mpi * mpi * ((-x1 - x3) * b1 * b1 + (-1.0 + x1 + x2 + x3) * mq * mq
        + (-3.0 / 4.0 * x1 - 3.0 / 4.0 * x2 - 3.0 / 4.0 * x3 + 1.0 - x4) * mpi * mpi - x2 * b2 * b2) / 4.0 - mpi * mpi * mpi *
        mpi * pow(-alpha * x1 / 2.0 - x2 * alpha / 2.0 - alpha * x3 / 2.0 + x1 / 2.0 + x2 / 2.0 + x3 / 2.0 - 1.0 + x4, 2.0
        ) / 2.0 - mpi * mpi * ((-x1 - x3) * b1 * b1 + (-1.0 + x1 + x2 + x3) * mq * mq + (-3.0 / 4.0 * x1 - 3.0 / 4.0 * x2 - 3.0
            / 4.0 * x3 + 1.0 - x4) * mpi * mpi - x2 * b2 * b2 - mpi * mpi * pow(-alpha * x1 / 2.0 - x2 * alpha / 2.0 - alpha *
                x3 / 2.0 + x1 / 2.0 + x2 / 2.0 + x3 / 2.0 - 1.0 + x4, 2.0)) / 8.0 - mpi * mpi * mpi * mpi * (-alpha * x1 / 2.0 - x2 *
                    alpha / 2.0 - alpha * x3 / 2.0 + x1 / 2.0 + x2 / 2.0 + x3 / 2.0 - 1.0 + x4) / 4.0;
    MapleGenVar5 = 1 / (mpi * mpi * mpi * mpi) / pow((-x1 - x3) * b1 * b1 + (-1.0 + x1 + x2 + x3) * mq *
        mq + (-3.0 / 4.0 * x1 - 3.0 / 4.0 * x2 - 3.0 / 4.0 * x3 + 1.0 - x4) * mpi * mpi - x2 * b2 * b2 - mpi * mpi * pow(-
            alpha * x1 / 2.0 - x2 * alpha / 2.0 - alpha * x3 / 2.0 + x1 / 2.0 + x2 / 2.0 + x3 / 2.0 - 1.0 + x4, 2.0), 3.0);
    MapleGenVar3 = MapleGenVar4 * MapleGenVar5;
    MapleGenVar6 = -6.0 * mq * mq * mpi * mpi * (-alpha * x1 / 2.0 - x2 * alpha / 2.0 - alpha * x3 /
        2.0 + x1 / 2.0 + x2 / 2.0 + x3 / 2.0 - 1.0 + x4) - 3.0 * mpi * mpi * mq * mq + 6.0 * mpi * mpi * (-alpha * x1 / 2.0 -
            x2 * alpha / 2.0 - alpha * x3 / 2.0 + x1 / 2.0 + x2 / 2.0 + x3 / 2.0 - 1.0 + x4) * (-mpi * mpi * pow(-alpha * x1 /
                2.0 - x2 * alpha / 2.0 - alpha * x3 / 2.0 + x1 / 2.0 + x2 / 2.0 + x3 / 2.0 - 1.0 + x4, 2.0) / 2.0 + 3.0 / 2.0 * (-x1
                    - x3) * b1 * b1 + 3.0 / 2.0 * (-1.0 + x1 + x2 + x3) * mq * mq + 3.0 / 2.0 * (-3.0 / 4.0 * x1 - 3.0 / 4.0 * x2 - 3.0 /
                        4.0 * x3 + 1.0 - x4) * mpi * mpi - 3.0 / 2.0 * x2 * b2 * b2);
    MapleGenVar5 = MapleGenVar6 + 3.0 * mpi * mpi * ((-x1 - x3) * b1 * b1 + (-1.0 + x1 + x2 + x3) *
        mq * mq + (-3.0 / 4.0 * x1 - 3.0 / 4.0 * x2 - 3.0 / 4.0 * x3 + 1.0 - x4) * mpi * mpi - x2 * b2 * b2) + 6.0 * mpi * mpi *
        mpi * mpi * pow(-alpha * x1 / 2.0 - x2 * alpha / 2.0 - alpha * x3 / 2.0 + x1 / 2.0 + x2 / 2.0 + x3 / 2.0 - 1.0 + x4
            , 2.0) + 3.0 / 2.0 * mpi * mpi * ((-x1 - x3) * b1 * b1 + (-1.0 + x1 + x2 + x3) * mq * mq + (-3.0 / 4.0 * x1 - 3.0 /
                4.0 * x2 - 3.0 / 4.0 * x3 + 1.0 - x4) * mpi * mpi - x2 * b2 * b2 - mpi * mpi * pow(-alpha * x1 / 2.0 - x2 * alpha /
                    2.0 - alpha * x3 / 2.0 + x1 / 2.0 + x2 / 2.0 + x3 / 2.0 - 1.0 + x4, 2.0)) + 3.0 * mpi * mpi * mpi * mpi * (-alpha *
                        x1 / 2.0 - x2 * alpha / 2.0 - alpha * x3 / 2.0 + x1 / 2.0 + x2 / 2.0 + x3 / 2.0 - 1.0 + x4);
    MapleGenVar6 = 1 / (mpi * mpi) / pow((-x1 - x3) * b1 * b1 + (-1.0 + x1 + x2 + x3) * mq * mq + (-3.0
        / 4.0 * x1 - 3.0 / 4.0 * x2 - 3.0 / 4.0 * x3 + 1.0 - x4) * mpi * mpi - x2 * b2 * b2 - mpi * mpi * pow(-alpha * x1 /
            2.0 - x2 * alpha / 2.0 - alpha * x3 / 2.0 + x1 / 2.0 + x2 / 2.0 + x3 / 2.0 - 1.0 + x4, 2.0), 4.0) * (-x3 * (-
                alpha * x1 / 2.0 - x2 * alpha / 2.0 - alpha * x3 / 2.0 + x1 / 2.0 + x2 / 2.0 + x3 / 2.0 - 1.0 + x4) / 2.0 - x3 * x3 /
                4.0);
    MapleGenVar4 = MapleGenVar5 * MapleGenVar6;
    MapleGenVar2 = MapleGenVar3 + MapleGenVar4;
    t0 = MapleGenVar1 + MapleGenVar2;




    if (x2 > 1 - x1)
    {
        return 0;
    }
    if (x3 > 1 - x1 - x2)
    {
        return 0;
    }
    if (x4 > 1 - x1 - x2 - x3)
    {
        return 0;
    }

    else
    {
        return (-2 * M_PI * M_PI * t0);
    }


}
double rpifINT2(double* k, size_t dim, void* p)//rpifINT2
{
    (void)(dim);
    struct my_f_params* fp = (struct my_f_params*)p;
    double x1 = k[0], x2 = k[1], x3 = k[2], x4 = k[3];
    double MapleGenVar1, MapleGenVar2, MapleGenVar3, MapleGenVar4, MapleGenVar5, MapleGenVar6, t0;
    double mpi = fp->m;
    double mq = fp->mq;
    double b = fp->b;
    double b1 = fp->b2;
    MapleGenVar3 = 2.0 * mq * mq * (-x2 / 4.0 - x3 / 4.0 + 1.0 / 2.0 - x1 / 2.0 - x4 / 2.0) + mq * mq * (x2
        / 4.0 + x3 / 4.0 - 1.0 / 2.0 + 3.0 / 4.0 * x1 + x4 / 2.0) - mq * mq / 4.0 - 2.0 * mpi * mpi * (x1 / 2.0 + x2 / 2.0 + x3 /
            2.0 - 1.0 + x4) * (-pow(x2 / 2.0 + x3 / 2.0 - 1.0 + x1 + x4, 2.0) / 2.0 + pow(x1 / 2.0 + x2 / 2.0 + x3 / 2.0 - 1.0
                + x4, 2.0) / 2.0) - 2.0 * (-x2 / 4.0 - x3 / 4.0 + 1.0 / 2.0 - x1 / 2.0 - x4 / 2.0) * (-mpi * mpi * pow(x1 / 2.0 +
                    x2 / 2.0 + x3 / 2.0 + x4, 2.0) / 2.0 + 3.0 / 2.0 * (-x1 - x2) * b * b + 3.0 / 2.0 * (-1.0 + x1 + x2 + x3) * mq * mq +
                    3.0 / 2.0 * (-3.0 / 4.0 * x1 - 3.0 / 4.0 * x2 - 3.0 / 4.0 * x3 + 1.0 - x4) * mpi * mpi - 3.0 / 2.0 * x3 * b1 * b1) - (
                        x2 / 4.0 + x3 / 4.0 - 1.0 / 2.0 + 3.0 / 4.0 * x1 + x4 / 2.0) * (-mpi * mpi * pow(x1 / 2.0 + x2 / 2.0 + x3 / 2.0 + x4,
                            2.0) / 2.0 + 3.0 / 2.0 * (-x1 - x2) * b * b + 3.0 / 2.0 * (-1.0 + x1 + x2 + x3) * mq * mq + 3.0 / 2.0 * (-3.0 / 4.0 *
                                x1 - 3.0 / 4.0 * x2 - 3.0 / 4.0 * x3 + 1.0 - x4) * mpi * mpi - 3.0 / 2.0 * x3 * b1 * b1) + 3.0 / 8.0 * (-x1 - x2) * b * b
        + 3.0 / 8.0 * (-1.0 + x1 + x2 + x3) * mq * mq;
    MapleGenVar2 = MapleGenVar3 + 3.0 / 8.0 * (-3.0 / 4.0 * x1 - 3.0 / 4.0 * x2 - 3.0 / 4.0 * x3 +
        1.0 - x4) * mpi * mpi - 3.0 / 8.0 * x3 * b1 * b1 - 4.0 * mpi * mpi * (x1 / 2.0 + x2 / 2.0 + x3 / 2.0 - 1.0 + x4) * (-x2
            / 4.0 - x3 / 4.0 + 1.0 / 2.0 - x1 / 2.0 - x4 / 2.0) - mpi * mpi * (-pow(x2 / 2.0 + x3 / 2.0 - 1.0 + x1 + x4, 2.0) +
                pow(x1 / 2.0 + x2 / 2.0 + x3 / 2.0 - 1.0 + x4, 2.0)) / 2.0 - 3.0 * (x2 / 4.0 + x3 / 4.0 - 1.0 / 2.0 + 3.0 / 4.0 * x1
                    + x4 / 2.0) * mpi * mpi * (x1 / 2.0 + x2 / 2.0 + x3 / 2.0 - 1.0 + x4) - mpi * mpi * pow(x1 / 2.0 + x2 / 2.0 + x3 / 2.0
                        + x4, 2.0) / 8.0 - mpi * mpi * (-x2 / 4.0 - x3 / 4.0 + 1.0 / 2.0 - x1 / 2.0 - x4 / 2.0) + mpi * mpi * (x1 / 2.0 + x2 /
                            2.0 + x3 / 2.0 - 1.0 + x4) / 4.0 - mpi * mpi * (x2 / 4.0 + x3 / 4.0 - 1.0 / 2.0 + 3.0 / 4.0 * x1 + x4 / 2.0);
    MapleGenVar3 = 1 / (mpi * mpi) / pow((-x1 - x2) * b * b + (-1.0 + x1 + x2 + x3) * mq * mq + (-3.0 /
        4.0 * x1 - 3.0 / 4.0 * x2 - 3.0 / 4.0 * x3 + 1.0 - x4) * mpi * mpi - x3 * b1 * b1 - mpi * mpi * pow(x1 / 2.0 + x2 / 2.0
            + x3 / 2.0 + x4, 2.0), 3.0);
    MapleGenVar1 = MapleGenVar2 * MapleGenVar3;
    MapleGenVar3 = (8.0 * mq * mq * (x1 / 2.0 + x2 / 2.0 + x3 / 2.0 - 1.0 + x4) * mpi * mpi + 4.0 * mq * mq
        * mpi * mpi - 8.0 * mpi * mpi * (x1 / 2.0 + x2 / 2.0 + x3 / 2.0 - 1.0 + x4) * (-mpi * mpi * pow(x1 / 2.0 + x2 / 2.0 +
            x3 / 2.0 + x4, 2.0) / 2.0 + 3.0 / 2.0 * (-x1 - x2) * b * b + 3.0 / 2.0 * (-1.0 + x1 + x2 + x3) * mq * mq + 3.0 / 2.0 * (
                -3.0 / 4.0 * x1 - 3.0 / 4.0 * x2 - 3.0 / 4.0 * x3 + 1.0 - x4) * mpi * mpi - 3.0 / 2.0 * x3 * b1 * b1) - 4.0 * mpi * mpi
        * ((-x1 - x2) * b * b + (-1.0 + x1 + x2 + x3) * mq * mq + (-3.0 / 4.0 * x1 - 3.0 / 4.0 * x2 - 3.0 / 4.0 * x3 + 1.0 - x4)
            * mpi * mpi - x3 * b1 * b1) - 8.0 * mpi * mpi * mpi * mpi * pow(x1 / 2.0 + x2 / 2.0 + x3 / 2.0 - 1.0 + x4, 2.0) - 2.0
        * mpi * mpi * ((-x1 - x2) * b * b + (-1.0 + x1 + x2 + x3) * mq * mq + (-3.0 / 4.0 * x1 - 3.0 / 4.0 * x2 - 3.0 / 4.0 * x3
            + 1.0 - x4) * mpi * mpi - x3 * b1 * b1 - mpi * mpi * pow(x1 / 2.0 + x2 / 2.0 + x3 / 2.0 + x4, 2.0)) - 4.0 * mpi * mpi
        * mpi * mpi * (x1 / 2.0 + x2 / 2.0 + x3 / 2.0 - 1.0 + x4)) / (mpi * mpi * mpi * mpi) / pow((-x1 - x2) * b * b + (
            -1.0 + x1 + x2 + x3) * mq * mq + (-3.0 / 4.0 * x1 - 3.0 / 4.0 * x2 - 3.0 / 4.0 * x3 + 1.0 - x4) * mpi * mpi - x3 * b1 *
            b1 - mpi * mpi * pow(x1 / 2.0 + x2 / 2.0 + x3 / 2.0 + x4, 2.0), 3.0) / 16.0;
    MapleGenVar5 = -6.0 * mq * mq * (x1 / 2.0 + x2 / 2.0 + x3 / 2.0 - 1.0 + x4) * mpi * mpi - 3.0 * mq * mq
        * mpi * mpi + 6.0 * mpi * mpi * (x1 / 2.0 + x2 / 2.0 + x3 / 2.0 - 1.0 + x4) * (-mpi * mpi * pow(x1 / 2.0 + x2 / 2.0 +
            x3 / 2.0 + x4, 2.0) / 2.0 + 3.0 / 2.0 * (-x1 - x2) * b * b + 3.0 / 2.0 * (-1.0 + x1 + x2 + x3) * mq * mq + 3.0 / 2.0 * (
                -3.0 / 4.0 * x1 - 3.0 / 4.0 * x2 - 3.0 / 4.0 * x3 + 1.0 - x4) * mpi * mpi - 3.0 / 2.0 * x3 * b1 * b1) + 3.0 * mpi * mpi
        * ((-x1 - x2) * b * b + (-1.0 + x1 + x2 + x3) * mq * mq + (-3.0 / 4.0 * x1 - 3.0 / 4.0 * x2 - 3.0 / 4.0 * x3 + 1.0 - x4)
            * mpi * mpi - x3 * b1 * b1) + 6.0 * mpi * mpi * mpi * mpi * pow(x1 / 2.0 + x2 / 2.0 + x3 / 2.0 - 1.0 + x4, 2.0) + 3.0
        / 2.0 * mpi * mpi * ((-x1 - x2) * b * b + (-1.0 + x1 + x2 + x3) * mq * mq + (-3.0 / 4.0 * x1 - 3.0 / 4.0 * x2 - 3.0 /
            4.0 * x3 + 1.0 - x4) * mpi * mpi - x3 * b1 * b1 - mpi * mpi * pow(x1 / 2.0 + x2 / 2.0 + x3 / 2.0 + x4, 2.0)) + 3.0 *
        mpi * mpi * mpi * mpi * (x1 / 2.0 + x2 / 2.0 + x3 / 2.0 - 1.0 + x4);
    MapleGenVar6 = 1 / (mpi * mpi) / pow((-x1 - x2) * b * b + (-1.0 + x1 + x2 + x3) * mq * mq + (-3.0 /
        4.0 * x1 - 3.0 / 4.0 * x2 - 3.0 / 4.0 * x3 + 1.0 - x4) * mpi * mpi - x3 * b1 * b1 - mpi * mpi * pow(x1 / 2.0 + x2 / 2.0
            + x3 / 2.0 + x4, 2.0), 4.0) * (-pow(x2 / 2.0 + x3 / 2.0 - 1.0 + x1 + x4, 2.0) + pow(x1 / 2.0 + x2 / 2.0 + x3 /
                2.0 - 1.0 + x4, 2.0));
    MapleGenVar4 = MapleGenVar5 * MapleGenVar6;
    MapleGenVar2 = MapleGenVar3 + MapleGenVar4;
    t0 = MapleGenVar1 + MapleGenVar2;




    if (x2 > 1 - x1)
    {
        return 0;
    }
    if (x3 > 1 - x1 - x2)
    {
        return 0;
    }
    if (x4 > 1 - x1 - x2 - x3)
    {
        return 0;
    }

    else
    {
        return (-2 * M_PI * M_PI * t0);
    }


}
double rpiRIAdipole(double* k, size_t dim, void* p)//rpifRIAdipole
{
    (void)(dim);
    struct my_f_params* fp = (struct my_f_params*)p;
    double x1 = k[0], x2 = k[1], x3 = k[2], x4 = k[3];
    double MapleGenVar1, MapleGenVar2, MapleGenVar3, MapleGenVar4, t0;
    double mpi = fp->m;
    double mq = fp->mq;
    double b12 = fp->b* fp->b;
    double b22 = fp->b2* fp->b2;
    MapleGenVar1 = 24.0 * (-1.0 + x1 + x2 + x3 + x4) * ((-x1 * x1 * x1 / 16.0 + (-3.0 / 16.0 * x2 + 3.0
        / 16.0 * x3 - 7.0 / 16.0) * x1 * x1 + (-3.0 / 16.0 * x2 * x2 + (-7.0 / 8.0 + 3.0 / 8.0 * x3) * x2 - 3.0 / 16.0 * x3 *
            x3 + 3.0 / 8.0 * x3 + 13.0 / 16.0) * x1 - x2 * x2 * x2 / 16.0 + (3.0 / 16.0 * x3 - 7.0 / 16.0) * x2 * x2 + (-3.0 /
                16.0 * x3 * x3 + 3.0 / 8.0 * x3 + 13.0 / 16.0) * x2 + (x3 - 1.0) * (x3 * x3 + 2.0 * x3 + 5.0) / 16.0) * mpi * mpi + (
                    mq * mq - b22) * x1 * x1 + ((2.0 * mq * mq - 2.0 * b22) * x2 + (-x4 + 3.0) * b22 + b12 * x4 - 3.0 / 4.0 * mq * mq) * x1
        + (mq * mq - b22) * x2 * x2 + ((-x4 + 3.0) * b22 + b12 * x4 - 3.0 / 4.0 * mq * mq) * x2 + (-mq * mq + b22) * x3 * x3 + (
            (x4 + 1.0) * b22 - b12 * x4 - 13.0 / 4.0 * mq * mq) * x3 + (2.0 * x4 - 2.0) * b22 - 15.0 / 4.0 * mq * mq - 2.0 * b12 *
        x4);
    MapleGenVar2 = (-x2 - 1.0 + x1 + x3 + x4) * x4 * (x1 + x4 / 2.0) / pow((x1 * x1 / 4.0 + (x2 / 2.0 -
        x3 / 2.0 - 1.0 / 4.0) * x1 + x2 * x2 / 4.0 + (-x3 / 2.0 - 1.0 / 4.0) * x2 + x3 * x3 / 4.0 - x3 / 4.0) * mpi * mpi + (mq
            * mq - b22) * x1 + (mq * mq - b22) * x2 + (mq * mq - b22) * x3 + (-x4 + 1.0) * b22 + b12 * x4, 6.0);
    t0 = MapleGenVar1 * MapleGenVar2;


    if (x2 > 1 - x1)
    {
        return 0;
    }
    if (x3 > 1 - x1 - x2)
    {
        return 0;
    }
    if (x4 > 1 - x1 - x2 - x3)
    {
        return 0;
    }

    else
    {
        return (2 * M_PI * M_PI * t0);
    }


}
double rpifINT1dipole(double* k, size_t dim, void* p)//rpifINT1dipole
{
    (void)(dim);
    struct my_f_params* fp = (struct my_f_params*)p;
    double x1 = k[0], x2 = k[1], x3 = k[2], x4 = k[3];
    double MapleGenVar1, MapleGenVar2, MapleGenVar3, MapleGenVar4, MapleGenVar5, MapleGenVar6, t0;
    double mpi = fp->m;
    double mq = fp->mq;
    double b12 = fp->b* fp->b;
    double b22 = fp->b2* fp->b2;
    double b32 = b12;
    MapleGenVar1 = -36.0 * (x3 * x3 / 3.0 + (1.0 / 12.0 + x4 / 3.0 + x1 / 6.0 + x2 / 6.0) * x3) * x1 * x2
        * x3 * (x1 + x2 + x3 + 2.0 * x4 - 1.0) / pow((-x3 * x3 / 4.0 + (-x1 / 2.0 - x2 / 2.0 - x4 + 1.0 / 4.0) * x3 - x1 * x1 /
            4.0 + (-x2 / 2.0 - x4 + 1.0 / 4.0) * x1 - x2 * x2 / 4.0 + (-x4 + 1.0 / 4.0) * x2 - x4 * x4 + x4) * mpi * mpi + (mq * mq
                - b32) * x3 + (mq * mq - b12) * x1 + (mq * mq - b22) * x2 - mq * mq, 6.0);
    MapleGenVar2 = 216.0 * ((x3 * x3 / 6.0 + (x1 / 3.0 + x2 / 3.0 + 2.0 / 3.0 * x4 - 7.0 / 12.0) * x3 +
        x1 * x1 / 6.0 + (x2 / 3.0 + 2.0 / 3.0 * x4 - 7.0 / 12.0) * x1 + x2 * x2 / 6.0 + (2.0 / 3.0 * x4 - 7.0 / 12.0) * x2 +
        2.0 / 3.0 * x4 * x4 - 2.0 / 3.0 * x4) * mpi * mpi + (mq * mq - b32) * x3 + (mq * mq - b12) * x1 + (mq * mq - b22) * x2
        - 8.0 / 3.0 * mq * mq) * x1 * x2 * x3 * (x1 + x2 + x3 + 2.0 * x4 - 1.0) / pow((-x3 * x3 / 4.0 + (-x1 / 2.0 - x2 / 2.0 -
            x4 + 1.0 / 4.0) * x3 - x1 * x1 / 4.0 + (-x2 / 2.0 - x4 + 1.0 / 4.0) * x1 - x2 * x2 / 4.0 + (-x4 + 1.0 / 4.0) * x2 - x4 *
            x4 + x4) * mpi * mpi + (mq * mq - b32) * x3 + (mq * mq - b12) * x1 + (mq * mq - b22) * x2 - mq * mq, 7.0) * (-x3 * x3 /
                2.0 + (1.0 / 2.0 - x4 / 2.0 - x1 / 4.0 - x2 / 4.0) * x3);
    t0 = -MapleGenVar1 - MapleGenVar2;





    if (x2 > 1 - x1)
    {
        return 0;
    }
    if (x3 > 1 - x1 - x2)
    {
        return 0;
    }
    if (x4 > 1 - x1 - x2 - x3)
    {
        return 0;
    }

    else
    {
        return (-2 * M_PI * M_PI * t0);
    }


}

double rpigamma(double* k, size_t dim, void* p)
{
    (void)(dim);

    struct my_f_params* fp = (struct my_f_params*)p;
    double x1 = k[0], x2 = k[1], x3 = k[2];
    double mpi = fp->m;
    double mq = fp->mq;
    double b = fp->b;

    if (x2 > 1 - x1)
    {
        return 0;
    }
    if (x3 > 1 - x1 - x2)
    {
        return 0;
    }
    else
    {
        return(1 / (pow(-b * b * x1 - x2 * mq * mq + x2 * mpi * mpi / 4.0 - x3 * mq * mq + x3 * mpi * mpi / 4.0 - (1.0 -
            x1 - x2 - x3) * mq * mq - (1.0 - x1 - x2 - x3) * mpi * mpi / 4.0 - mpi * mpi * pow(-x2 / 2.0 + x3 / 2.0, 2.0) + mpi *
            mpi * pow(1.0 - x1 - x2 - x3, 2.0) / 4.0, 2.0)));
    }
}
double drpigamma(double* k, size_t dim, void* p)
{
    (void)(dim);

    struct my_f_params* fp = (struct my_f_params*)p;
    double x1 = k[0], x2 = k[1], x3 = k[2];
    double mpi = fp->m;
    double mq = fp->mq;
    double b = fp->b;

    if (x2 > 1 - x1)
    {
        return 0;
    }
    if (x3 > 1 - x1 - x2)
    {
        return 0;
    }
    else
    {
        return((-2.0 / pow(-b * b * x1 - x2 * mq * mq + x2 * mpi * mpi / 4.0 - x3 * mq * mq + x3 * mpi * mpi / 4.0 - (
            1.0 - x1 - x2 - x3) * mq * mq - (1.0 - x1 - x2 - x3) * mpi * mpi / 4.0 - mpi * mpi * pow(-x2 / 2.0 + x3 / 2.0, 2.0) +
            pow(1.0 - x1 - x2 - x3, 2.0) * mpi * mpi / 4.0, 3.0) * (1.0 / 2.0 - x1 / 2.0 - x2 / 2.0 - x3 / 2.0 - pow(1.0 - x1
                - x2 - x3, 2.0) / 2.0)));
    }
}
double rpigamma_pk(double* k, size_t dim, void* p)
{
    (void)(dim);

    struct my_f_params_1* fp = (struct my_f_params_1*)p;
    double x1 = k[0], x2 = k[1], x3 = k[2];
    double mpi = fp->m;
    double mq = fp->mq;
    double b = fp->b;
    double alpha = fp->alpha;

    if (x2 > 1 - x1)
    {
        return 0;
    }
    if (x3 > 1 - x1 - x2)
    {
        return 0;
    }
    else
    {
        return(1 / (pow(-b * b * x1 - x2 * mq * mq + x2 * mpi * mpi / 4.0 - x3 * mq * mq + x3 * mpi * mpi / 4.0 - (1.0 -
            x1 - x2 - x3) * mq * mq - (1.0 - x1 - x2 - x3) * mpi * mpi / 4.0 - mpi * mpi * pow(-alpha * x1 / 2.0 - x2 / 2.0 + x3 /
                2.0, 2.0) + mpi * mpi * pow(1.0 - x1 - x2 - x3, 2.0) / 4.0, 2.0)));
    }
}
double drpigamma_pk(double* k, size_t dim, void* p)
{
    (void)(dim);

    struct my_f_params_1* fp = (struct my_f_params_1*)p;
    double x1 = k[0], x2 = k[1], x3 = k[2];
    double mpi = fp->m;
    double mq = fp->mq;
    double b = fp->b;
    double alpha = fp->alpha;
    if (x2 > 1 - x1)
    {
        return 0;
    }
    if (x3 > 1 - x1 - x2)
    {
        return 0;
    }
    else
    {
        return(-2.0 / pow(-b * b * x1 - x2 * mq * mq + x2 * mpi * mpi / 4.0 - x3 * mq * mq + x3 * mpi * mpi / 4.0 - (
            1.0 - x1 - x2 - x3) * mq * mq - (1.0 - x1 - x2 - x3) * mpi * mpi / 4.0 - mpi * mpi * pow(-alpha * x1 / 2.0 - x2 / 2.0
                + x3 / 2.0, 2.0) + pow(1.0 - x1 - x2 - x3, 2.0) * mpi * mpi / 4.0, 3.0) * (1.0 / 2.0 - x1 / 2.0 - x2 / 2.0 - x3 /
                    2.0 - pow(1.0 - x1 - x2 - x3, 2.0) / 2.0));
    }
}
double rpigammadipole(double* k, size_t dim, void* p)
{
    (void)(dim);

    struct my_f_params* fp = (struct my_f_params*)p;
    double x1 = k[0], x2 = k[1], x3 = k[2], x4 = k[3];
    double mpi = fp->m;
    double mq = fp->mq;
    double b = fp->b;
    double b2 = fp->b2;

    if (x2 > 1 - x1)
    {
        return 0;
    }
    if (x3 > 1 - x1 - x2)
    {
        return 0;
    }
    if (x4 > 1 - x1 - x2-x3)
    {
        return 0;
    }
    else
    {
        return(1 / (pow(-b * b * x1 - b2 * b2 * x2 - x3 * mq * mq + x3 * mpi * mpi / 4.0 - x4 * mq * mq + x4 * mpi * mpi /
            4.0 - (1.0 - x1 - x2 - x3 - x4) * mq * mq - (1.0 - x1 - x2 - x3 - x4) * mpi * mpi / 4.0 - mpi * mpi * pow(-x3 / 2.0 +
                x4 / 2.0, 2.0) + mpi * mpi * pow(1.0 - x1 - x2 - x3 - x4, 2.0) / 4.0, 3.0)));
        
    }
}
double drpigammadipole(double* k, size_t dim, void* p)
{
    (void)(dim);


    struct my_f_params* fp = (struct my_f_params*)p;
    double x1 = k[0], x2 = k[1], x3 = k[2], x4 = k[3];
    double mpi = fp->m;
    double mq = fp->mq;
    double b = fp->b;
    double b2 = fp->b2;

    if (x2 > 1 - x1)
    {
        return 0;
    }
    if (x3 > 1 - x1 - x2)
    {
        return 0;
    }
    if (x4 > 1 - x1 - x2 - x3)
    {
        return 0;
    }
    else
    {
        return(-3.0 / pow(-b * b * x1 - b2 * b2 * x2 - x3 * mq * mq + x3 * mpi * mpi / 4.0 - x4 * mq * mq + x4 * mpi *
            mpi / 4.0 - (1.0 - x1 - x2 - x3 - x4) * mq * mq - (1.0 - x1 - x2 - x3 - x4) * mpi * mpi / 4.0 - mpi * mpi * pow(-x3 /
                2.0 + x4 / 2.0, 2.0) + pow(1.0 - x1 - x2 - x3 - x4, 2.0) * mpi * mpi / 4.0, 4.0) * (1.0 / 2.0 - x1 / 2.0 - x2 /
                    2.0 - x3 / 2.0 - x4 / 2.0 - pow(1.0 - x1 - x2 - x3 - x4, 2.0) / 2.0));
    }
}
int main()
{
    double res_fmonopole, err_fmonopole;
    double xl_f[2] = { 0,0 };
    double xu_f[2] = { 1,1 };
    double res_wrmonopole, err_wrmonopole;
    double xl_wr[3] = { 0,0,-1 };
    double xu_wr[3] = { 1,1,1 };
    double res_fdipole, err_fdipole;
    double res_wrdipole, err_wrdipole;
    double xl_norm[4] = { 0,0,0,0 };
    double xu_norm[4] = { 1,1,1,1 };
    double res_norm, err_norm;
    double res_wrnorm, err_wrnorm;
    double res_rfria, err_rfria;
    double res_rfint1, err_rfint1;
    double res_rfint2, err_rfint2;
    double res_rfriadipole, err_rfriadipole;
    double res_rfint1dipole, err_rfint1dipole;
    double res_rfint2dipole, err_rfint2dipole;
    double res_rwr1, err_rwr1;
    double res_rf2, err_rf2;
    double res_rwr2, err_rwr2;
    double res_rpg, err_rpg, res_drpg, err_drpg;
    double xl_rpg[3] = { 0,0,0 };
    double xu_rpg[3] = { 1,1,1 };
    double xl_rpgdipole[4] = { 0,0,0,0 };
    double xu_rpgdipole[4] = { 1,1,1,1 };
    double res_rpgdipole, err_rpgdipole, res_drpgdipole, err_drpgdipole;

    const gsl_rng_type* T;
    gsl_rng* r;

    gsl_rng_env_setup();

    T = gsl_rng_default;
    r = gsl_rng_alloc(T);
    double Q2 = 1e-10;
    double m = 0.14;
    double mq = 0.260;
    double b = 0.550;
    //double b2 = 1.001;
    double N21 = -0.00596821;
    double N22 = -0.0175172;
    double N23 = -0.00325021;
    //double N2d = -0.0158588;
    //double N2d = -0.0831405;
    //double N2d = -0.0362659;
    //-0.0320479
    //double N2d = -0.0440332;
    double N2d = -0.0510124;
    double alpha = 0;
    ofstream file("fpirpigammarpi2.txt");
    //for (double alpha = -0.4;alpha < -0.25;alpha += 0.01)
    {
        
       //for (double b = 0.99;b < 1.02;b += 0.001)
        {
            double b2 = b ;
            //file << "alpha:  " << alpha << endl;
             file<<"mq: "<<mq << " be: " << b << endl;
            //struct my_f_params params1 = { Q2,m,mq,b,b2,N21 };
             struct my_f_params_1 params1 = { Q2,m,mq,b,b2,N21,alpha };
            {

                gsl_monte_vegas_state* s_norm = gsl_monte_vegas_alloc(4);
                gsl_monte_function G_norm = { &grianorm_pk, 4,&params1 };
                gsl_monte_vegas_integrate(&G_norm, xl_norm, xu_norm, 4, 1000000, r, s_norm,
                    &res_norm, &err_norm);
                do
                {
                    gsl_monte_vegas_integrate(&G_norm, xl_norm, xu_norm, 4, 1000000, r, s_norm,
                        &res_norm, &err_norm);
                } while (fabs(gsl_monte_vegas_chisq(s_norm) - 1.0) > 0.5);
                file<<"N: " << 2 * m / res_norm <<" N_err: "<< 2*m*(err_norm/res_norm/res_norm) <<endl;
                //cout << 2 * m / res_norm << endl;
            }
 /*           {

                gsl_monte_vegas_state* s_wrnorm = gsl_monte_vegas_alloc(3);
                gsl_monte_function G_wrnorm = { &gwrrianorm, 3,&params1 };
                gsl_monte_vegas_integrate(&G_wrnorm, xl_wr, xu_wr, 3, 100000, r, s_wrnorm,
                    &res_wrnorm, &err_wrnorm);
                do
                {
                    gsl_monte_vegas_integrate(&G_wrnorm, xl_wr, xu_wr, 3, 100000, r, s_wrnorm,
                        &res_wrnorm, &err_wrnorm);
                } while (fabs(gsl_monte_vegas_chisq(s_wrnorm) - 1.0) > 0.5);
                cout << 2 * m / res_wrnorm << endl;

            }*/
            double N = 2 * m / res_norm;
            //struct my_f_params params = { Q2,m,mq,b,b2,N };
            struct my_f_params_1 params = { Q2,m,mq,b,b2,N,alpha };
            {

                gsl_monte_vegas_state* s_fmonopole = gsl_monte_vegas_alloc(2);
                gsl_monte_function G_fmonopole = { &gfmonopole , 2,&params };
                gsl_monte_vegas_integrate(&G_fmonopole, xl_f, xu_f, 2, 1000000, r, s_fmonopole,
                    &res_fmonopole, &err_fmonopole);
                do
                {
                    gsl_monte_vegas_integrate(&G_fmonopole, xl_f, xu_f, 2, 1000000, r, s_fmonopole,
                        &res_fmonopole, &err_fmonopole);
                } while (fabs(gsl_monte_vegas_chisq(s_fmonopole) - 1.0) > 0.5);
              

            }
            double fpi = sqrt(2) * res_fmonopole;
            file<<"fpi:" << fpi << " fpi_err:"<< sqrt(2)*err_fmonopole<<endl;
            //{

            //    gsl_monte_vegas_state* s_wrmonopole = gsl_monte_vegas_alloc(3);
            //    gsl_monte_function G_wrmonopole = { &gwrmonopole, 3,&params };
            //    gsl_monte_vegas_integrate(&G_wrmonopole, xl_wr, xu_wr, 3, 100000, r, s_wrmonopole,
            //        &res_wrmonopole, &err_wrmonopole);
            //    do
            //    {
            //        gsl_monte_vegas_integrate(&G_wrmonopole, xl_wr, xu_wr, 3, 100000, r, s_wrmonopole,
            //            &res_wrmonopole, &err_wrmonopole);
            //    } while (fabs(gsl_monte_vegas_chisq(s_wrmonopole) - 1.0) > 0.5);
            //    cout << sqrt(2) * res_wrmonopole << endl;

            //}
           /* {

                 gsl_monte_vegas_state* s_fdipole = gsl_monte_vegas_alloc(2);
                 gsl_monte_function G_fdipole = { &gfdipole , 2,&params };
                 gsl_monte_vegas_integrate(&G_fdipole, xl_f, xu_f, 2, 1000000, r, s_fdipole,
                     &res_fdipole, &err_fdipole);
                 do
                 {
                     gsl_monte_vegas_integrate(&G_fdipole, xl_f, xu_f, 2, 1000000, r, s_fdipole,
                         &res_fdipole, &err_fdipole);
                 } while (fabs(gsl_monte_vegas_chisq(s_fdipole) - 1.0) > 0.5);
                 

            }
            double fpidipole = sqrt(2) * res_fdipole;
            file << "fpidipole:" << sqrt(2) * res_fdipole << " fpidipole_err:" << sqrt(2) * err_fdipole << endl;*/
           //  {

           //      gsl_monte_vegas_state* s_wrdipole = gsl_monte_vegas_alloc(3);
           //      gsl_monte_function G_wrdipole = { &gwrdipole, 3,&params };
           //      gsl_monte_vegas_integrate(&G_wrdipole, xl_wr, xu_wr, 3, 100000, r, s_wrdipole,
           //          &res_wrdipole, &err_wrdipole);
           //      do
           //      {
           //          gsl_monte_vegas_integrate(&G_wrdipole, xl_wr, xu_wr, 3, 100000, r, s_wrdipole,
           //              &res_wrdipole, &err_wrdipole);
           //      } while (fabs(gsl_monte_vegas_chisq(s_wrdipole) - 1.0) > 0.5);
           //      

           //  }
           //  double fpidipole = sqrt(2) * res_wrdipole;
           //cout << fpidipole << " "<<sqrt(2)*err_wrdipole<<endl;
             
            {

            gsl_monte_vegas_state* s_rpg = gsl_monte_vegas_alloc(3);
            gsl_monte_function G_rpg = { &rpigamma_pk, 3,&params1 };
            gsl_monte_vegas_integrate(&G_rpg, xl_rpg, xu_rpg, 3, 1000000, r, s_rpg,
                &res_rpg, &err_rpg);
            do
            {
                gsl_monte_vegas_integrate(&G_rpg, xl_rpg, xu_rpg, 3, 1000000, r, s_rpg,
                    &res_rpg, &err_rpg);
            } while (fabs(gsl_monte_vegas_chisq(s_rpg) - 1.0) > 0.5);

            }
            {

                gsl_monte_vegas_state* s_drpg = gsl_monte_vegas_alloc(3);
                gsl_monte_function G_drpg = { &drpigamma_pk, 3,&params1 };
                gsl_monte_vegas_integrate(&G_drpg, xl_rpg, xu_rpg, 3, 1000000, r, s_drpg,
                    &res_drpg, &err_drpg);
                do
                {
                    gsl_monte_vegas_integrate(&G_drpg, xl_rpg, xu_rpg, 3, 1000000, r, s_drpg,
                        &res_drpg, &err_drpg);
                } while (fabs(gsl_monte_vegas_chisq(s_drpg) - 1.0) > 0.5);


            }
            double rpig = sqrt(6 * res_drpg / res_rpg) * hc;
           // double hi2 = 0.5 * ((fpi - fpiexp) * (fpi - fpiexp) / fpiexperr / fpiexperr + (rpig - rpigexp) * (rpig - rpigexp) / rpigexperr / rpigexperr);
            file << "rpig: " << rpig << " rpig_err: " << sqrt(6 * err_drpg * err_rpg / res_rpg / res_rpg) * hc << endl;
            //file << "xi2: " << hi2 << endl;
         /*  {

               gsl_monte_vegas_state* s_rpgdipole = gsl_monte_vegas_alloc(4);
               gsl_monte_function G_rpgdipole = { &rpigammadipole, 4,&params1 };
               gsl_monte_vegas_integrate(&G_rpgdipole, xl_rpgdipole, xu_rpgdipole, 4, 1000000, r, s_rpgdipole,
                   &res_rpgdipole, &err_rpgdipole);
               do
               {
                   gsl_monte_vegas_integrate(&G_rpgdipole, xl_rpgdipole, xu_rpgdipole, 4, 1000000, r, s_rpgdipole,
                       &res_rpgdipole, &err_rpgdipole);
               } while (fabs(gsl_monte_vegas_chisq(s_rpgdipole) - 1.0) > 0.5);

           }
           {

               gsl_monte_vegas_state* s_drpgdipole = gsl_monte_vegas_alloc(4);
               gsl_monte_function G_drpgdipole = { &drpigammadipole, 4,&params1 };
               gsl_monte_vegas_integrate(&G_drpgdipole, xl_rpgdipole, xu_rpgdipole, 4, 1000000, r, s_drpgdipole,
                   &res_drpgdipole, &err_drpgdipole);
               do
               {
                   gsl_monte_vegas_integrate(&G_drpgdipole, xl_rpgdipole, xu_rpgdipole, 4, 1000000, r, s_drpgdipole,
                       &res_drpgdipole, &err_drpgdipole);
               } while (fabs(gsl_monte_vegas_chisq(s_drpgdipole) - 1.0) > 0.5);


           }
           double rpigdipole = sqrt(6 * res_drpgdipole / res_rpgdipole) * hc;
           file <<"rpigdipole: " <<rpigdipole << " rpigdipole_err: " << sqrt(6 * err_drpgdipole * err_rpgdipole / res_rpgdipole / res_rpgdipole) * hc << endl;
           double hi2 = 0.5 * ((fpidipole - fpiexp) * (fpidipole - fpiexp) / fpiexperr / fpiexperr + (rpigdipole - rpigexp) * (rpigdipole - rpigexp) / rpigexperr / rpigexperr);
           file <<"hi2: "<< hi2 << endl;*/
         {
         
             gsl_monte_vegas_state* s_rf1 = gsl_monte_vegas_alloc(4);
             gsl_monte_function G_rf1 = { &rpif_pk, 4,&params1 };
             gsl_monte_vegas_integrate(&G_rf1, xl_norm, xu_norm, 4, 1000000, r, s_rf1,
                 &res_rfria, &err_rfria);
             do
             {
                 gsl_monte_vegas_integrate(&G_rf1, xl_norm, xu_norm, 4, 1000000, r, s_rf1,
                     &res_rfria, &err_rfria);
             } while (fabs(gsl_monte_vegas_chisq(s_rf1) - 1.0) > 0.5);
             //cout << res_rf1;

             
         }
         double rpiria = (6 * res_rfria * N) * hc * hc;
         file << "rpiria2: " << rpiria << " rpiria2_err: " << (6 * err_rfria * N) * hc * hc << endl;
         {

             gsl_monte_vegas_state* s_rfint1 = gsl_monte_vegas_alloc(4);
             gsl_monte_function G_rfint1 = { &rpifINT1_pk, 4,&params1 };
             gsl_monte_vegas_integrate(&G_rfint1, xl_norm, xu_norm, 4, 1000000, r, s_rfint1,
                 &res_rfint1, &err_rfint1);
             do
             {
                 gsl_monte_vegas_integrate(&G_rfint1, xl_norm, xu_norm, 4, 1000000, r, s_rfint1,
                     &res_rfint1, &err_rfint1);
             } while (fabs(gsl_monte_vegas_chisq(s_rfint1) - 1.0) > 0.5);
             //cout << res_rf1;
            

             
         }
         double rpiint1 = (-6 * res_rfint1 * N) * hc * hc;
         //{

         //    gsl_monte_vegas_state* s_rfint2 = gsl_monte_vegas_alloc(4);
         //    gsl_monte_function G_rfint2 = { &rpifINT2, 4,&params1 };
         //    gsl_monte_vegas_integrate(&G_rfint2, xl_norm, xu_norm, 4, 1000000, r, s_rfint2,
         //        &res_rfint2, &err_rfint2);
         //    do
         //    {
         //        gsl_monte_vegas_integrate(&G_rfint2, xl_norm, xu_norm, 4, 1000000, r, s_rfint2,
         //            &res_rfint2, &err_rfint2);
         //    } while (fabs(gsl_monte_vegas_chisq(s_rfint2) - 1.0) > 0.5);
         //    //cout << res_rf1;
         //   

         //}
         //double rpiint2 = (-6 * res_rfint2 * N) * hc * hc;
         file <<"rpiint2: "<< 2*rpiint1 <<" rpiint2_err: "<< sqrt((-6 * err_rfint1 * N) * hc * hc* (-6 * err_rfint1 * N) * hc * hc + (-6 * err_rfint1 * N) * hc * hc* (-6 * err_rfint1 * N) * hc * hc) << endl;
         file << "sum:  " << rpiria + 2 * rpiint1 << " sum_err: " << sqrt((6 * err_rfria * N) * hc * hc * (6 * err_rfria * N) * hc * hc + (-6 * err_rfint1 * N) * hc * hc * (-6 * err_rfint1 * N) * hc * hc + (-6 * err_rfint1 * N) * hc * hc * (-6 * err_rfint1 * N) * hc * hc) << endl;
         file << endl;
         //{
        // 
        //     gsl_monte_vegas_state* s_rf1dipole = gsl_monte_vegas_alloc(4);
        //     gsl_monte_function G_rf1dipole = { &rpiRIAdipole, 4,&params1 };
        //     gsl_monte_vegas_integrate(&G_rf1dipole, xl_norm, xu_norm, 4, 1000000, r, s_rf1dipole,
        //         &res_rfriadipole, &err_rfriadipole);
        //     do
        //     {
        //         gsl_monte_vegas_integrate(&G_rf1dipole, xl_norm, xu_norm, 4, 1000000, r, s_rf1dipole,
        //             &res_rfriadipole, &err_rfriadipole);
        //     } while (fabs(gsl_monte_vegas_chisq(s_rf1dipole) - 1.0) > 0.5);
        //    

        //     
        // }
        // double rpiriadipole = (6 * res_rfriadipole * N) * hc * hc;
        // file << "rpiria2dipole: " << rpiriadipole << " rpiria2_errdipole: " << (6 * err_rfriadipole * N) * hc * hc << endl;
        // {

        //    gsl_monte_vegas_state* s_rfint1dipole = gsl_monte_vegas_alloc(4);
        //    gsl_monte_function G_rfint1dipole = { &rpifINT1dipole, 4,&params1 };
        //    gsl_monte_vegas_integrate(&G_rfint1dipole, xl_norm, xu_norm, 4, 1000000, r, s_rfint1dipole,
        //    &res_rfint1dipole, &err_rfint1dipole);
        //    do
        //    {
        //        gsl_monte_vegas_integrate(&G_rfint1dipole, xl_norm, xu_norm, 4, 1000000, r, s_rfint1dipole,
        //        &res_rfint1dipole, &err_rfint1dipole);
        //    } while (fabs(gsl_monte_vegas_chisq(s_rfint1dipole) - 1.0) > 0.5);
        //   

        // }
        // double rpiint1dipole = (-6 * res_rfint1dipole * N) * hc * hc;
        // file <<"rpiint2dipole: "<< 2*rpiint1dipole <<" rpiint2_errdipole: "<< sqrt((-6 * err_rfint1dipole * N) * hc * hc* (-6 * err_rfint1dipole * N) * hc * hc + (-6 * err_rfint1dipole * N) * hc * hc* (-6 * err_rfint1dipole * N) * hc * hc) << endl;
        // file << "sumdipole:  " << rpiriadipole + 2 * rpiint1dipole << " sum_errdipole: " << sqrt((6 * err_rfriadipole * N) * hc * hc * (6 * err_rfriadipole * N) * hc * hc + (-6 * err_rfint1dipole * N) * hc * hc * (-6 * err_rfint1dipole * N) * hc * hc + (-6 * err_rfint1dipole * N) * hc * hc * (-6 * err_rfint1dipole * N) * hc * hc) << endl;
         //double Q20 = 0, Q200 = 1e-2;
             //double q2 = -Q2;
             //double eta = -q2 / (4 * m * m);
             //struct my_f_params paramsr0 = { Q200,m,mq,b,b2,N };
             //{

             //    gsl_monte_vegas_state* s_rf1= gsl_monte_vegas_alloc(4);
             //    gsl_monte_function G_rf1 = { &grianorm, 4,&paramsr0 };
             //    gsl_monte_vegas_integrate(&G_rf1, xl_norm, xu_norm, 4, 1000000, r, s_rf1,
             //        &res_rf1, &err_rf1);
             //    do
             //    {
             //        gsl_monte_vegas_integrate(&G_rf1, xl_norm, xu_norm, 4, 1000000, r, s_rf1,
             //            &res_rf1, &err_rf1);
             //    } while (fabs(gsl_monte_vegas_chisq(s_rf1) - 1.0) > 0.5);


             //}
             //struct my_f_params paramsr1 = { Q20,m,mq,b,b2,N };
             //{

             //    gsl_monte_vegas_state* s_rf2 = gsl_monte_vegas_alloc(4);
             //    gsl_monte_function G_rf2 = { &grianorm, 4,&paramsr1 };
             //    gsl_monte_vegas_integrate(&G_rf2, xl_norm, xu_norm, 4, 1000000, r, s_rf2,
             //        &res_rf2, &err_rf2);
             //    do
             //    {
             //        gsl_monte_vegas_integrate(&G_rf2, xl_norm, xu_norm, 4, 1000000, r, s_rf2,
             //            &res_rf2, &err_rf2);
             //    } while (fabs(gsl_monte_vegas_chisq(s_rf2) - 1.0) > 0.5);


             //}
             //cout <<  sqrt((6*(res_rf1 - res_rf2) * N / (2 * m ) / (Q200 - Q20)))*0.197<<endl;

             //{

             //    gsl_monte_vegas_state* s_rwr1 = gsl_monte_vegas_alloc(3);
             //    gsl_monte_function G_rwr1 = { &gwrrianorm, 3,&paramsr0 };
             //    gsl_monte_vegas_integrate(&G_rwr1, xl_wr, xu_wr, 3, 100000, r, s_rwr1,
             //        &res_rwr1, &err_rwr1);
             //    do
             //    {
             //        gsl_monte_vegas_integrate(&G_rwr1, xl_wr, xu_wr, 3, 100000, r, s_rwr1,
             //            &res_rwr1, &err_rwr1);
             //    } while (fabs(gsl_monte_vegas_chisq(s_rwr1) - 1.0) > 0.5);

             //}

             //{

             //    gsl_monte_vegas_state* s_rwr2 = gsl_monte_vegas_alloc(3);
             //    gsl_monte_function G_rwr2 = { &gwrrianorm, 3,&paramsr1 };
             //    gsl_monte_vegas_integrate(&G_rwr2, xl_wr, xu_wr, 3, 100000, r, s_rwr2,
             //        &res_rwr2, &err_rwr2);
             //    do
             //    {
             //        gsl_monte_vegas_integrate(&G_rwr2, xl_wr, xu_wr, 3, 100000, r, s_rwr2,
             //            &res_rwr2, &err_rwr2);
             //    } while (fabs(gsl_monte_vegas_chisq(s_rwr2) - 1.0) > 0.5);

             //}
             //cout << sqrt((6 * (res_rwr1 - res_rwr2) * N / (2 * m * sqrt(1 + eta)) / (Q200 - Q20)))*  0.197;
        }
    }
    
}
//0.265 0.403 0.130677 0.660468 0.955941 - monopole
//0.241 1.019 0.130599 0.668476 3.25368 - dipole
//mq: 0.244 be: 0.997 1.00843

// Запуск программы: CTRL+F5 или меню "Отладка" > "Запуск без отладки"
// Отладка программы: F5 или меню "Отладка" > "Запустить отладку"

// Советы по началу работы 
//   1. В окне обозревателя решений можно добавлять файлы и управлять ими.
//   2. В окне Team Explorer можно подключиться к системе управления версиями.
//   3. В окне "Выходные данные" можно просматривать выходные данные сборки и другие сообщения.
//   4. В окне "Список ошибок" можно просматривать ошибки.
//   5. Последовательно выберите пункты меню "Проект" > "Добавить новый элемент", чтобы создать файлы кода, или "Проект" > "Добавить существующий элемент", чтобы добавить в проект существующие файлы кода.
//   6. Чтобы снова открыть этот проект позже, выберите пункты меню "Файл" > "Открыть" > "Проект" и выберите SLN-файл.
