﻿// offshell.cpp : Этот файл содержит функцию "main". Здесь начинается и заканчивается выполнение программы.
//

// Full_formfactor.cpp : Этот файл содержит функцию "main". Здесь начинается и заканчивается выполнение программы.
//

#include<iostream>
#include<fstream>
#include <stdlib.h>
#include<cmath>
#include<complex>
#define _USE_MATH_DEFINES
#include <gsl/gsl_math.h>
#include <gsl/gsl_monte.h>
#include <gsl/gsl_monte_plain.h>
#include <gsl/gsl_monte_miser.h>
#include <gsl/gsl_monte_vegas.h>
using namespace std;

struct my_f_params { double Q2;double t;double m;double mq;double b;double b1;double N; };
struct my_f_params_1 { double Q2;double t;double m;double mq; };

double g_friaPmuFr(double* k, size_t dim, void* p)
{
    (void)(dim);

    struct my_f_params* fp = (struct my_f_params*)p;
    double x1 = k[0], x2 = k[1], x3 = k[2], x4 = k[3];
    double mpi = fp->m;
    double mq = fp->mq;
    double t = fp->t;
    double b = fp->b ;
    double q2 = -fp->Q2;
    double pq = 0.5*(-t+mpi*mpi-q2);
    double ql = q2 * (-x2 / 2.0 - 1.0 / 2.0 + x1 / 2.0 + x3 / 2.0 + x4 / 2.0) + pq * (x3 / 2.0 + 1.0 / 2.0 - x1 / 2.0 -
        x2 / 2.0);

        double pl = (-x2 / 2.0 - 1.0 / 2.0 + x1 / 2.0 + x3 / 2.0 + x4 / 2.0) * pq + t * (x3 / 2.0 + 1.0 / 2.0 - x1 / 2.0 -
            x2 / 2.0);

   
    double l2 = t * pow(x3 / 2.0 + 1.0 / 2.0 - x1 / 2.0 - x2 / 2.0, 2.0) + 2.0 * pq * (x3 / 2.0 + 1.0 / 2.0 - x1 /
        2.0 - x2 / 2.0) * (-x2 / 2.0 - 1.0 / 2.0 + x1 / 2.0 + x3 / 2.0 + x4 / 2.0) + q2 * pow(-x2 / 2.0 - 1.0 / 2.0 + x1 /
            2.0 + x3 / 2.0 + x4 / 2.0, 2.0);


    double D = (-1.0 + x1 + x2 + x3) * b * b + (3.0 / 4.0 * x2 + 1.0 / 4.0 - x1 / 4.0 - x3 / 4.0 - x4 / 4.0) * q2 + (-
        x1 - x2 - x3) * mq * mq + (3.0 / 4.0 * x3 + 1.0 / 4.0 - x1 / 4.0 - x2 / 4.0) * t - (1.0 - x1 - x2 - x3 - x4) * pq / 2.0;
    ;
    double kk = D ;
    //double SpPmu= ((2.0 * pl * pq + 4.0 * pl * pl + (2.0 * mq * mq - 2.0 * kk) * pl - 2.0 * t * (-mq * mq + kk + ql)) * q2
    //    + 2.0 * ((-mq * mq + kk) * pq + ql * (-mq * mq + kk - 2.0 * pl)) * pq) / (-pq * pq + q2 * t);
    double SpPmu = (1 / 4 * t - 2 * ql - pl - 3 * kk + 3 * mq * mq);



    if (k[1] > 1 - k[0])
    {
        return 0;
    }
    if (k[2] > 1 - k[0] - k[1])
    {
        return 0;
    }
    if (k[3] > 1 - k[0] - k[1] - k[2])
    {
        return 0;
    }

    else
    {
      
       //return (SpPmu/ (D - l2) / (D - l2) / (D - l2) );
        return (1 / (D - l2) / (D - l2) / (D - l2));
    }

}

double g_friaqmuFr(double* k, size_t dim, void* p)
{
    (void)(dim);

    struct my_f_params* fp = (struct my_f_params*)p;
    double x1 = k[0], x2 = k[1], x3 = k[2], x4 = k[3];
    double mpi = fp->m;
    double mq = fp->mq;
    double t = fp->t;
    double b = fp->b;
    double q2 = -fp->Q2;
    double eta = -q2 / (4 * fp->m * fp->m);
    double pq = 0.5 * (-t + mpi * mpi - q2);
    double ql = q2 * (-x2 / 2.0 - 1.0 / 2.0 + x1 / 2.0 + x3 / 2.0 + x4 / 2.0) + pq * (x3 / 2.0 + 1.0 / 2.0 - x1 / 2.0 -
        x2 / 2.0);

    double pl = (-x2 / 2.0 - 1.0 / 2.0 + x1 / 2.0 + x3 / 2.0 + x4 / 2.0) * pq + t * (x3 / 2.0 + 1.0 / 2.0 - x1 / 2.0 -
        x2 / 2.0);


    double l2 = t * pow(x3 / 2.0 + 1.0 / 2.0 - x1 / 2.0 - x2 / 2.0, 2.0) + 2.0 * pq * (x3 / 2.0 + 1.0 / 2.0 - x1 /
        2.0 - x2 / 2.0) * (-x2 / 2.0 - 1.0 / 2.0 + x1 / 2.0 + x3 / 2.0 + x4 / 2.0) + q2 * pow(-x2 / 2.0 - 1.0 / 2.0 + x1 /
            2.0 + x3 / 2.0 + x4 / 2.0, 2.0);



    double D = (-1.0 + x1 + x2 + x3) * b * b + (3.0 / 4.0 * x2 + 1.0 / 4.0 - x1 / 4.0 - x3 / 4.0 - x4 / 4.0) * q2 + (-
        x1 - x2 - x3) * mq * mq + (3.0 / 4.0 * x3 + 1.0 / 4.0 - x1 / 4.0 - x2 / 4.0) * t - (1.0 - x1 - x2 - x3 - x4) * pq / 2.0;
    ;
    double kk = D;

    double Spqmu = ((-2.0 * mq * mq + 2.0 * kk - 8.0 * pl) * pq * pq + (-8.0 * pl * pl + (-4.0 * mq * mq + 4.0 * kk - 2.0
        * q2 + 4.0 * ql) * pl - 2.0 * ql * (-mq * mq + kk - 2.0 * t)) * pq - 4.0 * pl * pl * q2 + ((8.0 * ql + 4.0 * q2) * t + 2.0
            * q2 * (-mq * mq + kk)) * pl - 4.0 * ((-mq * mq / 2.0 + kk / 2.0 - ql / 2.0) * q2 + ql * (-mq * mq + kk)) * t) / (-pq *
                pq + q2 * t);





    if (k[1] > 1 - k[0])
    {
        return 0;
    }
    if (k[2] > 1 - k[0] - k[1])
    {
        return 0;
    }
    if (k[3] > 1 - k[0] - k[1] - k[2])
    {
        return 0;
    }

    else
    {

        return (Spqmu / (D - l2) / (D - l2) / (D - l2));
        //return (1 / (D - l2) / (D - l2) / (D - l2));
    }

}

double g_friaPmuOur(double* k, size_t dim, void* p)
{
    (void)(dim);

    struct my_f_params* fp = (struct my_f_params*)p;
    double x1 = k[0], x2 = k[1], x3 = k[2], x4 = k[3];
    double mpi = fp->m;
    double mq = fp->mq;
    double t = fp->t;
    double b = fp->b;
    double q2 = -fp->Q2;
    double x5 = 1 - x1 - x2 - x3 - x4;
    double pq = 0.5 * (-t + mpi * mpi - q2);

    double pl = (-x2 - x5 / 2.0) * pq + (-x1 / 2.0 - x2 / 2.0 + x3 / 2.0) * t;
    //double pl =  pq + 0.5*t;
    double ql = (-x2 - x5 / 2.0) * q2 + (-x1 / 2.0 - x2 / 2.0 + x3 / 2.0) * pq;


    double l2 = t * pow(-x1 / 2.0 - x2 / 2.0 + x3 / 2.0, 2.0) + 2.0 * pq * (-x1 / 2.0 - x2 / 2.0 + x3 / 2.0) * (-x2
        / 2.0 - 1.0 / 2.0 + x1 / 2.0 + x3 / 2.0 + x4 / 2.0) + q2 * pow(-x2 / 2.0 - 1.0 / 2.0 + x1 / 2.0 + x3 / 2.0 + x4 / 2.0,
            2.0);




   // double D = (-1.0 + x1 + x2 + x3) * b * b + (3.0 / 4.0 * x2 + 1.0 / 4.0 - x1 / 4.0 - x3 / 4.0 - x4 / 4.0) * q2 + (-
     //   x1 - x2 - x3) * mq * mq + (x1 / 4.0 + x2 / 4.0 + x3 / 4.0) * t + x2 * pq;



   double D= (-1.0 + x1 + x2 + x3)* b* b + (3.0 / 4.0 * x2 + 1.0 / 4.0 - x1 / 4.0 - x3 / 4.0 - x4 / 4.0) * q2 + (-
       x1 - x2 - x3) * mq * mq + (x1 / 4.0 + x2 / 4.0 + x3 / 4.0) * t + x2 * pq;




    double kk = D ;
    //double SpPmu1 = ((-12.0 * mq * mq + 12.0 * kk + 4.0 * pl - t) * pq * pq + (8.0 * q2 * pl + 8.0 * (-mq * mq + kk - pl
    //    - 3.0 / 4.0 * t) * ql) * pq - 8.0 * q2 * (-t * t / 8.0 + (-3.0 / 2.0 * mq * mq + 3.0 / 2.0 * kk + ql - pl / 4.0) * t + pl *
    //        (-mq * mq + kk - pl))) / (-4.0 * pq * pq + 4.0 * q2 * t);


    //double SpPmu2= -2.0 * q2 * (-x2 - x5 / 2.0) - 2.0 * pq * (-x1 / 2.0 - x2 / 2.0 + x3 / 2.0) - (-x2 - x5 / 2.0) * pq -
    //    t * (-x1 / 2.0 - x2 / 2.0 + x3 / 2.0) - 3.0 * kk + 3.0 * mq * mq + t / 4.0 + (-x1 / 4.0 - x2 / 4.0 + x3 / 4.0) * (4.0 *
    //        mq * mq - 4.0 * kk + 4.0 * (-x2 - x5 / 2.0) * pq + 4.0 * t * (-x1 / 2.0 - x2 / 2.0 + x3 / 2.0) + 4.0 * pq + 3.0 * t);

    double SpPmu3= -2.0 * ql - pl - 3.0 * kk + 3.0 * mq * mq + t / 4.0 + (-x1 / 4.0 - x2 / 4.0 + x3 / 4.0) * (4.0 * mq * mq
        + 4.0 * pq + 3.0 * t) + D / 2.0 - l2 / 2.0 + 4.0 * (-x1 / 4.0 - x2 / 4.0 + x3 / 4.0) * pl - 4.0 * (-x1 / 4.0 - x2 / 4.0 +
            x3 / 4.0) * (-l2 / 2.0 + 3.0 / 2.0 * D);


    //double SpPmu = 1.0 / 4.0 * t + 3 * mq * mq - 2 * ql - pl - 3 * D;
    if (k[1] > 1 - k[0])
    {
        return 0;
    }
    if (k[2] > 1 - k[0] - k[1])
    {
        return 0;
    }
    if (k[3] > 1 - k[0] - k[1] - k[2])
    {
        return 0;
    }

    else
    {

        return (SpPmu3 / (D - l2) / (D - l2) / (D - l2));
        //return (t/ (D - l2) / (D - l2) / (D - l2)/4);
    }

}

double g_friaqmuOur(double* k, size_t dim, void* p)
{
    (void)(dim);

    struct my_f_params* fp = (struct my_f_params*)p;
    double x1 = k[0], x2 = k[1], x3 = k[2], x4 = k[3];
    double mpi = fp->m;
    double mq = fp->mq;
    double t = fp->t;
    double b = fp->b;
    double q2 = -fp->Q2;
    double x5 = 1 - x1 - x2 - x3 - x4;
    double pq = 0.5 * (-t + mpi * mpi - q2);
    double pl = (-x2 / 2.0 - 1.0 / 2.0 + x1 / 2.0 + x3 / 2.0 + x4 / 2.0) * pq + t * (-x1 / 2.0 - x2 / 2.0 + x3 / 2.0);
    double ql = q2 * (-x2 / 2.0 - 1.0 / 2.0 + x1 / 2.0 + x3 / 2.0 + x4 / 2.0) + pq * (-x1 / 2.0 - x2 / 2.0 + x3 / 2.0);

    double l2 = t * pow(-x1 / 2.0 - x2 / 2.0 + x3 / 2.0, 2.0) + 2.0 * pq * (-x1 / 2.0 - x2 / 2.0 + x3 / 2.0) * (-x2
        / 2.0 - 1.0 / 2.0 + x1 / 2.0 + x3 / 2.0 + x4 / 2.0) + q2 * pow(-x2 / 2.0 - 1.0 / 2.0 + x1 / 2.0 + x3 / 2.0 + x4 / 2.0,
            2.0);



    //double D = (-1.0 + x1 + x2 + x3) * b * b + (3.0 / 4.0 * x2 + 1.0 / 4.0 - x1 / 4.0 - x3 / 4.0 - x4 / 4.0) * q2 + (-
    //    x1 - x2 - x3) * mq * mq + (x1 / 4.0 + x2 / 4.0 + x3 / 4.0) * t + x2 * pq;
    double D = (-1.0 + x1 + x2 + x3) * b * b + (3.0 / 4.0 * x2 + 1.0 / 4.0 - x1 / 4.0 - x3 / 4.0 - x4 / 4.0) * q2 + (-
        x1 - x2 - x3) * mq * mq + (x1 / 4.0 + x2 / 4.0 + x3 / 4.0) * t + x2 * pq;


    double kk = D ;

    //double Spqmu1 = ((-4.0 * mq * mq + 4.0 * kk - 20.0 * pl - 3.0 * t) * pq * pq + ((22.0 * ql - 12.0 * pl) * t - 16.0 *
    //    pl * pl + (-16.0 * mq * mq + 16.0 * kk - 8.0 * q2 + 8.0 * ql) * pl - 8.0 * ql * (-mq * mq + kk)) * pq + (12.0 * ql +
    //        3.0 * q2) * t * t + ((16.0 * ql - 2.0 * q2) * pl + (4.0 * mq * mq - 4.0 * kk + 8.0 * ql) * q2 - 16.0 * ql * (-mq * mq +
    //            kk)) * t + 8.0 * pl * q2 * (-mq * mq + kk - pl)) / (-4.0 * pq * pq + 4.0 * q2 * t);


   
    //double Spqmu2= (-3.0 / 4.0 * x2 - x5 / 2.0 + x1 / 4.0 - x3 / 4.0) * (4.0 * mq * mq - 4.0 * kk + 4.0 * (-x2 - x5 / 2.0
    //    ) * pq + 4.0 * t * (-x1 / 2.0 - x2 / 2.0 + x3 / 2.0) + 4.0 * pq + 3.0 * t) + 2.0 * q2 * (-x2 - x5 / 2.0) + 2.0 * pq * (-
    //        x1 / 2.0 - x2 / 2.0 + x3 / 2.0) + (-x2 - x5 / 2.0) * pq + t * (-x1 / 2.0 - x2 / 2.0 + x3 / 2.0) - kk + mq * mq + 3.0 /
    //    4.0 * t;

    double Spqmu3= (-3.0 / 4.0 * x2 - x5 / 2.0 + x1 / 4.0 - x3 / 4.0) * (4.0 * mq * mq + 4.0 * pq + 3.0 * t) + 2.0 * ql +
        pl - kk + mq * mq + 3.0 / 4.0 * t - D / 2.0 + l2 / 2.0 + 4.0 * (-3.0 / 4.0 * x2 - x5 / 2.0 + x1 / 4.0 - x3 / 4.0) * pl
        - 4.0 * (-3.0 / 4.0 * x2 - x5 / 2.0 + x1 / 4.0 - x3 / 4.0) * (-l2 / 2.0 + 3.0 / 2.0 * D);




    if (k[1] > 1 - k[0])
    {
        return 0;
    }
    if (k[2] > 1 - k[0] - k[1])
    {
        return 0;
    }
    if (k[3] > 1 - k[0] - k[1] - k[2])
    {
        return 0;
    }

    else
    {

        return (Spqmu3 / (D - l2) / (D - l2) / (D - l2));
        //return (1 / (D - l2) / (D - l2) / (D - l2));
    }

}




double g_friaPmuBuck(double* k, size_t dim, void* p)
{
    (void)(dim);

    struct my_f_params* fp = (struct my_f_params*)p;
    double x1 = k[0], x2 = k[1], x3 = k[2], x4 = k[3];
    double mpi = fp->m;
    double mq = fp->mq;
    double t = fp->t;
    double b = fp->b;
    double q2 = -fp->Q2;

    double pq = 0.5 * (-t + mpi * mpi - q2);
    double pl = (-x2 / 2.0 - 1.0 / 2.0 + x1 / 2.0 + x3 / 2.0 + x4 / 2.0) * pq + t * (-x2 / 2.0 - x3 / 2.0 - 1.0 / 2.0)
        ;

    double ql = q2 * (-x2 / 2.0 - 1.0 / 2.0 + x1 / 2.0 + x3 / 2.0 + x4 / 2.0) + pq * (-x2 / 2.0 - x3 / 2.0 - 1.0 / 2.0
        );

    double l2 = t * pow(-x2 / 2.0 - x3 / 2.0 - 1.0 / 2.0 + x1 / 2.0, 2.0) + 2.0 * pq * (-x2 / 2.0 - x3 / 2.0 - 1.0 /
           2.0 + x1 / 2.0) * (-x2 / 2.0 - 1.0 / 2.0 + x1 / 2.0 + x3 / 2.0 + x4 / 2.0) + q2 * pow(-x2 / 2.0 - 1.0 / 2.0 + x1 /
               2.0 + x3 / 2.0 + x4 / 2.0, 2.0);









    double D = (-1.0 + x1 + x2 + x3) * b * b + (3.0 / 4.0 * x2 + 1.0 / 4.0 - x1 / 4.0 - x3 / 4.0 - x4 / 4.0) * q2 + (
         3.0 / 2.0 * x2 + 1.0 / 2.0 - x1 / 2.0 - x3 / 2.0 - x4 / 2.0) * pq + (-x1 - x2 - x3) * mq * mq + (3.0 / 4.0 * x2 + 3.0 /
             4.0 * x3 + 1.0 / 4.0 - x1 / 4.0) * t;






    double kk = D ;
    //double SpPmu = ((-4.0 * mq * mq + 4.0 * kk + 4.0 * pl) * pq * pq + (2.0 * q2 * pl + 2.0 * ql * (-mq * mq + kk - t)) *
    //    pq - 2.0 * q2 * ((-2.0 * mq * mq + 2.0 * kk + pl + ql) * t + pl * (-mq * mq + kk))) / (-pq * pq + q2 * t);
    double SpPmu = (1 / 4 * t - 2 * ql - pl - 3 * kk + 3 * mq * mq);







    if (k[1] > 1 - k[0])
    {
        return 0;
    }
    if (k[2] > 1 - k[0] - k[1])
    {
        return 0;
    }
    if (k[3] > 1 - k[0] - k[1] - k[2])
    {
        return 0;
    }

    else
    {

        return (SpPmu / (D - l2) / (D - l2) / (D - l2));
        //return (1 / (D - l2) / (D - l2) / (D - l2));
    }

}

double g_friaqmuBuck(double* k, size_t dim, void* p)
{
    (void)(dim);

    struct my_f_params* fp = (struct my_f_params*)p;
    double x1 = k[0], x2 = k[1], x3 = k[2], x4 = k[3];
    double mpi = fp->m;
    double mq = fp->mq;
    double t = fp->t;
    double b = fp->b;
    double q2 = -fp->Q2;

    double pq = 0.5 * (-t + mpi * mpi - q2);
    double pl = (-x2 / 2.0 - 1.0 / 2.0 + x1 / 2.0 + x3 / 2.0 + x4 / 2.0) * pq + t * (-x2 / 2.0 - x3 / 2.0 - 1.0 / 2.0)
        ;

    double ql = q2 * (-x2 / 2.0 - 1.0 / 2.0 + x1 / 2.0 + x3 / 2.0 + x4 / 2.0) + pq * (-x2 / 2.0 - x3 / 2.0 - 1.0 / 2.0
        );


    //double l2 = t * pow(-x2 / 2.0 - x3 / 2.0 - 1.0 / 2.0 + x1 / 2.0, 2.0) + 2.0 * pq * (-x2 / 2.0 - x3 / 2.0 - 1.0 /
    //    2.0 + x1 / 2.0) * (-x2 / 2.0 - 1.0 / 2.0 + x1 / 2.0 + x3 / 2.0 + x4 / 2.0) + q2 * pow(-x2 / 2.0 - 1.0 / 2.0 + x1 /
    //        2.0 + x3 / 2.0 + x4 / 2.0, 2.0);
    double l2= t * pow(-x1 / 2.0 - x3 / 2.0 - 1.0 / 2.0 + x2 / 2.0, 2.0) + 2.0 * pq * (-x1 / 2.0 - x3 / 2.0 - 1.0 /
        2.0 + x2 / 2.0) * (-x3 / 2.0 - 1.0 / 2.0 + x1 / 2.0 + x2 / 2.0 + x4 / 2.0) + q2 * pow(-x3 / 2.0 - 1.0 / 2.0 + x1 /
            2.0 + x2 / 2.0 + x4 / 2.0, 2.0);








   /* double D = (-1.0 + x1 + x2 + x3) * b * b + (3.0 / 4.0 * x2 + 1.0 / 4.0 - x1 / 4.0 - x3 / 4.0 - x4 / 4.0) * q2 + (
        3.0 / 2.0 * x2 + 1.0 / 2.0 - x1 / 2.0 - x3 / 2.0 - x4 / 2.0) * pq + (-x1 - x2 - x3) * mq * mq + (3.0 / 4.0 * x2 + 3.0 /
            4.0 * x3 + 1.0 / 4.0 - x1 / 4.0) * t;*/
    double D= (-1.0 + x1 + x2 + x3)* b* b + (3.0 / 4.0 * x3 + 1.0 / 4.0 - x1 / 4.0 - x2 / 4.0 - x4 / 4.0) * q2 + (
        3.0 / 2.0 * x3 + 1.0 / 2.0 - x1 / 2.0 - x2 / 2.0 - x4 / 2.0) * pq + (-x1 - x3 - x2) * mq * mq + (3.0 / 4.0 * x1 + 3.0 /
            4.0 * x3 + 1.0 / 4.0 - x2 / 4.0) * t;






    double kk = D ;

    double Spqmu = (-4.0 * pl * pq * pq + ((-4.0 * mq * mq + 4.0 * kk - 2.0 * q2 - 4.0 * t) * pl - 2.0 * ql * (-mq * mq +
        kk - 3.0 * t)) * pq + 2.0 * q2 * (-mq * mq + kk - t) * pl - 4.0 * ql * (-mq * mq + kk - t - q2 / 2.0) * t) / (-pq * pq + q2
            * t);






    if (k[1] > 1 - k[0])
    {
        return 0;
    }
    if (k[2] > 1 - k[0] - k[1])
    {
        return 0;
    }
    if (k[3] > 1 - k[0] - k[1] - k[2])
    {
        return 0;
    }

    else
    {

        return (Spqmu / (D - l2) / (D - l2) / (D - l2));
        //return (1 / (D - l2) / (D - l2) / (D - l2));
    }

}


double g1_fintPmuBuck(double* k, size_t dim, void* p)
{
    (void)(dim);

    struct my_f_params* fp = (struct my_f_params*)p;
    double x1 = k[0], x2 = k[1], x3 = k[2], x4 = k[3];
    double x5 = 1 - x1 - x2 - x3 - x4;
    double mpi = fp->m;
    double mq = fp->mq;
    double t = fp->t;
    double b2 = fp->b1 ;
    double b1 = fp->b;
    
    double q2 = -fp->Q2;

    double pq = 0.5 * (-t + mpi * mpi - q2);

    double l2 = t * pow(-x4 + 1.0 / 2.0 - x1 / 2.0 - x2 / 2.0 - x3 / 2.0, 2.0) - pq * x1 * (-x4 + 1.0 / 2.0 - x1 /
        2.0 - x2 / 2.0 - x3 / 2.0) + q2 * x1 * x1 / 4.0;





    double D = (-x1 - x3) * b1 * b1 + (-1.0 + x1 + x2 + x3) * mq * mq + (1.0 / 4.0 - x1 / 4.0 - x2 / 4.0 - x3 / 4.0) *
        t + x1 * q2 / 4.0 - b2 * b2 * x2;





    double kk = D ;
    double pl = t * (-x4 + 1.0 / 2.0 - x1 / 2.0 - x2 / 2.0 - x3 / 2.0) - x1 * pq / 2.0;
    double ql = pq * (-x4 + 1.0 / 2.0 - x1 / 2.0 - x2 / 2.0 - x3 / 2.0) - x1 * q2 / 2.0;
    double SpPmu = -4.0 * (-x4 / 4.0 + x5 / 4.0) * (-l2 / 2.0 + 3.0 / 2.0 * D) + (-x4 / 4.0 + x5 / 4.0) * (4.0 * mq *
        mq + t);


    if (k[1] > 1 - k[0])
    {
        return 0;
    }
    if (k[2] > 1 - k[0] - k[1])
    {
        return 0;
    }
    if (k[3] > 1 - k[0] - k[1] - k[2])
    {
        return 0;
    }

    else
    {
        return (SpPmu/ (D - l2) / (D - l2) / (D - l2) );

    }

}

double g1_fintqmuBuck(double* k, size_t dim, void* p)
{
    (void)(dim);

    struct my_f_params* fp = (struct my_f_params*)p;
    double x1 = k[0], x2 = k[1], x3 = k[2], x4 = k[3];
    double x5 = 1 - x1 - x2 - x3 - x4;
    double mpi = fp->m;
    double mq = fp->mq;
    double t = fp->t;
    double b2 = fp->b1;
    double b1 = fp->b;

    double q2 = -fp->Q2;

    double pq = 0.5 * (-t + mpi * mpi - q2);


    double l2 = t * pow(-x4 + 1.0 / 2.0 - x1 / 2.0 - x2 / 2.0 - x3 / 2.0, 2.0) - pq * x1 * (-x4 + 1.0 / 2.0 - x1 /
        2.0 - x2 / 2.0 - x3 / 2.0) + q2 * x1 * x1 / 4.0;




    double D = (-x1 - x3) * b1 * b1 + (-1.0 + x1 + x2 + x3) * mq * mq + (1.0 / 4.0 - x1 / 4.0 - x2 / 4.0 - x3 / 4.0) *
        t + x1 * q2 / 4.0 - b2 * b2 * x2;




    double kk = D ;
    double pl = t * (-x4 + 1.0 / 2.0 - x1 / 2.0 - x2 / 2.0 - x3 / 2.0) - x1 * pq / 2.0;
    double ql = pq * (-x4 + 1.0 / 2.0 - x1 / 2.0 - x2 / 2.0 - x3 / 2.0) - x1 * q2 / 2.0;
    double Spqmu = -4.0 * (x4 / 4.0 - x5 / 4.0 - x1 / 2.0) * (-l2 / 2.0 + 3.0 / 2.0 * D) + (x4 / 4.0 - x5 / 4.0 - x1 /
        2.0) * (4.0 * mq * mq + t) - kk + mq * mq + t / 4.0;





    if (k[1] > 1 - k[0])
    {
        return 0;
    }
    if (k[2] > 1 - k[0] - k[1])
    {
        return 0;
    }
    if (k[3] > 1 - k[0] - k[1] - k[2])
    {
        return 0;
    }

    else
    {
        return (Spqmu / (D - l2) / (D - l2) / (D - l2));

    }

}

double g2_fintPmuBuck(double* k, size_t dim, void* p)
{
    (void)(dim);

    struct my_f_params* fp = (struct my_f_params*)p;
    double x1 = k[0], x2 = k[1], x3 = k[2], x4 = k[3];
    double x5 = 1 - x1 - x2 - x3 - x4;
    double mpi = fp->m;
    double mq = fp->mq;
    double t = fp->t;
    double b2 = fp->b1;
    double b1 = fp->b;

    double q2 = -fp->Q2;

    double pq = 0.5 * (-t + mpi * mpi - q2);

    double l2 = t * pow(x4 - 1.0 / 2.0 + x1 / 2.0 + x2 / 2.0 + x3 / 2.0, 2.0) + 2.0 * pq * (x1 + x4 - 1.0 / 2.0 + x2 /
        2.0 + x3 / 2.0) * (x4 - 1.0 / 2.0 + x1 / 2.0 + x2 / 2.0 + x3 / 2.0) + q2 * pow(x1 + x4 - 1.0 / 2.0 + x2 / 2.0 + x3 /
            2.0, 2.0);





    double D = (-x1 - x3) * b1 * b1 + (1.0 / 4.0 - x2 / 4.0 - x3 / 4.0) * q2 + (1.0 / 2.0 - x1 / 2.0 - x2 / 2.0 - x3 /
        2.0) * pq + (-1.0 + x1 + x2 + x3) * mq * mq + (1.0 / 4.0 - x1 / 4.0 - x2 / 4.0 - x3 / 4.0) * t - b2 * b2 * x2;




    double kk = D ;
    double pl = t * (x4 - 1.0 / 2.0 + x1 / 2.0 + x2 / 2.0 + x3 / 2.0) + pq * (x1 + x4 - 1.0 / 2.0 + x2 / 2.0 + x3 / 2.0);
    double ql = pq * (x4 - 1.0 / 2.0 + x1 / 2.0 + x2 / 2.0 + x3 / 2.0) + q2 * (x1 + x4 - 1.0 / 2.0 + x2 / 2.0 + x3 / 2.0
        );



    double SpPmu = -4.0 * (x4 / 4.0 - x5 / 4.0) * (-l2 / 2.0 + 3.0 / 2.0 * D) + (x4 / 4.0 - x5 / 4.0) * (4.0 * mq * mq +
        2.0 * pq + q2 + t);


    if (k[1] > 1 - k[0])
    {
        return 0;
    }
    if (k[2] > 1 - k[0] - k[1])
    {
        return 0;
    }
    if (k[3] > 1 - k[0] - k[1] - k[2])
    {
        return 0;
    }

    else
    {
        return (SpPmu / (D - l2) / (D - l2) / (D - l2) );

    }

}

double g2_fintqmuBuck(double* k, size_t dim, void* p)
{
    (void)(dim);

    struct my_f_params* fp = (struct my_f_params*)p;
    double x1 = k[0], x2 = k[1], x3 = k[2], x4 = k[3];
    double x5 = 1 - x1 - x2 - x3 - x4;
    double mpi = fp->m;
    double mq = fp->mq;
    double t = fp->t;
    double b2 = fp->b1;
    double b1 = fp->b;

    double q2 = -fp->Q2;

    double pq = 0.5 * (-t + mpi * mpi - q2);

    double l2 = t * pow(x4 - 1.0 / 2.0 + x1 / 2.0 + x2 / 2.0 + x3 / 2.0, 2.0) + 2.0 * pq * (x1 + x4 - 1.0 / 2.0 + x2 /
        2.0 + x3 / 2.0) * (x4 - 1.0 / 2.0 + x1 / 2.0 + x2 / 2.0 + x3 / 2.0) + q2 * pow(x1 + x4 - 1.0 / 2.0 + x2 / 2.0 + x3 /
            2.0, 2.0);



    double D = (-x1 - x3) * b1 * b1 + (1.0 / 4.0 - x2 / 4.0 - x3 / 4.0) * q2 + (1.0 / 2.0 - x1 / 2.0 - x2 / 2.0 - x3 /
        2.0) * pq + (-1.0 + x1 + x2 + x3) * mq * mq + (1.0 / 4.0 - x1 / 4.0 - x2 / 4.0 - x3 / 4.0) * t - b2 * b2 * x2;



    double kk = D ;
    double pl = t * (x4 - 1.0 / 2.0 + x1 / 2.0 + x2 / 2.0 + x3 / 2.0) + pq * (x1 + x4 - 1.0 / 2.0 + x2 / 2.0 + x3 / 2.0);
    double ql = pq * (x4 - 1.0 / 2.0 + x1 / 2.0 + x2 / 2.0 + x3 / 2.0) + q2 * (x1 + x4 - 1.0 / 2.0 + x2 / 2.0 + x3 / 2.0);
    double Spqmu = -4.0 * (x1 / 2.0 + x4 / 4.0 - x5 / 4.0) * (-l2 / 2.0 + 3.0 / 2.0 * D) + (x1 / 2.0 + x4 / 4.0 - x5 /
        4.0) * (4.0 * mq * mq + 2.0 * pq + q2 + t) - pq / 2.0 + kk - q2 / 4.0 - t / 4.0 - mq * mq;




    if (k[1] > 1 - k[0])
    {
        return 0;
    }
    if (k[2] > 1 - k[0] - k[1])
    {
        return 0;
    }
    if (k[3] > 1 - k[0] - k[1] - k[2])
    {
        return 0;
    }

    else
    {
        return (Spqmu / (D - l2) / (D - l2) / (D - l2));

    }

}


double F1(double* k, size_t dim, void* p)
{
    (void)(dim);

    struct my_f_params_1* fp = (struct my_f_params_1*)p;
    double x = k[0], y = k[1];
    double mpi = fp->m;
    double mq = fp->mq;
    double t = fp->t;
    double q2 = -fp->Q2;
   
    double qp = (mpi * mpi - q2 - t) / 2;
    double qE = (x - y) * q2 - y*qp;
    double pE = (x - y) * qp - y * t;
    double E2 = (x - y) * (x - y) * q2 - 2 * qp * (x - y) * y + y * y * t;
    double C = (x - y) * (x - y - 1) * q2 - y * (1 - y) * t - 2 * y * (x - y) * qp + mq * mq;
    double alpha = (1 + y) * (E2 - mq * mq) - qE + 2 * y * pE - y * qp;
    double beta = (1 - x + y) * (E2 - mq * mq) + (1 - 2 * x + 2 * y) * pE + (x - y) * qp;

    if (k[1] > k[0])
    {
        return 0;
    }

    else
    {

        return ((1+3*y)*log(C)+alpha/C);
    }

}

double F2(double* k, size_t dim, void* p)
{
    (void)(dim);

    struct my_f_params_1* fp = (struct my_f_params_1*)p;
    double x = k[0], y = k[1];
    double mpi = fp->m;
    double mq = fp->mq;
    double t = fp->t;
    double q2 = -fp->Q2;

    double qp = (mpi * mpi - q2 - t) / 2;
    double qE = (x - y) * q2 - y * qp;
    double pE = (x - y) * qp - y * t;
    double E2 = (x - y) * (x - y) * q2 - 2 * qp * (x - y) * y + y * y * t;
    double C = (x - y) * (x - y - 1) * q2 - y * (1 - y) * t - 2 * y * (x - y) * qp + mq * mq;
    double alpha = (1 + y) * (E2 - mq * mq) - qE + 2 * y * pE - y * qp;
    double beta = (1 - x + y) * (E2 - mq * mq) + (1 - 2 * x + 2 * y) * pE + (x - y) * qp;

    if (k[1] > k[0])
    {
        return 0;
    }

    else
    {

        return (3*(1-2*x+y)*log(C)+(2*beta-alpha)/C);
    }

}


int main()
{



    double res_f, err_f;
    double xl_f[4] = { 0,0,0,0 };
    double xu_f[4] = { 1,1,1,1 };
    double res1_res, err1_res;

    double F1int, F2int,F10int;
    double res_f1, res_f2, res_f10, err_f1, err_f2, err_f10;
    double res_f1int1, res_f2int1, res_f10int1, err_f1int1, err_f2int1, err_f10int1;
    double res_f1int2, res_f2int2, res_f10int2, err_f1int2, err_f2int2, err_f10int2;
    double xl[2] = { 0,0 };
    double xu[2] = { 1,1 };
    const gsl_rng_type* T;
    gsl_rng* r;

    gsl_rng_env_setup();

    T = gsl_rng_default;
    r = gsl_rng_alloc(T);
    double m = 0.14;
    double mq = 0.22;
    double Q2 = 0;
    double t = m*m;
    double b = 0.6;
    double b1 = 0.600001;
    double N21 = -0.00596118;//4.69579e-07
    double N22 = -0.0174739;//2.00517e-06
    double N23 = -0.00324541;//3.87599e-07
    double N24 = -0.00284119;
    double N25 = -0.0033686;
    double N26 = -0.0496939;
    double N27 = -0.0104346;
    double N28 = -0.00613619;
    double Npk1 = -0.00599878;
    double norm = -8.25709;
    ofstream file("WTI.txt");
    //for (double Q2 = 0;Q2 < 5.1;Q2 += 0.05)
    { 
        
    //    {

    //        struct my_f_params params1 = { Q2,t,m,mq,b,b1,N21 };
    //        gsl_monte_vegas_state* s_f1 = gsl_monte_vegas_alloc(4);
    //        gsl_monte_function G_f1 = { &g1_fintPmuBuck, 4,&params1 };
    //        gsl_monte_vegas_integrate(&G_f1, xl_f, xu_f, 4, 1000000, r, s_f1,
    //            &res_f1int1, &err_f1int1);
    //        do
    //        {
    //            gsl_monte_vegas_integrate(&G_f1, xl_f, xu_f, 4, 1000000, r, s_f1,
    //                &res_f1int1, &err_f1int1);
    //        } while (fabs(gsl_monte_vegas_chisq(s_f1) - 1.0) > 0.5);

    //        struct my_f_params params10 = { 0,t,m,mq,b,b1,N21 };
    //        gsl_monte_vegas_state* s_f10 = gsl_monte_vegas_alloc(4);
    //        gsl_monte_function G_f10 = { &g1_fintPmuBuck, 4,&params10 };
    //        gsl_monte_vegas_integrate(&G_f10, xl_f, xu_f, 4, 1000000, r, s_f10,
    //            &res_f10int1, &err_f10int1);
    //        do
    //        {
    //            gsl_monte_vegas_integrate(&G_f10, xl_f, xu_f, 4, 1000000, r, s_f10,
    //                &res_f10int1, &err_f10int1);
    //        } while (fabs(gsl_monte_vegas_chisq(s_f10) - 1.0) > 0.5);

    //        gsl_monte_vegas_state* s_f2 = gsl_monte_vegas_alloc(4);
    //        gsl_monte_function G_f2 = { &g1_fintqmuBuck, 4,&params1 };
    //        gsl_monte_vegas_integrate(&G_f2, xl_f, xu_f, 4, 1000000, r, s_f2,
    //            &res_f2int1, &err_f2int1);
    //        do
    //        {
    //            gsl_monte_vegas_integrate(&G_f2, xl_f, xu_f, 4, 1000000, r, s_f2,
    //                &res_f2int1, &err_f2int1);
    //        } while (fabs(gsl_monte_vegas_chisq(s_f2) - 1.0) > 0.5);

    //    }

    //{

    //    struct my_f_params params1 = { Q2,t,m,mq,b,b1,N21 };
    //    gsl_monte_vegas_state* s_f1 = gsl_monte_vegas_alloc(4);
    //    gsl_monte_function G_f1 = { &g2_fintPmuBuck, 4,&params1 };
    //    gsl_monte_vegas_integrate(&G_f1, xl_f, xu_f, 4, 1000000, r, s_f1,
    //        &res_f1int2, &err_f1int2);
    //    do
    //    {
    //        gsl_monte_vegas_integrate(&G_f1, xl_f, xu_f, 4, 1000000, r, s_f1,
    //            &res_f1int2, &err_f1int2);
    //    } while (fabs(gsl_monte_vegas_chisq(s_f1) - 1.0) > 0.5);

    //    struct my_f_params params10 = { 0,t,m,mq,b,b1,N21 };
    //    gsl_monte_vegas_state* s_f10 = gsl_monte_vegas_alloc(4);
    //    gsl_monte_function G_f10 = { &g2_fintPmuBuck, 4,&params10 };
    //    gsl_monte_vegas_integrate(&G_f10, xl_f, xu_f, 4, 1000000, r, s_f10,
    //        &res_f10int2, &err_f10int2);
    //    do
    //    {
    //        gsl_monte_vegas_integrate(&G_f10, xl_f, xu_f, 4, 1000000, r, s_f10,
    //            &res_f10int2, &err_f10int2);
    //    } while (fabs(gsl_monte_vegas_chisq(s_f10) - 1.0) > 0.5);

    //    gsl_monte_vegas_state* s_f2 = gsl_monte_vegas_alloc(4);
    //    gsl_monte_function G_f2 = { &g2_fintqmuBuck, 4,&params1 };
    //    gsl_monte_vegas_integrate(&G_f2, xl_f, xu_f, 4, 1000000, r, s_f2,
    //        &res_f2int2, &err_f2int2);
    //    do
    //    {
    //        gsl_monte_vegas_integrate(&G_f2, xl_f, xu_f, 4, 1000000, r, s_f2,
    //            &res_f2int2, &err_f2int2);
    //    } while (fabs(gsl_monte_vegas_chisq(s_f2) - 1.0) > 0.5);


    //}

    ////F1int = ((t - m * m) / Q2) * (res_f10int1 - res_f1int1) + ((t - m * m) / Q2) * (res_f10int2 - res_f1int2);
    //F2int = res_f2int1 + res_f2int2;
    //F1int = res_f1int1 + res_f1int2;
    //F10int = res_f10int1 + res_f10int2;
    /*cout << res_f1int1<<" "<< err_f1int1 << endl;
    cout << res_f2int1 << " " << err_f2int1 << endl;
    cout << res_f1int2 << " " << err_f1int2 << endl;
    cout << res_f2int2 << " " << err_f2int2 << endl;*/
   // cout << "Our:" << endl;
      //cout <<" eq "<< ((t - m * m) / Q2) * (res_f10int1 - res_f1int1) + ((t - m * m) / Q2) * (res_f10int2 - res_f1int2)<<endl;

        //cout << "t:" << t << endl;
        //cout << "Q2:" << Q2 << endl;
        //cout << "pq:" << 0.5 * (-t + m * m + Q2) << endl;
         {

             struct my_f_params params1 = { Q2,t,m,mq,b,b1,N21 };
             gsl_monte_vegas_state* s_f1 = gsl_monte_vegas_alloc(4);
             gsl_monte_function G_f1 = { &g_friaPmuOur, 4,&params1 };
             gsl_monte_vegas_integrate(&G_f1, xl_f, xu_f, 4, 1000000, r, s_f1,
                 &res_f1, &err_f1);
             do
             {
                 gsl_monte_vegas_integrate(&G_f1, xl_f, xu_f, 4, 1000000, r, s_f1,
                     &res_f1, &err_f1);
             } while (fabs(gsl_monte_vegas_chisq(s_f1) - 1.0) > 0.5);

             struct my_f_params params10 = { 0,t,m,mq,b,b1,N21 };
             gsl_monte_vegas_state* s_f10 = gsl_monte_vegas_alloc(4);
             gsl_monte_function G_f10 = { &g_friaPmuOur, 4,&params10 };
             gsl_monte_vegas_integrate(&G_f10, xl_f, xu_f, 4, 1000000, r, s_f10,
                 &res_f10, &err_f10);
             do
             {
                 gsl_monte_vegas_integrate(&G_f10, xl_f, xu_f, 4, 1000000, r, s_f10,
                     &res_f10, &err_f10);
             } while (fabs(gsl_monte_vegas_chisq(s_f10) - 1.0) > 0.5);

             gsl_monte_vegas_state* s_f2 = gsl_monte_vegas_alloc(4);
             gsl_monte_function G_f2 = { &g_friaqmuOur, 4,&params1 };
             gsl_monte_vegas_integrate(&G_f2, xl_f, xu_f, 4, 1000000, r, s_f2,
                 &res_f2, &err_f2);
             do
             {
                 gsl_monte_vegas_integrate(&G_f2, xl_f, xu_f, 4, 1000000, r, s_f2,
                     &res_f2, &err_f2);
             } while (fabs(gsl_monte_vegas_chisq(s_f2) - 1.0) > 0.5);
           
        
             //cout << ((t - m * m) / Q2) * (res_f10 - res_f1) << endl;
             //cout <<" F1ria    "<< res_f1/ res_f10 <<" "<< err_f1 << endl;
            //cout << " F10ria  " << res_f10/ norm << " " << err_f10 << endl;
             //cout << " F2ria   " << res_f2/ res_f10 << " " << err_f2 << endl;
             //cout << "F1int:  " << F1int / res_f10 << " " << sqrt(err_f1int1 * err_f1int1 + err_f1int2 * err_f1int2) << endl;
             //cout << " F10int " << (res_f10int1 + res_f10int2) / norm << endl;
             //cout << "F2int:  " << F2int / res_f10 << " " << sqrt(err_f2int1 * err_f2int1 + err_f2int2 * err_f2int2) << endl;

            // cout << " eq   " << ((t - m * m) / Q2) * (res_f10 - res_f1)  << endl;
   
            // cout <<"eq "<<(((t - m * m) / Q2) * (res_f10 - res_f1) + ((t - m * m) / Q2) * (res_f10int1 - res_f1int1) + ((t - m * m) / Q2) * (res_f10int2 - res_f1int2))/no << endl;
             
             //cout << "F1ria " << (res_f1+ F1int) / norm <<" "<<sqrt(err_f1*err_f1+ err_f1int1 * err_f1int1 + err_f1int2 * err_f1int2)<< endl;
             //cout << "F10 " << (res_f10 + res_f10int1 + res_f10int2) / norm << " " << sqrt(err_f10 * err_f10 + err_f10int1 * err_f10int1 + err_f10int2 * err_f10int2) << endl;
             //cout <<"g "<< (res_f2 + F2int)/ norm /(t-m*m) <<" "<< sqrt(err_f2*err_f2+ err_f2int1 * err_f2int1 + err_f2int2 * err_f2int2)<< endl;
             //cout << endl;
             //file <<Q2 << " " << -Q2*(res_f2 )/ norm <<" "<<(((-t + m * m) ) * (res_f10 - res_f1)) / norm << " " << -Q2 * ( F2int) / norm << " " << ( ((-t + m * m)) * (res_f10int1 - res_f1int1) + ((-t + m * m)) * (res_f10int2 - res_f1int2)) / norm<<   endl;
             //cout << "F1ria " << (res_f1 ) / norm << " F1int " << ( F1int) / norm << " F1tot " << (res_f1 + F1int) / norm  << endl;
             //cout << "gria " << (res_f2 ) / norm / (t - m * m) << " gint " << ( F2int) / norm / (t - m * m) << " gtot " << (res_f2 + F2int) / norm / (t - m * m) << endl;
           cout << res_f1 ;


         }


     }

 /*{

     {

         struct my_f_params params1 = { Q2,t,m,mq,b,b1,N21 };
         gsl_monte_vegas_state* s_f1 = gsl_monte_vegas_alloc(4);
         gsl_monte_function G_f1 = { &g_friaPmuFr, 4,&params1 };
         gsl_monte_vegas_integrate(&G_f1, xl_f, xu_f, 4, 100000, r, s_f1,
             &res_f1, &err_f1);
         do
         {
             gsl_monte_vegas_integrate(&G_f1, xl_f, xu_f, 4, 100000, r, s_f1,
                 &res_f1, &err_f1);
         } while (fabs(gsl_monte_vegas_chisq(s_f1) - 1.0) > 0.5);

         struct my_f_params params10 = { 0,t,m,mq,b,b1,N21 };
         gsl_monte_vegas_state* s_f10 = gsl_monte_vegas_alloc(4);
         gsl_monte_function G_f10 = { &g_friaPmuFr, 4,&params10 };
         gsl_monte_vegas_integrate(&G_f10, xl_f, xu_f, 4, 100000, r, s_f10,
             &res_f10, &err_f10);
         do
         {
             gsl_monte_vegas_integrate(&G_f10, xl_f, xu_f, 4, 100000, r, s_f10,
                 &res_f10, &err_f10);
         } while (fabs(gsl_monte_vegas_chisq(s_f10) - 1.0) > 0.5);

         gsl_monte_vegas_state* s_f2 = gsl_monte_vegas_alloc(4);
         gsl_monte_function G_f2 = { &g_friaqmuFr, 4,&params1 };
         gsl_monte_vegas_integrate(&G_f2, xl_f, xu_f, 4, 100000, r, s_f2,
             &res_f2, &err_f2);
         do
         {
             gsl_monte_vegas_integrate(&G_f2, xl_f, xu_f, 4, 100000, r, s_f2,
                 &res_f2, &err_f2);
         } while (fabs(gsl_monte_vegas_chisq(s_f2) - 1.0) > 0.5);
         cout << "Fr:" << endl;
         cout << ((t - m * m) / Q2) * (res_f10 - res_f1) << endl;

         cout << res_f2 << endl;

     }


 }

 {

     {

         struct my_f_params params1 = { Q2,t,m,mq,b,b1,N21 };
         gsl_monte_vegas_state* s_f1 = gsl_monte_vegas_alloc(4);
         gsl_monte_function G_f1 = { &g_friaPmuBuck, 4,&params1 };
         gsl_monte_vegas_integrate(&G_f1, xl_f, xu_f, 4, 100000, r, s_f1,
             &res_f1, &err_f1);
         do
         {
             gsl_monte_vegas_integrate(&G_f1, xl_f, xu_f, 4, 100000, r, s_f1,
                 &res_f1, &err_f1);
         } while (fabs(gsl_monte_vegas_chisq(s_f1) - 1.0) > 0.5);

         struct my_f_params params10 = { 0,t,m,mq,b,b1,N21 };
         gsl_monte_vegas_state* s_f10 = gsl_monte_vegas_alloc(4);
         gsl_monte_function G_f10 = { &g_friaPmuBuck, 4,&params10 };
         gsl_monte_vegas_integrate(&G_f10, xl_f, xu_f, 4, 100000, r, s_f10,
             &res_f10, &err_f10);
         do
         {
             gsl_monte_vegas_integrate(&G_f10, xl_f, xu_f, 4, 100000, r, s_f10,
                 &res_f10, &err_f10);
         } while (fabs(gsl_monte_vegas_chisq(s_f10) - 1.0) > 0.5);

         gsl_monte_vegas_state* s_f2 = gsl_monte_vegas_alloc(4);
         gsl_monte_function G_f2 = { &g_friaqmuBuck, 4,&params1 };
         gsl_monte_vegas_integrate(&G_f2, xl_f, xu_f, 4, 100000, r, s_f2,
             &res_f2, &err_f2);
         do
         {
             gsl_monte_vegas_integrate(&G_f2, xl_f, xu_f, 4, 100000, r, s_f2,
                 &res_f2, &err_f2);
         } while (fabs(gsl_monte_vegas_chisq(s_f2) - 1.0) > 0.5);
         cout << "Buck:" << endl;
         cout << ((t - m * m) / Q2) * (res_f10 - res_f1) << endl;

         cout << res_f2 << endl;

     }


 }*/


     //{
     //    struct my_f_params_1 params1 = { Q2,t,m,mq };
     //    gsl_monte_vegas_state* s_f1 = gsl_monte_vegas_alloc(2);
     //    gsl_monte_function G_f1 = { &F1, 2,&params1 };
     //    gsl_monte_vegas_integrate(&G_f1, xl, xu, 2, 1000000, r, s_f1,
     //        &res_f1, &err_f1);
     //    do
     //    {
     //        gsl_monte_vegas_integrate(&G_f1, xl, xu, 2, 1000000, r, s_f1,
     //            &res_f1, &err_f1);
     //    } while (fabs(gsl_monte_vegas_chisq(s_f1) - 1.0) > 0.5);

     //    struct my_f_params_1 params10 = { 0,t,m,mq };
     //    gsl_monte_vegas_state* s_f10 = gsl_monte_vegas_alloc(2);
     //    gsl_monte_function G_f10 = { &F1, 2,&params10 };
     //    gsl_monte_vegas_integrate(&G_f10, xl, xu, 2, 1000000, r, s_f10,
     //        &res_f10, &err_f10);
     //    do
     //    {
     //        gsl_monte_vegas_integrate(&G_f10, xl, xu, 2, 1000000, r, s_f10,
     //            &res_f10, &err_f10);
     //    } while (fabs(gsl_monte_vegas_chisq(s_f10) - 1.0) > 0.5);

     //    gsl_monte_vegas_state* s_f2 = gsl_monte_vegas_alloc(2);
     //    gsl_monte_function G_f2 = { &F2, 2,&params1 };
     //    gsl_monte_vegas_integrate(&G_f2, xl, xu, 2, 1000000, r, s_f2,
     //        &res_f2, &err_f2);
     //    do
     //    {
     //        gsl_monte_vegas_integrate(&G_f2, xl, xu, 2, 1000000, r, s_f2,
     //            &res_f2, &err_f2);
     //    } while (fabs(gsl_monte_vegas_chisq(s_f2) - 1.0) > 0.5);
     //    cout << "Right:" << endl;
     //    cout << ((t - m * m) / Q2) * (res_f10 - res_f1) << endl;

     //    cout << res_f2 << endl;
     //}
       
     file.close();
    return 0;
}

// Запуск программы: CTRL+F5 или меню "Отладка" > "Запуск без отладки"
// Отладка программы: F5 или меню "Отладка" > "Запустить отладку"

// Советы по началу работы 
//   1. В окне обозревателя решений можно добавлять файлы и управлять ими.
//   2. В окне Team Explorer можно подключиться к системе управления версиями.
//   3. В окне "Выходные данные" можно просматривать выходные данные сборки и другие сообщения.
//   4. В окне "Список ошибок" можно просматривать ошибки.
//   5. Последовательно выберите пункты меню "Проект" > "Добавить новый элемент", чтобы создать файлы кода, или "Проект" > "Добавить существующий элемент", чтобы добавить в проект существующие файлы кода.
//   6. Чтобы снова открыть этот проект позже, выберите пункты меню "Файл" > "Открыть" > "Проект" и выберите SLN-файл.


// Запуск программы: CTRL+F5 или меню "Отладка" > "Запуск без отладки"
// Отладка программы: F5 или меню "Отладка" > "Запустить отладку"

// Советы по началу работы 
//   1. В окне обозревателя решений можно добавлять файлы и управлять ими.
//   2. В окне Team Explorer можно подключиться к системе управления версиями.
//   3. В окне "Выходные данные" можно просматривать выходные данные сборки и другие сообщения.
//   4. В окне "Список ошибок" можно просматривать ошибки.
//   5. Последовательно выберите пункты меню "Проект" > "Добавить новый элемент", чтобы создать файлы кода, или "Проект" > "Добавить существующий элемент", чтобы добавить в проект существующие файлы кода.
//   6. Чтобы снова открыть этот проект позже, выберите пункты меню "Файл" > "Открыть" > "Проект" и выберите SLN-файл.
